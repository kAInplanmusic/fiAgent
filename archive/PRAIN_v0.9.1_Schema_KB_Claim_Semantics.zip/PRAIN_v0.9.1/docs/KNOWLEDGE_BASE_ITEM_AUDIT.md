# Knowledge base item-level reconciliation — PRAIN workstream 2

**Result:** JSON and embedded HTML database are structurally and value-identical after key-order normalization.

- JSON source: `PRAIN_Wissensdatenbank.json`
- HTML source: `PRAIN_interaktive_Wissensdatenbank.html`
- Top-level sections: project, dimensions, cross_cutting, relations, sources, priority
- Dimensions: 5; cross-cutting entries: 3; relations: 8; sources: 17; priorities: 7
- Recursive difference count: 0

## Section counts and entry identity

- `project`: 6 item(s)
- `dimensions`: 5 item(s)
- `cross_cutting`: 3 item(s)
- `relations`: 8 item(s)
- `sources`: 17 item(s)
- `priority`: 7 item(s)

No data-level differences were found. This does not mean that claims are factually verified; it only establishes that the HTML’s embedded database matches the JSON source.

## Item-level semantic inventory

The current database is synchronized as data, but several governance gaps remain: claim objects use free-text `status` and `confidence`; source IDs are referenced from dimensions, but claim-level provenance/evidence is not consistently represented; `project.purpose` still mentions Hallerbans, which conflicts with PRAIN’s now-canonical independent-framework definition; and the legacy dimensions `brain`, `soul`, `will`, `body`, `senses` require an explicit mapping to R/A/I/N/P. These are semantic/model changes, not JSON-vs-HTML sync errors.

### Required correction/migration actions
1. Keep JSON as the canonical authoring source; HTML should be generated from it or validated against it in CI.
2. Change the project purpose so PRAIN is defined independently of any particular host agent; Hallerbans is a possible consumer, not a defining dependency.
3. Add stable claim IDs and structured fields: subject, predicate, object/value, scope, epistemic status, confidence model, valid time, recorded time, provenance, evidence refs, counterevidence refs, reviewer/verification record.
4. Replace free-text confidence/status with controlled values and explicit semantics; do not silently convert legacy values.
5. Add source-level metadata (canonical URL/identifier, title, publisher/author, publication date, retrieval date, source type, integrity digest, license/usage note, trust assessment).
6. Add a relation mapping record for each legacy dimension and relation; keep source text unchanged while recording the canonical interpretation and any ambiguity.
7. Add a test that extracts embedded DB from HTML and compares canonical JSON against the JSON source; fail build on divergence.
8. Maintain provenance for each migrated field and an explicit `migration_version`; no destructive replacement of legacy knowledge.

## Relation mapping review

- `senses` → P / Perception.
- `brain` → R / Reason for inference and cognition; memory storage is cross-cutting and must not be equated exclusively with R.
- `soul` → A / Anima for self-model and continuity; it is not the policy authorization authority.
- `will` → I / Intention for goals, priorities and commitment.
- `body` → N / Nerve for execution and tool-facing action; runtime/OS remain replaceable infrastructure.
- Cross-cutting: evidence, security, privacy, identity lineage, feedback and governance.
- Any legacy relation claiming that A/Soul itself authorizes actions must be reinterpreted: only the policy gateway grants/denies permission.
