# Deep schema field audit — PRAIN v0.9 workstream 1

**Status:** static comparison of archived JSON Schemas; no runtime implementation. Similar names do not imply interchangeable contracts. This audit is descriptive and flags candidate migration requirements; it does not silently select a canonical schema.

## Executive findings

- The v0.2.1 contracts are the earliest broad structured baseline: observations, claims, evidence, goals, policy decisions, state snapshots, action requests/results, event envelopes, agent manifests and traces.
- v0.4 changes core identifiers and shapes for Goal and Action Request, and introduces a richer Message Envelope. Treat these as breaking contract generations, not additive updates.
- v0.5 separates intent/dispatch (`action-command`) from execution evidence (`execution-receipt`), and adds explicit tenant, aggregate, classification and producer structures to the envelope.
- v0.6 adds a semantic message with explicit epistemic status/provenance plus HAL health and repair contracts. These complement dispatch/state contracts rather than replace them.
- `additionalProperties: false` appears throughout inspected root schemas. This makes unversioned field additions invalid and means every evolution needs a new schema version or an explicitly designed extension point.
- Schema identifiers use `prain.dev`, `prain.local`, and `prain.example` across generations. Registry canonicalization is unresolved; do not treat these IDs as production-resolvable references.

## Inventory and required-field diffs

### v0.2.1 — `action-request`
- Path: `PRAIN_Phase0_v0.2.1/schemas/action-request.schema.json`
- Title: PRAIN ActionRequest
- `$id`: `https://prain.dev/schema/action-request-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (10): id, actor_id, capability, target, declared_side_effects, risk_level, policy_decision_ref, correlation_id, idempotency_key, schema_version
- Properties (13): id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version
- Root `additionalProperties`: `False`

### v0.2.1 — `action-result`
- Path: `PRAIN_Phase0_v0.2.1/schemas/action-result.schema.json`
- Title: PRAIN ActionResult
- `$id`: `https://prain.dev/schema/action-result-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (6): id, action_request_id, execution_status, verification_status, occurred_at, schema_version
- Properties (10): id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version
- Root `additionalProperties`: `False`

### v0.2.1 — `agent-manifest`
- Path: `PRAIN_Phase0_v0.2.1/schemas/agent-manifest.schema.json`
- Title: PRAIN AgentManifest
- `$id`: `https://prain.dev/schema/agent-manifest-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (6): agent_id, identity_version, role, capabilities, limitations, schema_version
- Properties (10): agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version
- Root `additionalProperties`: `False`

### v0.2.1 — `claim`
- Path: `PRAIN_Phase0_v0.2.1/schemas/claim.schema.json`
- Title: PRAIN Claim
- `$id`: `https://prain.dev/schema/claim-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (6): id, statement, kind, verification_status, created_at, schema_version
- Properties (14): id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version, verification_exception_ref
- Root `additionalProperties`: `False`

### v0.2.1 — `event-envelope`
- Path: `PRAIN_Phase0_v0.2.1/schemas/event-envelope.schema.json`
- Title: PRAIN Event Envelope
- `$id`: `https://prain.dev/schema/event-envelope-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (7): event_id, event_type, occurred_at, producer, correlation_id, schema_version, payload
- Properties (10): event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context
- Root `additionalProperties`: `False`

### v0.2.1 — `evidence`
- Path: `PRAIN_Phase0_v0.2.1/schemas/evidence.schema.json`
- Title: PRAIN Evidence
- `$id`: `https://prain.dev/schema/evidence-0.2.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (6): id, kind, source_ref, captured_at, integrity, schema_version
- Properties (9): id, kind, source_ref, captured_at, content_hash, integrity, classification, retention_policy_ref, schema_version
- Root `additionalProperties`: `False`

### v0.2.1 — `goal`
- Path: `PRAIN_Phase0_v0.2.1/schemas/goal.schema.json`
- Title: PRAIN Goal
- `$id`: `https://prain.dev/schema/goal-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (7): id, description, status, priority, acceptance_criteria, version, created_at
- Properties (11): id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at
- Root `additionalProperties`: `False`

### v0.2.1 — `observation`
- Path: `PRAIN_Phase0_v0.2.1/schemas/observation.schema.json`
- Title: PRAIN Observation
- `$id`: `https://prain.dev/schema/observation-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (6): id, type, source, occurred_at, schema_version, payload_ref
- Properties (12): id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels
- Root `additionalProperties`: `False`

### v0.2.1 — `policy-decision`
- Path: `PRAIN_Phase0_v0.2.1/schemas/policy-decision.schema.json`
- Title: PRAIN PolicyDecision
- `$id`: `https://prain.dev/schema/policy-decision-0.1.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (7): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version
- Properties (8): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref
- Root `additionalProperties`: `False`

### v0.2.1 — `state-snapshot`
- Path: `PRAIN_Phase0_v0.2.1/schemas/state-snapshot.schema.json`
- Title: PRAIN StateSnapshot
- `$id`: `https://prain.dev/schema/state-snapshot-0.2.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (6): id, entity_type, version, updated_at, data, schema_version
- Properties (8): id, entity_type, version, updated_at, data, content_classification, retention_policy_ref, schema_version
- Root `additionalProperties`: `False`

### v0.2.1 — `trace-event`
- Path: `PRAIN_Phase0_v0.2.1/schemas/trace-event.schema.json`
- Title: PRAIN TraceEvent
- `$id`: `https://prain.dev/schema/trace-event-0.2.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (8): trace_id, span_id, event_id, timestamp, component, operation, outcome, schema_version
- Properties (11): trace_id, span_id, parent_span_id, event_id, timestamp, component, operation, outcome, policy_decision_ref, redaction_applied, schema_version
- Root `additionalProperties`: `False`

### v0.4.0 — `action-request`
- Path: `PRAIN_Architecture_v0.4.0/contracts/action-request.schema.json`
- Title: PRAIN Action Request
- `$id`: `https://prain.local/schemas/action-request-0.4.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (10): action_id, goal_id, plan_id, actor, action, target, input_digest, capability_ref, idempotency_key, requested_at
- Properties (15): action_id, goal_id, plan_id, actor, action, target, input_digest, capability_ref, idempotency_key, requested_at, deadline, preconditions, expected_postconditions, risk_class, policy_decision_ref
- Root `additionalProperties`: `False`

### v0.4.0 — `goal`
- Path: `PRAIN_Architecture_v0.4.0/contracts/goal.schema.json`
- Title: PRAIN Goal
- `$id`: `https://prain.local/schemas/goal-0.4.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (10): goal_id, revision, title, desired_outcome, owner, priority, status, acceptance_criteria, created_at, updated_at
- Properties (17): goal_id, revision, title, desired_outcome, owner, requester, priority, status, acceptance_criteria, constraints, depends_on, budget, deadline, created_at, updated_at, verification_ref, blocked_reason
- Root `additionalProperties`: `False`

### v0.4.0 — `message-envelope`
- Path: `PRAIN_Architecture_v0.4.0/contracts/message-envelope.schema.json`
- Title: PRAIN Message Envelope
- `$id`: `https://prain.local/schemas/message-envelope-0.4.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (8): message_id, message_type, name, schema_version, created_at, producer, correlation_id, payload
- Properties (14): message_id, message_type, name, schema_version, created_at, producer, recipient, correlation_id, causation_id, tenant_id, idempotency_key, trace_context, provenance, payload
- Root `additionalProperties`: `False`

### v0.5.0 — `action-command`
- Path: `PRAIN_Distributed_Protocol_v0.5.0/schemas/action-command.schema.json`
- Title: PRAIN Action Command
- `$id`: `https://prain.dev/schemas/action-command-0.5.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (8): command_id, idempotency_key, action_digest, target, action, expected_policy_version, retry_class, deadline
- Properties (9): command_id, idempotency_key, action_digest, target, action, expected_policy_version, retry_class, deadline, lease
- Root `additionalProperties`: `False`

### v0.5.0 — `execution-receipt`
- Path: `PRAIN_Distributed_Protocol_v0.5.0/schemas/execution-receipt.schema.json`
- Title: PRAIN Execution Receipt
- `$id`: `https://prain.dev/schemas/execution-receipt-0.5.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (7): receipt_id, command_id, status, attempt, observed_at, executor, evidence_refs
- Properties (9): receipt_id, command_id, status, attempt, observed_at, executor, error_code, evidence_refs, reconciliation
- Root `additionalProperties`: `False`

### v0.5.0 — `message-envelope`
- Path: `PRAIN_Distributed_Protocol_v0.5.0/schemas/message-envelope.schema.json`
- Title: PRAIN Message Envelope
- `$id`: `https://prain.dev/schemas/message-envelope-0.5.0.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (9): message_id, message_type, schema_version, created_at, producer, correlation_id, tenant_id, payload, classification
- Properties (14): message_id, message_type, schema_version, created_at, producer, correlation_id, causation_id, tenant_id, aggregate, payload, provenance, trace, classification, expires_at
- Root `additionalProperties`: `False`

### v0.6 — `health-signal`
- Path: `PRAIN_v0.6/schemas/health-signal.schema.json`
- Title: PRAIN v0.6 HAL Health Signal
- `$id`: `https://prain.example/schemas/v0.6/health-signal.schema.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (7): schema_version, signal_id, observed_at, scope, metric, status, source
- Properties (12): schema_version, signal_id, observed_at, scope, metric, value, unit, status, threshold_ref, source, evidence_refs, fresh_until
- Root `additionalProperties`: `False`

### v0.6 — `repair-proposal`
- Path: `PRAIN_v0.6/schemas/repair-proposal.schema.json`
- Title: PRAIN v0.6 HAL Repair Proposal
- `$id`: `https://prain.example/schemas/v0.6/repair-proposal.schema.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (11): schema_version, proposal_id, created_at, target, observation_refs, change, bounds, rollout, success_metrics, rollback_conditions, expires_at
- Properties (12): schema_version, proposal_id, created_at, target, observation_refs, change, bounds, rollout, success_metrics, rollback_conditions, expires_at, status
- Root `additionalProperties`: `False`

### v0.6 — `semantic-message`
- Path: `PRAIN_v0.6/schemas/semantic-message.schema.json`
- Title: PRAIN v0.6 Semantic Message
- `$id`: `https://prain.example/schemas/v0.6/semantic-message.schema.json`; `$schema`: `https://json-schema.org/draft/2020-12/schema`
- Required (9): schema_version, message_id, message_type, created_at, producer, scope, epistemic_status, payload, provenance
- Properties (18): schema_version, message_id, correlation_id, causation_id, message_type, created_at, producer, scope, epistemic_status, aggregate, affected_dependencies, valid_until, confidence, payload, provenance, required_response, idempotency_key, trace_id
- Root `additionalProperties`: `False`

## Cross-version contract families

### Action request / action command
- v0.2.1 `ActionRequest` requires `id`, `actor_id`, `capability`, `target`, declared side effects, risk level, policy-decision reference, correlation ID, idempotency key and schema version.
- v0.4 `Action Request` instead requires `action_id`, `goal_id`, `plan_id`, `actor`, `action`, `input_digest`, `capability_ref`, idempotency key and requested time. This is a semantic and structural redesign.
- v0.5 `Action Command` carries a command ID, idempotency key, action digest, target/action, expected policy version, retry class and deadline; lease is optional. It is a dispatch contract, not a direct field-for-field successor.
- Required migration: explicit adapter mapping; do not infer equivalence between `actor_id` and `actor`, `input_ref` and `input_digest`, or `risk_level` and `risk_class` without a semantic rule.

### Goal
- v0.2.1 uses `id`, free-text `description`, integer `priority`, `version`, and acceptance criteria.
- v0.4 uses `goal_id`, `revision`, `title`, `desired_outcome`, structured `priority`, owner/requester, dependencies, budget, deadline and verification reference.
- Required migration: define stable goal identity versus revision; map priority representation; specify status transition compatibility and whether `description` maps to `desired_outcome` or remains separate.

### Event/message envelope
- v0.2.1 event envelope uses `event_id`, `event_type`, `occurred_at`, string producer, correlation ID and payload.
- v0.4 message envelope adds message type/name, recipient, tenant ID, idempotency key, trace context and provenance; `producer` remains comparatively simple.
- v0.5 envelope makes `producer` an object and requires `tenant_id` and `classification`; adds aggregate, provenance, trace and optional expiry.
- v0.6 semantic message requires scope, epistemic status and provenance; it adds semantic obligations but is not a transport-envelope replacement.
- Required migration: separate transport envelope from semantic payload, or formally define one canonical envelope with versioned profiles. Do not merge these shapes informally.

### Execution outcomes and evidence
- v0.2.1 `ActionResult` has execution status and verification status; v0.5 `Execution Receipt` has receipt/command IDs, status, attempt, executor, evidence references and reconciliation. There is no proven one-to-one status mapping yet.
- Evidence v0.2.1 includes source, capture time, integrity and classification/retention. v0.5 receipts refer to evidence but do not replace the evidence record.
- Required migration: distinguish command acceptance, execution started, effect observed, effect verified, and outcome unknown; keep evidence records independent from receipts.

### Claim and epistemic status
- v0.2.1 Claim has statement/kind, optional subject-predicate-object, evidence refs, numeric confidence and verification status.
- v0.6 semantic message has a required `epistemic_status`, provenance and optional confidence; it is a message-level epistemic marker, not a complete claim entity schema.
- Required migration: define claim lifecycle and confidence semantics before changing the old claim schema. A numeric confidence must not be treated as verification.

### HAL contracts
- v0.6 Health Signal requires scope, metric, status, source and observed time; Repair Proposal requires target, observations, change, bounds, rollout, success metrics, rollback conditions and expiry.
- These contracts should be constrained by a policy envelope: a proposal is not authorization, and a health signal is not itself proof that a repair is safe.

## Global schema quality issues to resolve

1. Standardize JSON Schema dialect and canonical `$id` namespace; preserve old IDs as aliases if required.
2. Add a machine-readable migration registry with source schema/version, target schema/version, lossiness, defaulting rules and rejection conditions.
3. Define enum values and state-transition matrices centrally; field names alone are not enough to compare status semantics.
4. Audit nested object closure, array item constraints, formats, patterns, min/max constraints and `$ref` resolution as a second-level review.
5. Add golden valid/invalid fixtures for every schema and migration pair; test unknown fields explicitly.
6. Define compatibility policy: strict readers; versioned writers; no silent default for authorization, identity, evidence, tenancy or execution status.

## Recommended disposition

- Preserve each historical schema unchanged.
- Introduce a canonical contract registry only after decisions on identifier namespace and semantic mapping.
- Prefer explicit versioned adapters over in-place mutation.
- Do not mark schema work complete until nested constraints and automated valid/invalid test vectors are reviewed.
