# PRAIN v0.9 — Decision freeze proposal

**Status:** proposed decisions for user review; not silently accepted. This package does not close Phase 0.

| ID | Topic | Proposed baseline | Status |
|---|---|---|---|
| D-0901 | Claim epistemics | Explicit states: observed, inferred, assumed, verified, disputed, invalidated; transitions require evidence and provenance. | PROPOSED |
| D-0902 | Principal/tenant | Every command/action is bound to a principal and tenant/scope; delegated authority carries issuer, scope, expiry and revocation reference. | PROPOSED |
| D-0903 | Record authority | Define record classes: authoritative, append-only evidence, derived projection, ephemeral telemetry; authority and consistency declared per class. | PROPOSED |
| D-0904 | Action lifecycle | Intent/goal → plan → action request → policy decision → command → receipt/result → verification evidence → authoritative state update. | PROPOSED |
| D-0905 | Unknown outcome | Persist `unknown`; reconcile with target/evidence before retry; expired lease is not proof of non-execution. | CARRIED FORWARD |
| D-0906 | Policy and approvals | Action-bound, principal-bound, target/scope-bound, expiring approval; re-check policy immediately before side effect; revocation blocks future execution. | PROPOSED |
| D-0907 | Evidence crypto | Hash content and canonical metadata; signatures and key IDs optional per trust tier; rotation/revocation and verification procedure required. | PROPOSED |
| D-0908 | Deletion/retention | Retention by data class; delete source and derived copies where legally/operationally required; keep only a minimal deletion receipt where permitted. | PROPOSED |
| D-0909 | HAL adaptation | Only enumerated, bounded, expiring, reversible changes; independent verifier; no permission/policy ceiling changes; rollback on failed metrics. | CARRIED FORWARD |
| D-0910 | SLOs | Define per-boundary latency, queue age, recovery time, evidence completeness and false-positive thresholds before implementation. | OPEN — needs workload targets |
| D-0911 | Broker/storage | Keep replaceable; select after workload, durability, operational cost and recovery tests. | DEFERRED |
| D-0912 | Dedup retention | Keep idempotency records at least as long as command validity + maximum reconciliation/replay horizon; specify per external connector. | PROPOSED |
| D-0913 | Schema evolution | Versioned schemas, explicit compatibility classification, migration adapters and golden fixtures; no implicit field aliasing. | PROPOSED |
| D-0914 | Group consensus | Require group-level consensus only for shared high-impact authoritative decisions; not for observations or local projections. | PROPOSED |

## Required decision procedure
For every proposed row, user approval or explicit deferral must be recorded. “Proposed” does not mean implemented or binding. Broker/provider choices remain deliberately deferred until workload and operational requirements are defined.
