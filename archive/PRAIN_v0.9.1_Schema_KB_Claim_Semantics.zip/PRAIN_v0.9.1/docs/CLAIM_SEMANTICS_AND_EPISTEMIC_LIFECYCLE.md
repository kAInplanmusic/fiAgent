# Claim semantics and epistemic lifecycle — PRAIN workstream 3

**Status:** proposed normative specification for Phase 0 review. It does not overwrite historical schemas or imply user approval. The values and rules below are a candidate canonical model.

## 1. Separate the dimensions

A claim must not collapse these independent axes into one `status`:

- **Epistemic status**: what kind of knowledge posture applies.
- **Verification status**: what verification procedure has actually run and with what result.
- **Confidence**: a calibrated estimate or ordinal assessment with a declared method; never a substitute for evidence or verification.
- **Validity**: whether the claim applies in the relevant world/time/scope.
- **Lifecycle status**: whether the record is active, superseded, withdrawn or deleted under governance rules.

## 2. Canonical epistemic statuses (proposal)

| Status | Meaning | Permitted basis | Must not imply |
|---|---|---|---|
| `observed` | Directly recorded observation with provenance | Sensor/tool/user/source event and capture metadata | Truth beyond the observation itself |
| `reported` | A source asserts the proposition | Identified source and source excerpt/reference | Independent confirmation |
| `inferred` | Derived from premises/rules/model output | Explicit premise claim IDs and inference method/version | Direct observation |
| `hypothesized` | Candidate explanation not yet sufficiently tested | Rationale and proposed falsification/verification method | High confidence or established fact |
| `corroborated` | Independent evidence supports the same proposition | At least two genuinely independent evidence paths or an explicitly approved equivalent | Absolute certainty |
| `verified` | Required verification procedure passed for declared scope | Named verifier/procedure, version, timestamp and evidence | Timeless truth or universal validity |
| `disputed` | Credible counterevidence or incompatible claims exist | Counterclaim/evidence references and conflict reason | That the original claim is necessarily false |
| `refuted` | The proposition failed a defined test or is contradicted by stronger evidence within scope | Reproducible refutation basis and scope | Global falsity outside that scope |
| `unknown` | Evidence is insufficient or unavailable | Explicit reason and next-step if known | Negative evidence |

`verified` and `refuted` are not simple confidence levels. `disputed` may coexist with an earlier verification record: the current epistemic view changes while the historical verification event remains immutable.

## 3. Verification status (separate field)

Recommended values: `not_checked`, `pending`, `passed`, `failed`, `inconclusive`, `stale`, `not_applicable`.

Rules:
- A claim can be `observed` with verification `not_checked`.
- A claim can be `inferred` and verification `passed` only when the inference procedure itself was checked; this does not transform its origin into direct observation.
- A verification result is scoped to a method/version, inputs, time and acceptance criteria.
- Expired or superseded evidence makes a result potentially `stale`; it does not silently erase history.

## 4. Confidence model

Preferred representation is optional numeric `confidence` in `[0,1]` plus required `confidence_method` when numeric confidence is supplied. The method identifies whether the value is calibrated probability, model self-estimate, human rating, or a domain-specific score. If values cannot be calibrated, use an ordinal assessment (`low`, `medium`, `high`) with its rubric, not a fabricated probability. Confidence may be absent; missing is not zero.

No generic threshold (for example 0.8) may automatically promote a claim to `verified`. Promotion requires evidence and an explicit verification policy.

## 5. Required claim record fields (proposal)

- `claim_id`: stable opaque identifier.
- `schema_version`.
- `proposition`: normalized statement or subject-predicate-object form; both can coexist but must be consistent.
- `scope`: entity/domain/tenant and applicable conditions.
- `epistemic_status` and `verification_status`.
- `provenance[]`: origin, source reference, capture/record time, producer, transformation/inference method and parent references.
- `evidence_refs[]` and `counterevidence_refs[]`.
- `confidence` and `confidence_method` when available.
- `valid_time`: `valid_from`, optional `valid_until`; separate from `recorded_at` and `updated_at`.
- `review`: optional reviewer, procedure/version, result and timestamp.
- `supersedes[]` / `superseded_by` where applicable; never silently mutate historical assertions.

## 6. Allowed transitions (candidate state machine)

- New record starts in one of `observed`, `reported`, `inferred`, `hypothesized`, or `unknown` according to provenance.
- `hypothesized` → `corroborated`, `verified`, `disputed`, `refuted`, or remains hypothesized, only with a recorded event and evidence.
- `reported` / `observed` / `inferred` → `corroborated`, `verified`, `disputed`, `refuted`, or `unknown` as evidence changes; preserve origin and history.
- `corroborated` → `verified` only when the declared verification policy passes; can become `disputed`, `refuted`, `stale`, or `unknown` if evidence/premises change.
- `verified` → `disputed`, `refuted`, `stale`, or `unknown` only through a new event with counterevidence, invalidation, scope change, or expiry; never rewrite the historical verification result.
- `disputed` → `corroborated`, `verified`, `refuted`, or `unknown` only after reconciliation with recorded reasons.
- `refuted` is terminal for that exact proposition and scope except when a correction creates a new claim version or a materially changed proposition; do not resurrect by editing history.
- `unknown` may move to another epistemic state when new evidence arrives.
- `superseded` is a lifecycle state, not an epistemic status; it points to a successor claim and preserves the old record.

Any transition not defined by policy is rejected or deferred, not guessed.

## 7. Evidence and conflict rules

1. Every material status transition emits an append-only claim event containing prior/new state, actor, time, reason, evidence references and policy/rule version.
2. A source assertion is not independent corroboration of itself through multiple mirrors, summaries or model paraphrases.
3. Conflicting claims remain separately addressable; do not overwrite one with the other. Create a conflict set with scope, competing claim IDs, evidence and resolution status.
4. Evidence must retain source identity, captured time, integrity metadata and applicable classification/retention policy.
5. Derived claims must reference their premise claims and inference method/version. If a premise is invalidated, derived claims become candidates for re-evaluation; they are not automatically false unless dependency policy says so.
6. Absence of evidence is not evidence of falsity unless the relevant search/test has defined coverage and sensitivity.
7. Human review is evidence about a review decision, not a magical guarantee of correctness.
8. Policy authorization remains separate from epistemic confidence: a high-confidence claim cannot grant execution permission.

## 8. Migration from legacy v0.2.x Claim

Legacy fields: `statement`, `kind`, `subject_id`, `predicate`, `object_ref`, `evidence_refs`, `confidence`, `verification_status`, `valid_from`, `valid_until`, `created_at`, optional `verification_exception_ref`.

Proposed mapping:
- `id` → `claim_id` (preserve original value in `legacy_ids`).
- `statement` → `proposition.statement`; retain as supplied, do not auto-normalize destructively.
- `kind` → `claim_kind` only after a controlled vocabulary is approved.
- `subject_id`/`predicate`/`object_ref` → structured proposition if present; missing values remain missing.
- `evidence_refs` → `evidence_refs`; do not fabricate provenance from the reference alone.
- `confidence` → `confidence` with `confidence_method = unknown_legacy_method` until source semantics are documented.
- `verification_status` → preserve under `legacy_verification_status`; map to the new field only through an explicit mapping table. No direct mapping is safe from the schema alone.
- `created_at` → `recorded_at` only if it truly denotes record creation; preserve original field.
- `valid_from`/`valid_until` → `valid_time`.
- `verification_exception_ref` → review/exception reference; must not be treated as a pass.

## 9. Acceptance tests

- Numeric confidence alone never changes epistemic or verification status.
- A claim with no provenance cannot be promoted to `verified`.
- Repeated copies of one source do not count as independent corroboration.
- Contradictory evidence creates a dispute/conflict record and preserves both claims.
- Expired evidence can stale a current verification without erasing its historical receipt.
- Every transition records actor, time, rule version, reason and evidence refs.
- Unknown statuses and undefined transitions are rejected/deferred.
- A derived claim references its premises and inference version.
- `refuted` is scoped to proposition and scope; changed proposition requires a new claim/version.
- Authorization decisions cannot be derived from confidence alone.
