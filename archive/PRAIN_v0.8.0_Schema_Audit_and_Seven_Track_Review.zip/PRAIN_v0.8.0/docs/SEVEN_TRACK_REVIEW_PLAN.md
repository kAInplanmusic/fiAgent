# Seven-track review plan — PRAIN Phase 0

**Execution note:** this environment does not expose a subagent-spawning control. The seven tracks below are therefore independent review workstreams, not falsely represented as seven agents that were actually launched. They are recorded separately and consolidated by the coordinator.

## Track 1 — Schema lineage and compatibility
**Scope:** v0.1→v0.2.x→v0.4→v0.5→v0.6 schema files.
**Output:** `SCHEMA_FIELD_AUDIT.md`; next pass must diff nested constraints, enums, refs, patterns, formats and sample payloads.
**Gate:** no silent breaking changes; migration/adapters specified.

## Track 2 — Semantic ontology and epistemic state
**Scope:** claim, observation, semantic-message, evidence; provenance, confidence, verification, temporal validity.
**Output required:** canonical claim model and promotion/demotion rules.
**Gate:** observed/inferred/assumed/verified/disputed/invalidated are defined; confidence is not treated as proof.

## Track 3 — Identity, principal and tenancy
**Scope:** agent-manifest, identity/lineage, actor, tenant, requester/owner, delegation.
**Output required:** principal/tenant contract, delegation chain, revocation and identity-version semantics.
**Gate:** actor identity is distinct from capability and authorization.

## Track 4 — Authority, consistency and execution lifecycle
**Scope:** state snapshots/CAS, event/message envelopes, action request/command/result/receipt, unknown outcomes.
**Output required:** record-class authority matrix and end-to-end lifecycle crosswalk.
**Gate:** no blind retry after ambiguous external execution; authoritative state is not overwritten by projections.

## Track 5 — Policy, approvals and revocation
**Scope:** policy gateway, action-bound approvals, policy versions, risk classes, HAL bounds.
**Output required:** approval state machine and policy re-check rules.
**Gate:** missing policy/capability denies or defers; HAL cannot elevate permissions or change hard ceilings.

## Track 6 — Evidence, privacy and data lifecycle
**Scope:** evidence integrity, hash-chain/signatures, retention, deletion, redaction, derived indexes/caches.
**Output required:** data classification/retention/deletion matrix and key lifecycle proposal.
**Gate:** verifiable provenance without retaining prohibited/deleted content indefinitely.

## Track 7 — HAL, resilience, observability and conformance
**Scope:** health signals, repair proposals, bounded adaptation, SLOs, backpressure, recovery and restore.
**Output required:** preapproved adaptation catalogue, SLO proposal, complete conformance matrix.
**Gate:** repair proposals are bounded, expiring, evidence-backed, reversible and independently verified.

## Coordinator consolidation order
1. v0.8: audit and normalize evidence, schema and knowledge-base lineage.
2. v0.9: decision pack; resolve or explicitly mark each architecture decision as proposed/accepted/deferred.
3. v0.99: Phase-0 release candidate; every exit criterion has evidence, owner, status and residual risk.
4. v0.1: only after explicit user approval of Phase-0 closure, as a new Phase-1 specification baseline. No runtime implementation is authorized by this plan alone.
