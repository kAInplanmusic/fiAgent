# Seven-track status snapshot

| Track | Current evidence | Status | Required before Phase-0 closure |
|---|---|---|---|
| 1. Schema lineage | `SCHEMA_FIELD_AUDIT.md`, archived schemas | Partial | Nested constraint/enum/ref diff + migration fixtures |
| 2. Semantic ontology | v0.2.x claim/observation, v0.6 semantic message | Open | Claim ontology + epistemic promotion rules |
| 3. Identity/tenancy | v0.2.x manifest; v0.4/v0.5 envelope fields | Open | Principal/tenant/delegation/revocation contract |
| 4. Authority/execution | v0.2.x CAS/policy; v0.5 commands/receipts | Partial | Record-class matrix + canonical lifecycle |
| 5. Policy/approvals | v0.2.x policy decision; v0.6 HAL constraints | Partial | Approval/revocation lifecycle and re-check semantics |
| 6. Evidence/privacy | evidence schema, integrity concepts, retention refs | Open | classification/retention/deletion/key lifecycle matrix |
| 7. HAL/resilience | v0.5 recovery and v0.6 health/repair schemas | Partial | SLOs, adaptation catalogue, conformance closure |

**Interpretation:** “Partial” means there is relevant specification material, not that all acceptance evidence exists. No track is marked complete solely because a schema or design paragraph exists.
