# Phase 0 — Remaining Gaps and Exit Criteria

**Current status: NOT CLOSED.** v0.7.0 is a consolidation/specification candidate, not a user-approved closure record.

## 1. High-priority gaps

| Priority | Gap | Why it matters | Required written result |
|---|---|---|---|
| P0 | Item-by-item reconciliation of `PRAIN_Wissensdatenbank.json` | May contain requirements or decisions not represented in formal specs | Knowledge-base inventory with source IDs and status |
| P0 | Inspect/reconcile interactive HTML data and embedded logic | Prevent presentation-layer rules being mistaken for canonical facts | HTML/data extraction notes and crosswalk |
| P0 | Schema field-level comparison across v0.2.1/v0.4/v0.5/v0.6 | Similar schemas may diverge in required fields, enums, identifiers or semantics | Schema diff and canonical contract decision |
| P0 | Claim ontology and epistemic promotion | Prevent hypothesis/model output becoming fact without evidence | Claim types, status transitions, evidence thresholds |
| P0 | Principal/tenant/identity contract | Needed for authorization, isolation and lineage | Principal, tenant, actor and delegation model |
| P0 | Authoritative record-class matrix | Needed to determine consistency, owner and conflict handling | Per-record source-of-truth/consistency table |
| P0 | Data lifecycle/privacy contract | Retention/deletion must include projections, caches, replicas, backups and evidence | Classification, retention, redaction, deletion and tombstone rules |
| P1 | Human approval and revocation lifecycle | Approval must be action-specific and time-bounded | Approval schema/state machine and revocation race behavior |
| P1 | Evidence integrity and cryptographic key lifecycle | Hash-chain alone does not establish signer identity | Signing scope, key rotation, verification and recovery |
| P1 | Adaptation policy for HAL | Distinguish safe preapproved repair from approval-required changes | Allowed change classes, budgets, canary, rollback and escalation |
| P1 | SLOs and operational thresholds | Recovery/latency targets otherwise remain vague | User-approved target classes or explicit “implementation-dependent” values |
| P1 | Schema compatibility and migration protocol | Safe evolution across old/new workers | Compatibility table, migration sequencing and rollback |
| P1 | Idempotency and deduplication retention | Expiring dedup state can re-enable duplicate side effects | Scope, key construction, retention and reconciliation policy |
| P2 | Broker/database/provider selection | Architecture has candidates, not final commitments | Explicitly defer to implementation decision or select later |
| P2 | Quantum-ready interface boundary | Phrase should have concrete replaceable interface semantics | Provider capability contract and non-quantum fallback |

## 2. Phase 0 exit criteria
Phase 0 can be proposed for acceptance only when:
1. Every artifact through v0.6 is inventoried with checksum and version.
2. Every knowledge-base item is mapped to a canonical concept/decision/requirement or marked obsolete/duplicate/open with rationale.
3. Every schema and code fragment has a source/version and an explicit disposition.
4. No unresolved contradictions remain hidden; each is resolved or documented as a deliberate open decision that does not block design acceptance.
5. Canonical entities, claim epistemic statuses, goal/action lifecycles and message envelope are agreed.
6. Authority/consistency classes, conflict resolution, idempotency and unknown-outcome recovery are specified.
7. Policy, identity/tenant, approval/revocation and capability contracts are specified.
8. Retention, redaction, deletion propagation and evidence lineage are specified.
9. HAL proposal/apply/verify/rollback boundaries are specified and cannot bypass authorization/invariants.
10. Reference flows cover normal, duplicate, reordered, stale, concurrent, crash, partition, timeout-after-side-effect, revocation, restore/replay and deletion cases.
11. Conformance matrix maps each requirement to at least one positive and relevant negative test.
12. Schema validation and deterministic reference checks pass on the spec artifacts.
13. All decisions have status, rationale, source, impact and owner (user decision where appropriate).
14. User reviews and explicitly approves the Phase-0 closure record.

## 3. Not required for Phase 0 closure
- Running production runtime or deploying services.
- Selecting an OS, framework, database or message broker unless the user wants those choices frozen now.
- Claiming the system is secure merely because security controls are specified.
- Claiming tests passed against a runtime that does not exist.
- Resolving every research question about quantum computing or consciousness; those are explicitly not assumptions of the architecture.

## 4. Suggested closure sequence
A. Finish archive + knowledge-base inventory.
B. Run schema and enum crosswalk.
C. Resolve P0 semantic/identity/authority/privacy contracts.
D. Complete reference pseudocode and failure matrix.
E. Validate schemas, traceability fixtures and cross-references.
F. Create user-readable decision review.
G. Only after explicit approval, produce signed/versioned Phase-0 acceptance record.
