# Versioning and Change Policy (PROPOSED)

## 1. Artifact immutability
Published version archives are immutable snapshots. Corrections produce a new version and a change note; do not overwrite historical ZIPs.

## 2. Status of decisions
Every decision uses one of: `proposed`, `accepted`, `rejected`, `superseded`, `deferred`.
Every requirement uses one of: `draft`, `specified`, `acceptance_ready`, `accepted`, `implemented_verified`.
“Implemented_verified” must never be used for a paper specification or schema-only validation.

## 3. Semantic versioning
- MAJOR: incompatible meaning, removed required field, changed authorization or state semantics.
- MINOR: backward-compatible optional capability/field or new non-breaking contract.
- PATCH: clarifications, typo fixes, examples/tests that do not change semantics.
Schema version and package version are separate and both must be explicit.

## 4. Required change record
Each change records:
- change ID and date;
- source version and target version;
- reason and alternatives considered;
- affected requirement IDs, schemas, pseudocode, tests and decisions;
- compatibility and migration strategy;
- security/privacy implications;
- rollback or supersession rule;
- approval status and approver.

## 5. Unknown or conflicting requirements
Do not silently choose between conflicting sources. Mark the conflict, preserve both source references, propose a resolution, and obtain user decision where it changes core semantics.
