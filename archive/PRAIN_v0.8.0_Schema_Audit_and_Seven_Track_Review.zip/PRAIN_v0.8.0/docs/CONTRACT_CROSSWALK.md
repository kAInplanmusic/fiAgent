# Contract and Schema Crosswalk

## 1. Existing contract families

| Contract family | v0.2.1 | v0.4.0 | v0.5.0 | v0.6 | Consolidation action |
|---|---|---|---|---|---|
| Observation | `observation.schema.json` | Semantic model | Message provenance | `semantic-message.schema.json` | Define common claim/observation vocabulary and required provenance |
| Claim / belief | `claim.schema.json` | Semantic model | Conflict classes | Identity/lineage + semantic message | Add explicit epistemic status and promotion rules |
| Evidence | `evidence.schema.json` | Observability/evaluation | Execution receipt | Invariant & evidence plane | Define receipt/evidence linkage and integrity/signature policy |
| Goal | `goal.schema.json` | Goal/control loop | Completion verification | Acceptance-criterion tests | Reconcile lifecycle enum and criterion evidence model |
| Action request/command | `action-request.schema.json` | Action contract | `action-command.schema.json` | Execution boundary | Versioned mapping, approval binding and idempotency scope |
| Action result / receipt | `action-result.schema.json` | Failure/recovery | `execution-receipt.schema.json` | Unknown outcome/reconciliation | Define status enum, external idempotency and reconciliation evidence |
| Event/message envelope | `event-envelope.schema.json` | `message-envelope.schema.json` | `message-envelope.schema.json` | `semantic-message.schema.json` | One canonical envelope profile plus versioned extensions |
| State snapshot | `state-snapshot.schema.json` | Aggregate versioning | CAS/conflict model | Authoritative vs projection | Record-class authority and freshness metadata |
| Policy decision | `policy-decision.schema.json` | Threat/trust boundary | Execution-time reauthorization | HAL cannot bypass policy | Bind decision to exact principal, action digest, scope and policy version |
| Agent manifest | `agent-manifest.schema.json` | Capability topology | Worker registry | Local-unit contract | Separate declared capability from granted authorization |
| Trace event | `trace-event.schema.json` | Observability | Fault-injection evidence | Lineage and receipts | Ensure correlation/causation and privacy-safe audit fields |
| Health signal | — | Observability precursor | — | `health-signal.schema.json` | Add freshness, source, scope, confidence/quality and stale behavior |
| Repair proposal | — | Failure/recovery precursor | — | `repair-proposal.schema.json` | Treat as proposal only; policy check, budget, canary, rollback and evidence required |

## 2. Canonical envelope minimum (PROPOSED)
A canonical message should carry:
- `message_id`, `schema_version`, `message_type`
- `occurred_at`, `produced_at` in UTC RFC3339
- `producer_id`, `scope` / tenant context
- `correlation_id`, optional `causation_id`, `trace_id`
- `aggregate_id` and `aggregate_version` where applicable
- `provenance` and epistemic status for semantic claims
- payload and classification
- idempotency key for commands or side-effecting requests
- expiry/deadline where applicable
- signature/key reference when cryptographic message authenticity is enabled

This is a proposed normalized profile, not a claim that all fields are present consistently in all historical schemas. Before acceptance, compare the actual JSON Schemas and decide required/optional fields and migration behavior.

## 3. Action lifecycle (PROPOSED canonical union)
`proposed → policy_check → authorized → dispatched → acknowledged | unknown_outcome → reconciling → succeeded | failed | compensated | manual_review`

Rules:
- Authorization is rechecked at the execution boundary against the exact action digest and current policy.
- A timeout after dispatch is `unknown_outcome`, not `failed`.
- A retry requires idempotency protection or a reconciliation result that establishes safe retry.
- `succeeded` does not imply goal completion; acceptance criteria still require evidence verification.
- `manual_review` is a valid terminal operational state when safety/correctness cannot be established automatically.

The exact enums and transitions must be reconciled against v0.2.1/v0.4/v0.5 schemas before being declared canonical.

## 4. Goal lifecycle (PROPOSED canonical union)
`proposed → accepted → active → blocked | verifying → completed`
Additional terminal or superseding states: `failed`, `cancelled`, `superseded`.
A goal cannot be `completed` unless each required acceptance criterion references acceptable evidence and the verifier records the decision. A successful tool call alone is insufficient.

## 5. Required contract closure tasks
- Extract and compare every historical schema by semantic field, not just filename.
- Establish canonical enums and identify legacy aliases.
- Define backward/forward compatibility and explicit migrations.
- Define authoritative record classes, owners, conflict policy and consistency requirement.
- Define evidence integrity/signature, retention, redaction and deletion propagation.
- Define action idempotency/reconciliation contract per capability adapter.
- Add negative fixtures for unknown fields, missing provenance, stale versions, tenant mismatch and policy revocation.
