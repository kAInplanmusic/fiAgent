# Master Traceability — PRAIN v0.1.0 through v0.6

## 1. Status vocabulary
- **RETAINED** — source contract remains valid in the consolidated design.
- **EXTENDED** — preserved and elaborated by a later version.
- **PROPOSED** — consolidation recommendation; requires explicit user approval.
- **OPEN** — insufficient detail or decision needed.
- **HISTORICAL** — preserved for lineage, not assumed to be current.
- **NOT VERIFIED** — artifact or runtime behavior has not been inspected/tested in this pass.

## 2. Version-to-version map

| Source | Main contribution | Later treatment | Status |
|---|---|---|---|
| Phase 0 v0.1.0 | Earliest Phase-0 baseline | Retain as historical source; compare on any disputed lineage | HISTORICAL |
| Phase 0 v0.2.0 | Expanded contracts and initial schemas | Retain; compare with v0.2.1 for changes | HISTORICAL |
| Phase 0 v0.2.1 | Event/Goal registries, versioned state/CAS, policy gateway, ontology, policy model, schemas, test vectors, exit criteria | Foundation retained; later versions extend semantic, distributed and multiscale contracts | RETAINED/EXTENDED |
| Architecture v0.4.0 | Semantic model, P/R/A/I/N roles, communication, goal/control loop, identity, trust, failure/recovery, observability | Distributed behavior refined in v0.5; multiscale organization refined in v0.6 | EXTENDED |
| Distributed Protocol v0.5.0 | At-least-once, idempotency, outbox/inbox, consistency classes, CAS, leases/fencing, unknown outcome, recovery, 18 conformance tests | Explicitly retained by v0.6; adds semantic conflict classes, selective sync, HAL stability tests | RETAINED/EXTENDED |
| Architecture v0.6 | Multiscale coordination; SCF; HAL; invariant/evidence layer; 15 invariants; semantic/health/repair schemas; 30 conformance tests | Latest architecture layer; not a wholesale replacement of earlier contracts | RETAINED/EXTENDED |
| Phase 1 prototype v0.1.0 | In-memory demonstration/reference implementation | Keep separate; not proof of Phase-0 completeness or production readiness | HISTORICAL |
| `PRAIN_Wissensdatenbank.json` | Existing knowledge-base records | Must be parsed and individually mapped to canonical concepts/decisions/sources | OPEN / NOT VERIFIED |
| `PRAIN_interaktive_Wissensdatenbank.html` | Interactive knowledge-base view | Inspect content and behavior; map data separately from presentation | OPEN / NOT VERIFIED |

## 3. Requirement traceability matrix

| ID | Requirement / invariant | Origin | v0.4 | v0.5 | v0.6 | Consolidated disposition |
|---|---|---|---|---|---|---|
| TR-001 | Canonical P/R/A/I/N logical dimensions | Canonical project definition; v0.4 architecture map | Explicit roles | Retained as logical cores | D-0601 confirms | RETAINED |
| TR-002 | PRAIN independent of any one host agent | Canonical project definition | Architecture describes framework | Transport/deployment replaceable | Modular and multiscale model | RETAINED |
| TR-003 | Quantum-ready means replaceable interfaces, no advantage claim | v0.2.1 decisions; v0.4/v0.5 | Provider abstraction | Explicit non-goal | D-0609 context | RETAINED |
| TR-004 | Provenance and uncertainty travel with observations/claims | v0.2.1 observation/claim/evidence schemas | Semantic model | Message provenance/versioning | D-0606; semantic-message schema | EXTENDED |
| TR-005 | Goals have explicit lifecycle and acceptance criteria | v0.2.1 goal schema | Goal/control loop | Criterion evidence gate | Criterion-level completion retained | EXTENDED |
| TR-006 | Policy gateway is sole authorization boundary | v0.2.1 policy model | Trust boundaries | Execution-time authorization | HAL cannot bypass invariant boundary | RETAINED/EXTENDED |
| TR-007 | Deny/defer when capability, policy, or authority is missing | v0.2.1 policy model | Trust boundary | Unknown authority denies/defer | Global write authority explicit | RETAINED |
| TR-008 | Versioned authoritative state with CAS | v0.2.1 state snapshot / decisions | Aggregate versions | Explicit CAS/conflicts | Per-record authority/consistency | RETAINED/EXTENDED |
| TR-009 | No global exactly-once promise | v0.2.1 delivery decision | At-least-once communication | Explicit at-least-once + idempotency | Retained in SCF | RETAINED |
| TR-010 | Duplicate messages/actions are idempotent where contract allows | v0.2.1 tests | Communication model | Inbox/outbox and idempotency key | SCF duplicate conformance test | RETAINED |
| TR-011 | Unknown external side-effect outcome is first-class | v0.4 failure model | Failure/recovery | Explicit unknown outcome/reconcile | Retained | RETAINED |
| TR-012 | Lease expiry does not prove non-execution | v0.5 | Recovery semantics | Explicit rule | Explicit v0.6 test | RETAINED |
| TR-013 | Goal completion requires evidence for every required criterion | v0.2.1 evidence/goal schemas | Goal/control loop | Protocol rule | v0.6 tests 24–25 | RETAINED/EXTENDED |
| TR-014 | Derived projections never overwrite authoritative records | v0.5 | Semantic projections | Consistency model | Selective sync/invalidation | RETAINED |
| TR-015 | P/R/A/I/N do not imply one service per dimension | Canonical project definition | Logical roles | Cluster topology separate | D-0601/D-0602 | RETAINED |
| TR-016 | Identity/continuity are inspectable and versioned; A is not sole identity source | Canonical definition; v0.4 | Identity & continuity | Principal/tenant model still open | Identity & lineage | RETAINED; details OPEN |
| TR-017 | HAL is supervisory, not sixth core or authorization authority | v0.6 | N/A | N/A | D-0603/D-0608 | RETAINED |
| TR-018 | Local autonomy coexists with global invariants | v0.6 | Reference architecture precursor | Scoped consistency | L0–L3, SCF | RETAINED |
| TR-019 | Privacy controls include classification, retention, redaction and derived deletion | v0.2.1 decisions | Threat/trust boundaries | Recovery/projections | Test 30; exact policies open | RETAINED; implementation rules OPEN |
| TR-020 | Schemas are versioned and migration compatibility explicit | v0.2.1 SemVer decision | Schema contracts | Schema incompatibility test | v0.5→v0.6 migration note | RETAINED; detailed policy OPEN |
| TR-021 | Evidence has provenance and append-only/hash-chain lineage | v0.2.1 decisions/schema | Observability/evidence | Execution receipts | Invariant/evidence layer | RETAINED; crypto/key management OPEN |
| TR-022 | Health/adaptation actions are bounded, observable, reversible where possible | v0.6 | N/A | N/A | HAL spec/tests | RETAINED |
| TR-023 | Broker/provider/storage are replaceable; candidates are not commitments | v0.4/v0.5 | Reference topology | NATS/PostgreSQL candidates | Modular-first decision | RETAINED |
| TR-024 | Knowledge-base items and all code/schema fragments have source lineage | Master index requirement | Partial traceability | Protocol-specific lineage | Partial v0.6 traceability | OPEN — item-by-item inventory required |
| TR-025 | Phase 0 closure needs user-reviewed acceptance record | v0.2.1 exit criteria; master index | Roadmap | Implementation plan exit criteria | Implementation plan | OPEN — not signed/approved |

## 4. Cross-cutting architecture rule
Later versions refine rather than erase earlier contracts unless a decision explicitly says otherwise. v0.6's own compatibility note requires retaining v0.5 envelope fields where practical and adding fields through explicit schema-version migration. This consolidation therefore treats the v0.6 package as the newest architectural layer, not the only source of truth.

## 5. Traceability limitations in this release
This matrix is a cross-version conceptual traceability pass over the archive inventory and core design documents. It is not yet a line-by-line semantic audit of every item in the JSON knowledge base, every embedded script in the HTML knowledge base, or every source line inside every historical archive. Those are explicit remaining Phase-0 closure tasks.
