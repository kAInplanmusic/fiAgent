# Schema field audit — PRAIN v0.8.0

**Status:** static contract audit; no runtime validation. This report compares schema names, fields, required fields and closed-object settings from archived artifacts. It does not declare semantically similar schemas interchangeable.

## Findings

- The v0.2.0 and v0.2.1 schema field sets are identical for the inspected schema files; v0.1.0 contains a smaller initial set and is historical.
- v0.4.0 changes the contract shape for `action-request`, `goal`, and `message-envelope`; these are breaking structural differences from v0.2.x, not mere renames.
- v0.5.0 separates action dispatch (`action-command`) from execution result (`execution-receipt`) and evolves `message-envelope`; explicit migration/adapters are required.
- v0.6.0 adds semantic-message, health-signal, and repair-proposal contracts. They complement rather than replace earlier authoritative contracts.
- Every inspected schema sets `additionalProperties: false`, which is useful for strict validation but requires explicit versioned migration when fields change.
- Schema `$id` and `$schema` values must be audited separately before standardizing a registry; this generated field report does not assume one draft/version across files.

## Inventory

### PRAIN_Phase0_v0.1.0 / `action-result.schema.json`
- Title: PRAIN ActionResult
- Required (6): id, action_request_id, execution_status, verification_status, occurred_at, schema_version
- Fields (10): id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/action-result-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `action-request.schema.json`
- Title: PRAIN ActionRequest
- Required (10): id, actor_id, capability, target, declared_side_effects, risk_level, policy_decision_ref, correlation_id, idempotency_key, schema_version
- Fields (13): id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/action-request-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `observation.schema.json`
- Title: PRAIN Observation
- Required (6): id, type, source, occurred_at, schema_version, payload_ref
- Fields (12): id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/observation-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `claim.schema.json`
- Title: PRAIN Claim
- Required (6): id, statement, kind, verification_status, created_at, schema_version
- Fields (13): id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/claim-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `goal.schema.json`
- Title: PRAIN Goal
- Required (7): id, description, status, priority, acceptance_criteria, version, created_at
- Fields (11): id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/goal-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `policy-decision.schema.json`
- Title: PRAIN PolicyDecision
- Required (7): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version
- Fields (8): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/policy-decision-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `event-envelope.schema.json`
- Title: PRAIN Event Envelope
- Required (7): event_id, event_type, occurred_at, producer, correlation_id, schema_version, payload
- Fields (10): event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/event-envelope-0.1.0.json`

### PRAIN_Phase0_v0.1.0 / `agent-manifest.schema.json`
- Title: PRAIN AgentManifest
- Required (6): agent_id, identity_version, role, capabilities, limitations, schema_version
- Fields (10): agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/agent-manifest-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `action-result.schema.json`
- Title: PRAIN ActionResult
- Required (6): id, action_request_id, execution_status, verification_status, occurred_at, schema_version
- Fields (10): id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/action-result-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `action-request.schema.json`
- Title: PRAIN ActionRequest
- Required (10): id, actor_id, capability, target, declared_side_effects, risk_level, policy_decision_ref, correlation_id, idempotency_key, schema_version
- Fields (13): id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/action-request-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `state-snapshot.schema.json`
- Title: PRAIN StateSnapshot
- Required (6): id, entity_type, version, updated_at, data, schema_version
- Fields (8): id, entity_type, version, updated_at, data, content_classification, retention_policy_ref, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/state-snapshot-0.2.0.json`

### PRAIN_Phase0_v0.2.0 / `observation.schema.json`
- Title: PRAIN Observation
- Required (6): id, type, source, occurred_at, schema_version, payload_ref
- Fields (12): id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/observation-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `claim.schema.json`
- Title: PRAIN Claim
- Required (6): id, statement, kind, verification_status, created_at, schema_version
- Fields (14): id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version, verification_exception_ref
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/claim-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `goal.schema.json`
- Title: PRAIN Goal
- Required (7): id, description, status, priority, acceptance_criteria, version, created_at
- Fields (11): id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/goal-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `policy-decision.schema.json`
- Title: PRAIN PolicyDecision
- Required (7): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version
- Fields (8): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/policy-decision-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `event-envelope.schema.json`
- Title: PRAIN Event Envelope
- Required (7): event_id, event_type, occurred_at, producer, correlation_id, schema_version, payload
- Fields (10): event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/event-envelope-0.1.0.json`

### PRAIN_Phase0_v0.2.0 / `trace-event.schema.json`
- Title: PRAIN TraceEvent
- Required (8): trace_id, span_id, event_id, timestamp, component, operation, outcome, schema_version
- Fields (11): trace_id, span_id, parent_span_id, event_id, timestamp, component, operation, outcome, policy_decision_ref, redaction_applied, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/trace-event-0.2.0.json`

### PRAIN_Phase0_v0.2.0 / `evidence.schema.json`
- Title: PRAIN Evidence
- Required (6): id, kind, source_ref, captured_at, integrity, schema_version
- Fields (9): id, kind, source_ref, captured_at, content_hash, integrity, classification, retention_policy_ref, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/evidence-0.2.0.json`

### PRAIN_Phase0_v0.2.0 / `agent-manifest.schema.json`
- Title: PRAIN AgentManifest
- Required (6): agent_id, identity_version, role, capabilities, limitations, schema_version
- Fields (10): agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/agent-manifest-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `action-request.schema.json`
- Title: PRAIN ActionRequest
- Required (10): id, actor_id, capability, target, declared_side_effects, risk_level, policy_decision_ref, correlation_id, idempotency_key, schema_version
- Fields (13): id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/action-request-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `action-result.schema.json`
- Title: PRAIN ActionResult
- Required (6): id, action_request_id, execution_status, verification_status, occurred_at, schema_version
- Fields (10): id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/action-result-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `agent-manifest.schema.json`
- Title: PRAIN AgentManifest
- Required (6): agent_id, identity_version, role, capabilities, limitations, schema_version
- Fields (10): agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/agent-manifest-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `claim.schema.json`
- Title: PRAIN Claim
- Required (6): id, statement, kind, verification_status, created_at, schema_version
- Fields (14): id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version, verification_exception_ref
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/claim-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `event-envelope.schema.json`
- Title: PRAIN Event Envelope
- Required (7): event_id, event_type, occurred_at, producer, correlation_id, schema_version, payload
- Fields (10): event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/event-envelope-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `evidence.schema.json`
- Title: PRAIN Evidence
- Required (6): id, kind, source_ref, captured_at, integrity, schema_version
- Fields (9): id, kind, source_ref, captured_at, content_hash, integrity, classification, retention_policy_ref, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/evidence-0.2.0.json`

### PRAIN_Phase0_v0.2.1 / `goal.schema.json`
- Title: PRAIN Goal
- Required (7): id, description, status, priority, acceptance_criteria, version, created_at
- Fields (11): id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/goal-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `observation.schema.json`
- Title: PRAIN Observation
- Required (6): id, type, source, occurred_at, schema_version, payload_ref
- Fields (12): id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/observation-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `policy-decision.schema.json`
- Title: PRAIN PolicyDecision
- Required (7): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version
- Fields (8): id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/policy-decision-0.1.0.json`

### PRAIN_Phase0_v0.2.1 / `state-snapshot.schema.json`
- Title: PRAIN StateSnapshot
- Required (6): id, entity_type, version, updated_at, data, schema_version
- Fields (8): id, entity_type, version, updated_at, data, content_classification, retention_policy_ref, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/state-snapshot-0.2.0.json`

### PRAIN_Phase0_v0.2.1 / `trace-event.schema.json`
- Title: PRAIN TraceEvent
- Required (8): trace_id, span_id, event_id, timestamp, component, operation, outcome, schema_version
- Fields (11): trace_id, span_id, parent_span_id, event_id, timestamp, component, operation, outcome, policy_decision_ref, redaction_applied, schema_version
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schema/trace-event-0.2.0.json`

### PRAIN_Architecture_v0.4.0 / `action-request.schema.json`
- Title: PRAIN Action Request
- Required (10): action_id, goal_id, plan_id, actor, action, target, input_digest, capability_ref, idempotency_key, requested_at
- Fields (15): action_id, goal_id, plan_id, actor, action, target, input_digest, capability_ref, idempotency_key, requested_at, deadline, preconditions, expected_postconditions, risk_class, policy_decision_ref
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.local/schemas/action-request-0.4.0.json`

### PRAIN_Architecture_v0.4.0 / `goal.schema.json`
- Title: PRAIN Goal
- Required (10): goal_id, revision, title, desired_outcome, owner, priority, status, acceptance_criteria, created_at, updated_at
- Fields (17): goal_id, revision, title, desired_outcome, owner, requester, priority, status, acceptance_criteria, constraints, depends_on, budget, deadline, created_at, updated_at, verification_ref, blocked_reason
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.local/schemas/goal-0.4.0.json`

### PRAIN_Architecture_v0.4.0 / `message-envelope.schema.json`
- Title: PRAIN Message Envelope
- Required (8): message_id, message_type, name, schema_version, created_at, producer, correlation_id, payload
- Fields (14): message_id, message_type, name, schema_version, created_at, producer, recipient, correlation_id, causation_id, tenant_id, idempotency_key, trace_context, provenance, payload
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.local/schemas/message-envelope-0.4.0.json`

### PRAIN_Distributed_Protocol_v0.5.0 / `action-command.schema.json`
- Title: PRAIN Action Command
- Required (8): command_id, idempotency_key, action_digest, target, action, expected_policy_version, retry_class, deadline
- Fields (9): command_id, idempotency_key, action_digest, target, action, expected_policy_version, retry_class, deadline, lease
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schemas/action-command-0.5.0.json`

### PRAIN_Distributed_Protocol_v0.5.0 / `execution-receipt.schema.json`
- Title: PRAIN Execution Receipt
- Required (7): receipt_id, command_id, status, attempt, observed_at, executor, evidence_refs
- Fields (9): receipt_id, command_id, status, attempt, observed_at, executor, error_code, evidence_refs, reconciliation
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schemas/execution-receipt-0.5.0.json`

### PRAIN_Distributed_Protocol_v0.5.0 / `message-envelope.schema.json`
- Title: PRAIN Message Envelope
- Required (9): message_id, message_type, schema_version, created_at, producer, correlation_id, tenant_id, payload, classification
- Fields (14): message_id, message_type, schema_version, created_at, producer, correlation_id, causation_id, tenant_id, aggregate, payload, provenance, trace, classification, expires_at
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.dev/schemas/message-envelope-0.5.0.json`

### PRAIN_v0.6 / `health-signal.schema.json`
- Title: PRAIN v0.6 HAL Health Signal
- Required (7): schema_version, signal_id, observed_at, scope, metric, status, source
- Fields (12): schema_version, signal_id, observed_at, scope, metric, value, unit, status, threshold_ref, source, evidence_refs, fresh_until
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.example/schemas/v0.6/health-signal.schema.json`

### PRAIN_v0.6 / `repair-proposal.schema.json`
- Title: PRAIN v0.6 HAL Repair Proposal
- Required (11): schema_version, proposal_id, created_at, target, observation_refs, change, bounds, rollout, success_metrics, rollback_conditions, expires_at
- Fields (12): schema_version, proposal_id, created_at, target, observation_refs, change, bounds, rollout, success_metrics, rollback_conditions, expires_at, status
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.example/schemas/v0.6/repair-proposal.schema.json`

### PRAIN_v0.6 / `semantic-message.schema.json`
- Title: PRAIN v0.6 Semantic Message
- Required (9): schema_version, message_id, message_type, created_at, producer, scope, epistemic_status, payload, provenance
- Fields (18): schema_version, message_id, correlation_id, causation_id, message_type, created_at, producer, scope, epistemic_status, aggregate, affected_dependencies, valid_until, confidence, payload, provenance, required_response, idempotency_key, trace_id
- `additionalProperties`: `False`; `$schema`: `https://json-schema.org/draft/2020-12/schema`; `$id`: `https://prain.example/schemas/v0.6/semantic-message.schema.json`

## Cross-version deltas by recurring schema name

### `action-request.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=13; required=10; fields: `id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version`
- **PRAIN_Phase0_v0.2.0**: fields=13; required=10; fields: `id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version`
- **PRAIN_Phase0_v0.2.1**: fields=13; required=10; fields: `id, actor_id, capability, target, input_ref, declared_side_effects, risk_level, policy_decision_ref, approval_ref, correlation_id, causation_id, idempotency_key, schema_version`
- **PRAIN_Architecture_v0.4.0**: fields=15; required=10; fields: `action_id, goal_id, plan_id, actor, action, target, input_digest, capability_ref, idempotency_key, requested_at, deadline, preconditions, expected_postconditions, risk_class, policy_decision_ref`

### `action-result.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=10; required=6; fields: `id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version`
- **PRAIN_Phase0_v0.2.0**: fields=10; required=6; fields: `id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version`
- **PRAIN_Phase0_v0.2.1**: fields=10; required=6; fields: `id, action_request_id, execution_status, output_ref, side_effects_observed, verification_status, verification_evidence_refs, error_code, occurred_at, schema_version`

### `agent-manifest.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=10; required=6; fields: `agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version`
- **PRAIN_Phase0_v0.2.0**: fields=10; required=6; fields: `agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version`
- **PRAIN_Phase0_v0.2.1**: fields=10; required=6; fields: `agent_id, identity_version, role, capabilities, limitations, model_adapter, memory_adapter, runtime_adapter, identity_claim_refs, schema_version`

### `claim.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=13; required=6; fields: `id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version`
- **PRAIN_Phase0_v0.2.0**: fields=14; required=6; fields: `id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version, verification_exception_ref`
- **PRAIN_Phase0_v0.2.1**: fields=14; required=6; fields: `id, statement, kind, subject_id, predicate, object_ref, evidence_refs, confidence, verification_status, valid_from, valid_until, created_at, schema_version, verification_exception_ref`

### `event-envelope.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=10; required=7; fields: `event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context`
- **PRAIN_Phase0_v0.2.0**: fields=10; required=7; fields: `event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context`
- **PRAIN_Phase0_v0.2.1**: fields=10; required=7; fields: `event_id, event_type, occurred_at, producer, correlation_id, causation_id, idempotency_key, schema_version, payload, trace_context`

### `evidence.schema.json`
- **PRAIN_Phase0_v0.2.0**: fields=9; required=6; fields: `id, kind, source_ref, captured_at, content_hash, integrity, classification, retention_policy_ref, schema_version`
- **PRAIN_Phase0_v0.2.1**: fields=9; required=6; fields: `id, kind, source_ref, captured_at, content_hash, integrity, classification, retention_policy_ref, schema_version`

### `goal.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=11; required=7; fields: `id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at`
- **PRAIN_Phase0_v0.2.0**: fields=11; required=7; fields: `id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at`
- **PRAIN_Phase0_v0.2.1**: fields=11; required=7; fields: `id, description, status, priority, owner_id, parent_goal_id, constraints, acceptance_criteria, version, created_at, updated_at`
- **PRAIN_Architecture_v0.4.0**: fields=17; required=10; fields: `goal_id, revision, title, desired_outcome, owner, requester, priority, status, acceptance_criteria, constraints, depends_on, budget, deadline, created_at, updated_at, verification_ref, blocked_reason`

### `message-envelope.schema.json`
- **PRAIN_Architecture_v0.4.0**: fields=14; required=8; fields: `message_id, message_type, name, schema_version, created_at, producer, recipient, correlation_id, causation_id, tenant_id, idempotency_key, trace_context, provenance, payload`
- **PRAIN_Distributed_Protocol_v0.5.0**: fields=14; required=9; fields: `message_id, message_type, schema_version, created_at, producer, correlation_id, causation_id, tenant_id, aggregate, payload, provenance, trace, classification, expires_at`

### `observation.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=12; required=6; fields: `id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels`
- **PRAIN_Phase0_v0.2.0**: fields=12; required=6; fields: `id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels`
- **PRAIN_Phase0_v0.2.1**: fields=12; required=6; fields: `id, type, source, occurred_at, received_at, schema_version, payload_ref, content_hash, confidence, provenance, correlation_id, labels`

### `policy-decision.schema.json`
- **PRAIN_Phase0_v0.1.0**: fields=8; required=7; fields: `id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref`
- **PRAIN_Phase0_v0.2.0**: fields=8; required=7; fields: `id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref`
- **PRAIN_Phase0_v0.2.1**: fields=8; required=7; fields: `id, action_request_id, decision, rule_refs, reason, decided_at, policy_version, approval_ref`

### `state-snapshot.schema.json`
- **PRAIN_Phase0_v0.2.0**: fields=8; required=6; fields: `id, entity_type, version, updated_at, data, content_classification, retention_policy_ref, schema_version`
- **PRAIN_Phase0_v0.2.1**: fields=8; required=6; fields: `id, entity_type, version, updated_at, data, content_classification, retention_policy_ref, schema_version`

### `trace-event.schema.json`
- **PRAIN_Phase0_v0.2.0**: fields=11; required=8; fields: `trace_id, span_id, parent_span_id, event_id, timestamp, component, operation, outcome, policy_decision_ref, redaction_applied, schema_version`
- **PRAIN_Phase0_v0.2.1**: fields=11; required=8; fields: `trace_id, span_id, parent_span_id, event_id, timestamp, component, operation, outcome, policy_decision_ref, redaction_applied, schema_version`

## Canonicalization recommendations (proposed, not approved)

1. Keep a stable canonical contract per concept and publish explicit adapters; do not merge schemas based on similar names alone.
2. Separate domain identity (`goal_id`, `action_id`, `command_id`, `receipt_id`) from transport envelope identity (`message_id`/`event_id`).
3. Define one canonical action lifecycle linking request → policy decision → command → receipt/result → verification evidence.
4. Define one canonical goal contract with revision/CAS semantics, owner/requester, dependencies, constraints, acceptance criteria and evidence-backed terminal state.
5. Keep semantic epistemic status/provenance in claim/message contracts; define promotion rules before a claim becomes authoritative state.
6. Add explicit compatibility metadata: `contract_family`, `contract_version`, `compatibility`, and migration reference in registry metadata (not necessarily in every payload).
7. Maintain golden positive/negative fixtures per contract version and migration tests across every supported adjacent version.

## Limits

This is a schema structure/field audit. It does not yet compare every nested property constraint, enum, pattern, numeric bound, `$ref`, or sample payload. That deeper constraint diff remains a v0.8 acceptance item.
