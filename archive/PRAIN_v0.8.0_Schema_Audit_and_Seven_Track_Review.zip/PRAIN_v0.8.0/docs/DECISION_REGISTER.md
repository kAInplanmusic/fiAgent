# Consolidated Decision Register — PRAIN through v0.6

| ID | Decision | Source lineage | Current status | Notes / remaining work |
|---|---|---|---|---|
| DEC-001 | PRAIN is an independent semantic framework, not a generic knowledge base or Hallerbans subsystem | Canonical project definition / Master Index | RETAINED | Host agents consume PRAIN through contracts |
| DEC-002 | P/R/A/I/N are five logical responsibilities, not necessarily five services | Canonical definition; v0.4; v0.6 D-0601 | RETAINED | Deployment boundaries are implementation choices |
| DEC-003 | A/Anima maintains explicit, inspectable, versioned self-model; identity is distributed across all five dimensions | Canonical definition; v0.4 identity; v0.6 lineage | RETAINED | Exact identity/principal/tenant model OPEN |
| DEC-004 | “Quantum-ready” means replaceable provider/compute interfaces, no quantum advantage claim | v0.2.1/v0.4/v0.5 | RETAINED | Provider contract to be specified before implementation |
| DEC-005 | Prefer UUIDv7 opaque identifiers | v0.2.1 decision register | RETAINED | Collision and clock rollback handling must not rely on time order alone |
| DEC-006 | Timestamps use UTC RFC3339 | v0.2.1 | RETAINED | Clock time is not authoritative ordering; aggregate versions are |
| DEC-007 | Delivery is at-least-once; consumers must be idempotent; no global exactly-once promise | v0.2.1/v0.4/v0.5/v0.6 | RETAINED | Idempotency scope and retention period OPEN |
| DEC-008 | Authoritative state uses versioning, updated timestamps and CAS | v0.2.1/v0.5/v0.6 | RETAINED | Per-aggregate authority matrix to be completed |
| DEC-009 | Evidence ledger is append-only with hash-chain lineage reference | v0.2.1/v0.4/v0.5/v0.6 | RETAINED | Signature format, key rotation and deletion/tombstone semantics OPEN |
| DEC-010 | Deny by default; least privilege; approvals bound to exact action; missing policy/capability means deny or defer | v0.2.1 policy model; v0.4 trust; v0.5/v0.6 | RETAINED | Principal/tenant and approval expiration contract OPEN |
| DEC-011 | Schema evolution uses SemVer | v0.2.1; v0.5/v0.6 | RETAINED | Compatibility matrix and migration protocol OPEN |
| DEC-012 | Strong consistency is scoped to authoritative records; derived projections may be eventual and must expose freshness | v0.5 D-0501+; v0.6 D-0604/0605 | RETAINED | Per-record class table OPEN |
| DEC-013 | Unknown action outcome is persisted and reconciled before retry; expired lease does not prove non-execution | v0.5/v0.6 | RETAINED | Adapter-specific reconciliation contracts OPEN |
| DEC-014 | Goal completion requires evidence for every required acceptance criterion | v0.2.1/v0.4/v0.5/v0.6 | RETAINED | Evidence sufficiency rules need typed criteria |
| DEC-015 | NATS JetStream and PostgreSQL are candidates, not mandatory dependencies | v0.4/v0.5 | RETAINED | No vendor/runtime commitment in Phase 0 |
| DEC-016 | SCF is a logical coordination capability, not necessarily a separate service | v0.6 | RETAINED | Interface contract remains to be completed |
| DEC-017 | HAL is supervisory, not a sixth core; it cannot grant permissions, alter hard ceilings, or rewrite live policy | v0.6 D-0603/D-0608 | RETAINED | Proposal/apply/rollback contract needs detailed acceptance |
| DEC-018 | Local autonomy is allowed only within declared scope and global invariants | v0.6 L0–L3 | RETAINED | Scope inheritance and escalation rules OPEN |
| DEC-019 | Use a modular-first architecture; do not prematurely microservice the design | v0.6 D-0609 | RETAINED as design guidance | Not a runtime mandate |
| DEC-020 | Biological/processor analogies must map to falsifiable mechanisms | v0.6 D-0610 | RETAINED | Avoid anthropomorphic or consciousness claims |
| DEC-021 | Existing artifacts must not be silently overwritten; every requirement is retained, extended, superseded, or open | Master Index / this consolidation | PROPOSED for user approval | Recommended governance rule |
| DEC-022 | Phase 0 remains open until the user explicitly accepts a complete closure record | Master Index / exit criteria | RETAINED | No runtime work before closure |

## Explicitly open decisions inherited from v0.6
1. Claim-type ontology and epistemic promotion rules.
2. Tenant and principal model.
3. Cryptographic signing and key rotation for evidence/messages.
4. Retention/deletion rules by data class, including derived projections, replicas, caches and backups.
5. SLOs for message lag, recovery time and verification latency.
6. Which bounded adaptations may be preapproved.
7. When group-level consensus is required for specific authoritative records.
8. Exact persistence and broker versions (must remain candidates until separately selected).
9. Idempotency-key scope and retention period.
10. Authoritative record-class matrix and conflict resolution ownership.
11. Compatibility windows and migration/rollback protocol for schemas.
12. Human approval lifecycle: principal, action digest, expiry, revocation, and evidence.
13. Knowledge-base item-level lineage and reconciliation against the formal specifications.
