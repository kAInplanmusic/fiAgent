# Knowledge-Base Crosswalk — JSON v0.1.0 and Interactive HTML

## Scope and status
The JSON source was parsed and its top-level structure inspected: `project`, `dimensions`, `cross_cutting`, `relations`, `sources`, `priority`. The HTML source was inspected for embedded data and execution structure; it contains an embedded `DB` object and local rendering logic. This is a structural and semantic first-pass crosswalk, not a claim that every source URL or every research claim has been externally revalidated.

## Legacy dimension mapping to canonical P/R/A/I/N

| Legacy knowledge-base ID | Legacy label | Canonical PRAIN dimension | Disposition | Reason / boundary |
|---|---|---|---|---|
| `senses` | Senses — Perception & Tools | P — Perception | Retain and rename in canonical model | Observations, multimodal input, tool interface and result verification belong primarily to perception. Authorization remains governed by policy, not perception itself. |
| `brain` | Brain — Cognition & Memory | R — Reason, with shared memory responsibilities | Retain, split responsibility conceptually | Reason covers interpretation, inference and planning. Memory is a cross-cutting substrate; persistent facts/self-model continuity also touch A. Do not treat the entire memory system as exclusively R. |
| `soul` | Soul — Identity & Governance | A — Anima for self-model/continuity; governance is cross-cutting | Split responsibility conceptually | Identity/continuity maps to A. Authorization, least privilege and policy enforcement are system-wide invariant responsibilities, not the exclusive property of A. Payment protocols remain optional integrations. |
| `will` | Will — Goals & Control | I — Intention | Retain and rename in canonical model | Goals, priorities, decomposition and acceptance criteria are I responsibilities. Execution policy and verification remain cross-cutting interfaces. |
| `body` | Body — Runtime & Infrastructure | N — Nerve for action/execution; runtime infrastructure is implementation substrate | Split responsibility conceptually | N is the authorized action/capability boundary, not synonymous with the OS, process supervisor, database or deployment topology. Those are replaceable implementation choices. |

## Cross-cutting groups

| Legacy ID | Existing meaning | Canonical treatment |
|---|---|---|
| `security` | Prompt injection, memory poisoning, tool misuse, privilege escalation, secret leakage, supply-chain risk, excessive agency | Cross-cutting invariant/policy domain. Enforced at input, memory, planning, execution and evidence boundaries. |
| `evidence` | Evidence quality, source classes, claim verification and numerical-claim scope | Semantic provenance and epistemic governance across P/R/A/I/N. |
| `feedback` | Evaluation of success, recovery, tool correctness, memory, cost, latency and goal adherence | Observability/evaluation plus HAL feedback; HAL may propose bounded adaptation but cannot authorize itself. |

## Relation crosswalk

| Existing relation | Retain? | Canonical interpretation |
|---|---|---|
| senses → brain (`feeds`) | Yes | P observations provide input to R; provenance and uncertainty must be preserved. |
| brain → will (`supports`) | Yes | R informs I planning; I's explicit goal/criteria remain authoritative for the task. |
| will → body (`controls`) | Yes, with guard | I can request action through N only after policy authorization; it does not bypass the policy gateway. |
| soul → body (`authorizes`) | Modify | A/self-identity is not itself the authorization engine. A principal/identity context is checked by the policy gateway before N executes. |
| soul → senses (`governs`) | Modify | Access policy is a cross-cutting policy boundary; A may carry identity context but does not unilaterally grant access. |
| body → brain (`persists`) | Yes, with guard | Infrastructure may persist state; only declared source-of-truth records are authoritative. |
| will → brain (`updates`) | Yes, with guard | Verified outcomes can inform memory; unverified model narration cannot be promoted to evidence. |
| body → senses (`exposes`) | Yes | Runtime adapters expose available sensors/tools; manifests declare capability, policy separately grants authority. |

## Claim-quality handling
The JSON already distinguishes several unsupported or overstated claims from better-supported design patterns (for example universal token-savings percentages, universal agent-OS claims, fixed goal-drift thresholds, and claims that identity/payment/TEE protocols replace local authorization). Preserve this epistemic discipline. These records are research notes, not architectural mandates.

For every claim/source pair, the eventual item-level audit should retain:
- stable claim ID and exact text;
- source ID/URL and source type;
- publication/version date and last checked date;
- evidence status, confidence and reason;
- applicability scope and known limitations;
- links to PRAIN requirements/decisions, if any;
- superseded/duplicate status without deleting history.

## Interactive HTML disposition
The HTML file is a presentation artifact with embedded data and rendering code. Its content should not be treated as a second independent source of truth. Reconcile the embedded `DB` against `PRAIN_Wissensdatenbank.json`; the JSON should be the canonical data source unless the user explicitly chooses otherwise. Keep UI logic separate from semantic records. No browser persistence mechanism such as localStorage or fetch calls was found in the initial literal scan; this is a preliminary code inspection, not a full security audit.

## Open follow-up
1. Enumerate every claim in each dimension and map each `sourceId` to the exact source record.
2. Validate all URLs and source freshness where current public evidence is needed.
3. Compare HTML embedded DB byte/semantic equality with the JSON dataset.
4. Decide whether the legacy labels remain as aliases or are migrated to P/R/A/I/N identifiers.
5. Give each knowledge-base item a disposition: `architecture_requirement`, `research_evidence`, `implementation_candidate`, `historical_note`, `duplicate`, or `obsolete`.
