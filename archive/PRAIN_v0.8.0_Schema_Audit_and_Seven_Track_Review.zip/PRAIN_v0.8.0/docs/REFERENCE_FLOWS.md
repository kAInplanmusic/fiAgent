# Reference Flows — Specification-Level Pseudocode

These are normative-intent examples, not executable implementation code. They do not choose a language, framework, operating system or database.

## 1. Safe goal execution
```text
function advance_goal(goal_id):
    goal = read_authoritative_goal(goal_id)
    require goal.version is current
    require goal.status in {accepted, active, blocked}
    plan = reasoner.propose_plan(goal, current_evidence, capability_manifests)
    validate_plan_scope(plan, goal.acceptance_criteria)
    for action in plan.actions:
        digest = canonical_digest(action.parameters, action.target, action.scope)
        decision = policy_gateway.authorize(
            principal=current_principal,
            action_digest=digest,
            policy_version=current_policy_version,
            scope=action.scope
        )
        if decision != ALLOW:
            record_denial_or_defer(action, decision)
            stop_or_replan_without_bypass()
        result = nerve.dispatch_with_idempotency(action, digest)
        if result.status == UNKNOWN_OUTCOME:
            persist_unknown_outcome(result)
            reconciliation = reconcile_external_effect(action, result)
            if reconciliation == PROVEN_NOT_EXECUTED:
                retry_only_if_deadline_and_policy_still_valid()
            elif reconciliation == PROVEN_EXECUTED:
                record_receipt_and_verify_effect()
            else:
                mark_manual_review_and_do_not_blind_retry()
    for criterion in goal.required_acceptance_criteria:
        evidence = gather_evidence(criterion)
        verification = independent_verifier.evaluate(criterion, evidence)
        persist_verification(criterion, verification)
        if verification != PASS:
            goal.status = verifying_or_blocked
            return goal
    CAS_update_goal(goal.version, status=completed, evidence_refs=all_verified_refs)
```

## 2. Semantic claim ingestion
```text
function ingest_claim(candidate):
    validate_schema(candidate)
    if missing_provenance(candidate) or out_of_scope(candidate):
        quarantine_or_reject_with_reason(candidate)
        return
    preserve(candidate.provenance, candidate.source_time, candidate.epistemic_status)
    existing = find_related_claims(candidate.subject, candidate.predicate, candidate.scope)
    conflicts = compare_claims(existing, candidate)
    if conflicts:
        store_candidates_without_silent_overwrite(existing, candidate)
        classify_conflict_and_request_evidence_or_authority()
    else:
        store_as_candidate_or_observation(candidate)
    promote_to_confirmed_only_if_declared_evidence_rule_passes()
    invalidate_only_dependent_projections_and_plans()
```

## 3. HAL bounded repair
```text
function evaluate_health(signal):
    if signal.missing_or_stale:
        publish_health_unknown()
        return
    if signal.repeats_same_incident and cooldown_active:
        suppress_duplicate_repair()
        return
    proposal = HAL.propose_repair(signal, declared_bounds, repair_budget)
    require proposal.scope within HAL_write_scope
    require proposal does_not_change_policy_or_hard_ceiling
    require proposal has expected_effects, risk, rollback, verification_plan
    decision = policy_gateway.authorize_repair(proposal.digest)
    if decision != ALLOW:
        record_defer_or_deny(proposal)
        return
    if proposal.requires_human_approval:
        wait_for_action_bound_approval_or_expire()
    apply_smallest_safe_change_or_canary()
    verify_against_predeclared_acceptance_conditions()
    if failed_or_worse:
        rollback_if_safe()
        record_failure_and_escalate()
    else:
        record_evidence_and_close_repair()
```

## 4. Concurrent authoritative update
```text
function update_authoritative_record(record_id, expected_version, patch):
    current = read_source_of_truth(record_id)
    if current.version != expected_version:
        return CONFLICT(current.version, current.updated_at)
    validate_scope_authority_and_policy(patch)
    next = apply_patch_without_mutating_history(current, patch)
    commit_if_version_matches(expected_version, next.version=expected_version+1)
    publish_outbox_event_in_same_transaction()
    return COMMITTED(next.version)
```

## 5. Deletion and derived data
```text
function process_deletion_request(subject, data_class):
    decision = validate_retention_and_legal_hold(subject, data_class)
    if blocked_by_required_retention:
        restrict_access_and_record_reasoned_hold()
        return
    create_deletion_tombstone_with_scope_and_version()
    enumerate_authoritative_records_and_all_derived_locations()
    delete_or_redact_per_policy(projections, caches, embeddings, replicas, exports)
    preserve only permitted minimal audit evidence
    verify deletion propagation and record outstanding unreachable replicas
    retry idempotently until all required targets acknowledge or escalate
```

## 6. Invariants
- Unknown execution outcome is not equivalent to failure.
- Policy denial cannot be bypassed by R, A, I, N, SCF or HAL.
- A model response is not evidence merely because it is confident.
- A projection cannot overwrite its source of truth.
- Goal completion requires evidence for each required criterion.
- Repair proposal and repair execution are separate authority stages.
- A deletion request must account for derived data, not just the primary row.
