# Consolidated Conformance Matrix (Specification Only)

A test definition is not evidence that a runtime passed. Existing test results are version-scoped and must not be generalized to the full architecture.

| Test family | Source tests | Consolidated obligation | Phase-0 artifact status |
|---|---|---|---|
| Schema shape / required fields | v0.2.1 schema vectors; v0.4/v0.5/v0.6 schemas | Validate every schema, reference, enum and example | Partially checked historically; rerun whole archive needed |
| Provenance / epistemic status | v0.2.1 semantic tests; v0.6 tests 1,3,4 | Missing provenance rejected/quarantined; hypotheses never silently become facts | Contract present; promotion rules open |
| Delivery / idempotency | v0.2.1; v0.5; v0.6 test 7 | Duplicate message/command does not duplicate state transition/side effect | Specified; full canonical scope open |
| Ordering / concurrency | v0.5 conformance; v0.6 tests 6,8,29 | Stale writes conflict visibly; reordering converges or records conflict | Specified; per-record matrix open |
| Authorization / revocation | v0.2.1 policy; v0.5; v0.6 tests 9,12 | Exact action digest reauthorized at execution boundary; stale cache cannot bypass revocation | Specified; principal/tenant model open |
| Unknown outcome / recovery | v0.5 recovery; v0.6 tests 20–21 | Reconcile before retry; lease expiry not proof of non-execution | Specified |
| Goal completion | v0.2.1 goal/evidence; v0.4 control loop; v0.6 tests 24–25 | Each required criterion has accepted evidence and verifier decision | Specified; typed evidence rules open |
| HAL stability | v0.6 tests 14–19 | Hysteresis, cooldown, budgets, rollback, unknown stale health | Specified; preapproval classes open |
| Tenant isolation | v0.6 test 11 | Cross-tenant message/state leakage rejected and audited | Test specified; tenant model open |
| Projection rebuild / freshness | v0.5 consistency; v0.6 test 22 | Rebuild at cursor reproduces canonical state and exposes freshness | Specified |
| Poison messages / backpressure | v0.5 conformance; v0.6 test 23 | Quarantine poison input without blocking unrelated work | Specified |
| Deletion / retention | v0.2.1 decisions; v0.6 test 30 | Apply retention/redaction/deletion to projections, replicas and caches | Incomplete: policy matrix open |
| Schema migration | v0.5 test 26; v0.6 compatibility note | Reject incompatible schema or use declared migration path | Requirement present; migration protocol open |
| Restore/replay | v0.5 tests; v0.6 test 28 | Preserve evidence lineage, dedup and authority after restore | Specified at intent level |
| Knowledge-base lineage | Master archive | Every item maps to canonical ID/source/status | Not yet executed item-by-item |
| Traceability consistency | This v0.7 package | All requirements have source, disposition, test/acceptance criterion or open decision | Matrix drafted; user review required |

## Minimum negative cases before Phase-0 acceptance
1. Missing or forged provenance.
2. Hypothesis promoted without required evidence.
3. Duplicate action after timeout and worker restart.
4. Stale policy cache after permission revocation.
5. Tenant mismatch in envelope, projection, or action.
6. CAS conflict with two concurrent updates.
7. HAL proposal attempting to increase its own permissions/resource ceiling.
8. Goal completion with one missing/invalid evidence reference.
9. Deletion propagation failure on an offline replica.
10. Incompatible schema arriving during rolling upgrade.
11. Expired lease with external side effect already performed.
12. Restore/replay causing a duplicate external side effect.
