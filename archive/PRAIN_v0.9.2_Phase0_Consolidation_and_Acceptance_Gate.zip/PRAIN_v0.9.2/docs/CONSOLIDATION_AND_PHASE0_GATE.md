# Consolidation and Phase-0 Acceptance Gate

**Version:** v0.9.2
**Status:** Review candidate; Phase 0 is NOT CLOSED.
**Scope:** Consolidate workstreams 1–3 and define acceptance criteria. No runtime implementation.

## 1. Integrated findings

### 1.1 Schema contracts
- The archive contains multiple contract generations, not one backward-compatible schema line.
- v0.2.1 is a broad structured baseline; v0.4 materially changes goal/action shapes; v0.5 separates action command/dispatch from execution receipt; v0.6 adds semantic-message and HAL contracts.
- Root-level `additionalProperties: false` means undocumented additions may fail validation. Changes must be versioned and migrated deliberately.
- Schema `$id` namespaces vary (`prain.dev`, `prain.local`, `prain.example`). A canonical registry URI strategy remains undecided.
- The static field inventory is useful but does not yet constitute a complete recursive semantic diff of every nested constraint, reference, enum, pattern, numeric bound, and conditional schema.

### 1.2 Knowledge base
- `PRAIN_Wissensdatenbank.json` and the embedded HTML database have zero recursive value differences after normalizing object-key order, according to the existing comparison report.
- This proves data parity only, not factual accuracy, source quality, security of the HTML, or semantic consistency with the newer architecture.
- The JSON should be the canonical authoring source; HTML should be generated from it or checked against it.
- The project purpose must define PRAIN independently of Hallerbans. Hallerbans is a possible consumer, not a dependency or identity-defining component of PRAIN.
- Legacy dimension mapping: senses→P; brain→R with memory cross-cutting; soul→A for self-model/continuity but not authorization; will→I; body→N for authorized execution.

### 1.3 Claim semantics
- Epistemic status, verification status, confidence, validity time, and record lifecycle are independent axes.
- Confidence alone must never promote a claim to `verified` or authorize an action.
- Contradictions create a conflict set and preserve both claims; they do not silently overwrite evidence.
- Provenance, evidence, counterevidence, scope, method/version, and transition history must be explicit for material claims.
- The nine-state epistemic vocabulary in `CLAIM_SEMANTICS_AND_EPISTEMIC_LIFECYCLE.md` remains a proposal until approved.

## 2. Decision status legend
- **BASELINE**: explicitly established in the current PRAIN specification history.
- **PROPOSED**: a recommended normative design, not yet user-approved.
- **OPEN**: requires a decision or evidence.
- **DEFERRED**: may be left to implementation only if that deferral is explicitly accepted and does not undermine a Phase-0 invariant.

## 3. Phase-0 gate matrix

| Gate | Acceptance evidence | Current status | Closure condition |
|---|---|---|---|
| G1 Artifact lineage | Inventory/checksum/version for all artifacts through v0.6 | Partial | Inventory reconciled against all source archives and manifests |
| G2 Knowledge item mapping | Every JSON item mapped to canonical concept/decision/requirement or explicitly retired | Partial | Item-level disposition complete; Hallerbans dependency corrected in canonical source |
| G3 HTML parity | Extracted embedded DB compared deterministically with canonical JSON | Reported pass for data parity | Repeatable test or documented deterministic verification; HTML logic separately reviewed if relied on |
| G4 Schema recursive diff | Types, required, enums, refs, patterns, bounds, composition, additionalProperties | Partial | Full recursive diff plus migration fixtures for breaking changes |
| G5 Canonical claim model | Claim shape, epistemic states, transitions, evidence/provenance rules | Proposed | User approves vocabulary and transition/verification rules |
| G6 Goal/action lifecycles | Goal state machine, action dispatch, receipt, verification and unknown outcome | Partial | Cross-version canonical lifecycle and mappings approved |
| G7 Identity and tenancy | Principal, tenant, actor, delegation, lineage, revocation | Open | Contract and isolation invariants specified and reviewed |
| G8 Authority/consistency | Record-class source-of-truth and consistency matrix | Partial | Every authoritative record class has owner, consistency and conflict policy |
| G9 Policy/approval | Action-scoped approvals, expiry, revocation race and policy re-check | Partial | Normative lifecycle and negative tests defined |
| G10 Data lifecycle | Classification, retention, redaction, deletion, replicas/projections/backups | Open | Per-class lifecycle matrix and deletion evidence defined |
| G11 Evidence integrity | Hashing/signatures, signer identity, key rotation/recovery, verification scope | Open | Threat model and key lifecycle contract reviewed |
| G12 HAL boundaries | Allowed adaptations, budgets, approval thresholds, rollback, no privilege escalation | Partial | Adaptation catalogue and policy-enforcement invariants approved |
| G13 Distributed recovery | Duplicate/reorder/crash/partition/timeout-after-side-effect/replay cases | Partial | Every required scenario maps to an expected state and conformance test |
| G14 Conformance coverage | Each invariant maps to positive and relevant negative tests | Partial | Matrix complete; schema and deterministic reference tests pass |
| G15 Versioning/migration | Compatibility policy and reversible migration plan | Partial | Version/compatibility policy covers producer-consumer skew and rollback |
| G16 Explicit approval | Versioned Phase-0 closure record | Not started | User explicitly approves after reviewing unresolved decisions and evidence |

## 4. Blocking decisions before closure
1. Approve or revise claim epistemic vocabulary and transition rules.
2. Approve principal/tenant/delegation and identity lineage model.
3. Approve authoritative record-class/consistency matrix.
4. Approve data classification, retention, deletion and derived-data propagation rules.
5. Approve human approval/revocation lifecycle and action re-check behavior.
6. Approve evidence integrity and cryptographic key lifecycle boundaries.
7. Approve HAL adaptation classes and hard ceilings.
8. Decide which SLOs must be architecture-level constraints and which can remain implementation-specific.
9. Decide whether provider/broker/database selection is explicitly deferred.

## 5. Recommended closure sequence
A. Complete the recursive schema diff and migration fixtures.
B. Finish source-item dispositions and make JSON the canonical knowledge source.
C. Review/approve the proposed claim model.
D. Close identity, authority, privacy, approval, evidence and HAL contracts.
E. Complete the failure/conformance crosswalk and run spec-level validation.
F. Publish a decision review containing all open items, impacts, and proposed defaults.
G. Create the Phase-0 closure record only after explicit user approval.

## 6. Explicit non-goals
- No runtime/framework/OS implementation.
- No production security claim based solely on written controls.
- No inference that a schema or pseudocode test proves a nonexistent runtime.
- No assumption of quantum advantage or consciousness.
- No automatic Phase-1 start from publication of v0.9.2 or v0.99.0.
