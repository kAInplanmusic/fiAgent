# Decision review table — PRAIN v0.9.2

This table intentionally distinguishes inherited baseline from proposed design and user decisions. `PROPOSED` is not approval.

| ID | Topic | Status | Current baseline / proposal | Needed for Phase 0? |
|---|---|---|---|---|
| D-0601 | P/R/A/I/N dimensions | BASELINE | Keep five functional dimensions; do not treat them as five required services | No new decision; preserve |
| D-0602 | Multiscale organization | BASELINE | Local units, cooperation groups, global semantic system, invariant boundary | Preserve |
| D-0603 | HAL position | BASELINE | Supervisory layer, not a sixth core dimension | Preserve |
| D-0604 | Global meaning vs synchronization | BASELINE | Global semantic coherence does not imply global synchronization of all data | Preserve |
| D-0605 | Authority by record class | BASELINE / INCOMPLETE | Declare source of truth and consistency per record class | Yes: complete matrix |
| D-0606 | Claim provenance and epistemic state | BASELINE / INCOMPLETE | Semantic claims require provenance and epistemic status | Yes: approve detailed ontology |
| D-0607 | Unknown action outcome | BASELINE | Unknown outcome is first-class; reconcile before retry | Preserve and test |
| D-0608 | HAL permission ceiling | BASELINE | HAL cannot grant permissions, alter hard ceilings, or self-modify live policy | Preserve and operationalize |
| D-0609 | Initial architecture granularity | BASELINE | Prefer modular design over premature microservices | Implementation choice later |
| D-0610 | Biological/processor analogy | BASELINE | Must map to falsifiable mechanisms | Preserve |
| D-0911 | Claim epistemic vocabulary | PROPOSED | observed, reported, inferred, hypothesized, corroborated, verified, disputed, refuted, unknown | Yes |
| D-0912 | Separate verification/confidence/validity/lifecycle | PROPOSED | Orthogonal fields; confidence is not verification | Yes |
| D-0913 | JSON canonical authoring source | PROPOSED | HTML generated from JSON or deterministically checked against it | Yes for knowledge governance |
| D-0914 | Hallerbans independence | REQUIRED CORRECTION | PRAIN purpose must be independent; Hallerbans is a possible consumer | Yes |
| D-0915 | Schema ID namespace | OPEN | Choose stable canonical URI/registry strategy or explicitly defer | Yes, at least defer explicitly |
| D-0916 | Principal/tenant/delegation | OPEN | Define principal, tenant, actor, delegation scope, expiry, revocation | Yes |
| D-0917 | Record-class authority matrix | OPEN | Define authoritative source, consistency, conflict, projection rules | Yes |
| D-0918 | Data lifecycle and deletion | OPEN | Retention, redaction, deletion/tombstones across replicas, caches, backups | Yes |
| D-0919 | Approval/revocation race | OPEN | Action-bound, time-bounded approval; recheck at execution boundary | Yes |
| D-0920 | Evidence crypto/key lifecycle | OPEN | Hashes do not prove signer identity; define signing and rotation | Yes |
| D-0921 | HAL allowed adaptations | OPEN | Preapproved catalogue, budgets, canary, rollback and escalation | Yes |
| D-0922 | SLOs | OPEN | Set architecture-level floors or mark implementation-specific with rationale | Decision on boundary required |
| D-0923 | Broker/database/provider | DEFERRED CANDIDATE | Keep adapters replaceable; defer concrete selection until implementation phase | May be deferred explicitly |
| D-0924 | Quantum-ready meaning | BASELINE / NEEDS CONTRACT | Replaceable compute/provider abstraction, no presumed quantum advantage | Define interface criteria; implementation later |

## Recommended default dispositions
1. Accept D-0911 and D-0912 as a candidate unless review finds a concrete semantic conflict.
2. Accept D-0913 and D-0914 as governance corrections.
3. Keep infrastructure provider choices deferred; record the deferral rather than silently selecting products.
4. Do not close Phase 0 while D-0916 through D-0921 lack normative contracts.
5. Preserve all legacy fields and source values during migration; add explicit mapping metadata instead of destructive rewriting.
