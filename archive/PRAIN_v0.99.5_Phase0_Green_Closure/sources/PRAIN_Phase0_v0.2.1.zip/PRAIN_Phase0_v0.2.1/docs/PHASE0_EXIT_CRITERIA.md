# Phase 0 — Exit-Kriterien und Abnahme v0.2.1

**Status: Phase 0 (Architektur- und Vertragsdefinition) abgeschlossen.**
**Nicht enthalten:** produktive Runtime, echte Event-Bus-Integration, persistenter State Store,
produktives Policy Gateway, deployment-spezifische Security- und Datenschutzprüfung.

## Abnahmeumfang
Phase 0 liefert ein versioniertes, framework-neutrales Architekturmodell, JSON-Schemas,
Testvektoren, ausführbare Referenztests für Kerninvarianten, Entscheidungsregister und
Schnittstellenverträge für Phase 1. Die Referenztests prüfen die Semantik anhand kleiner
deterministischer Modelle; sie ersetzen keine Integrationstests der späteren Runtime.

## Exit-Kriterien
- [x] Alle JSON-Schemas laden als JSON Schema Draft 2020-12.
- [x] Kernobjekte definieren IDs, Schema-Versionen bzw. Zeit-/Versionssemantik, soweit relevant.
- [x] Verifizierte Claims benötigen Evidenzreferenzen oder eine explizite dokumentierte Ausnahme (Schema/contract).
- [x] Aktive Goals benötigen mindestens ein Akzeptanzkriterium.
- [x] ActionRequest verlangt Policy-Referenz, Capability, Idempotenz- und Korrelations-ID.
- [x] Ausführungsstatus und Verifikationsstatus sind getrennt modelliert.
- [x] Referenztest für idempotente Wiederholungszustellung.
- [x] Referenztest für veraltete Versionsupdates.
- [x] Referenztest: fehlende Capability/Policy oder unbekannter Risikograd führt nicht zu Allow.
- [x] Referenztest für Secret-Redaction vor Serialisierung/Persistenz.
- [x] Append-only Korrekturmodell und namespaced externe IDs als Referenztests.
- [x] Schema-Kompatibilitätsregel für Breaking Changes dokumentiert und getestet.
- [x] Reproduzierbare Tests erzeugen maschinenlesbare Schema-Ergebnisse.

## Ausdrückliche Grenze
Ein grüner Phase-0-Lauf bedeutet **Vertrags-/Referenzkonformität**, nicht Produktionsreife.
Für Phase 1 müssen dieselben Invarianten gegen echte Implementierungen, Storage,
Retry-Verhalten, konkurrierende Writes, Policy-Konfigurationen und Redaction-Ausgaben
als Integrationstests erneut geprüft werden.
