"""Deterministic executable checks for Phase 0 architectural invariants.

These are contract/reference tests, not a production event bus, state store,
policy gateway, or privacy service. Run with: python -m unittest discover -s tests
"""
import hashlib
import json
import unittest
from copy import deepcopy


def policy_decision(capability, policy_present, risk_level):
    # Conservative contract model: absence of required inputs never allows.
    if not capability or risk_level not in {"low", "medium", "high", "critical"}:
        return "defer"
    if not policy_present:
        return "deny"
    if risk_level in {"high", "critical"}:
        return "require_approval"
    return "allow"


def redact(value, secrets):
    if isinstance(value, dict):
        return {k: redact(v, secrets) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v, secrets) for v in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, "[REDACTED]")
    return value


class ReferenceStateStore:
    def __init__(self):
        self.items = {}

    def create(self, entity_id, data):
        if entity_id in self.items:
            raise ValueError("ALREADY_EXISTS")
        self.items[entity_id] = {"version": 1, "data": deepcopy(data)}

    def compare_and_swap(self, entity_id, expected_version, data):
        current = self.items[entity_id]
        if current["version"] != expected_version:
            raise ValueError("VERSION_CONFLICT")
        self.items[entity_id] = {
            "version": current["version"] + 1,
            "data": deepcopy(data)
        }
        return deepcopy(self.items[entity_id])


class ReferenceIdempotencyLedger:
    def __init__(self):
        self.results = {}
        self.side_effect_count = 0

    def execute_once(self, consumer, key, operation):
        compound = (consumer, key)
        if compound in self.results:
            return self.results[compound]
        result = operation()
        self.side_effect_count += 1
        self.results[compound] = result
        return result


class Phase0SemanticsTests(unittest.TestCase):
    def test_execution_completed_does_not_imply_verified(self):
        result = {"execution_status": "completed", "verification_status": "unverified"}
        self.assertEqual(result["execution_status"], "completed")
        self.assertNotEqual(result["verification_status"], "verified")

    def test_duplicate_delivery_does_not_repeat_side_effect(self):
        ledger = ReferenceIdempotencyLedger()
        operation = lambda: {"status": "done"}
        first = ledger.execute_once("consumer-a", "idem-1", operation)
        second = ledger.execute_once("consumer-a", "idem-1", operation)
        self.assertEqual(first, second)
        self.assertEqual(ledger.side_effect_count, 1)

    def test_idempotency_is_scoped_by_consumer(self):
        ledger = ReferenceIdempotencyLedger()
        op = lambda: "ok"
        ledger.execute_once("consumer-a", "same-key", op)
        ledger.execute_once("consumer-b", "same-key", op)
        self.assertEqual(ledger.side_effect_count, 2)

    def test_stale_version_is_rejected(self):
        store = ReferenceStateStore()
        store.create("goal-1", {"status": "active"})
        store.compare_and_swap("goal-1", 1, {"status": "blocked"})
        with self.assertRaisesRegex(ValueError, "VERSION_CONFLICT"):
            store.compare_and_swap("goal-1", 1, {"status": "succeeded"})
        self.assertEqual(store.items["goal-1"]["version"], 2)

    def test_missing_policy_or_capability_never_allows(self):
        self.assertNotEqual(policy_decision("read_file", False, "low"), "allow")
        self.assertNotEqual(policy_decision("", True, "low"), "allow")
        self.assertNotEqual(policy_decision("read_file", True, "unknown"), "allow")

    def test_high_risk_action_requires_approval(self):
        self.assertEqual(policy_decision("delete_resource", True, "critical"), "require_approval")

    def test_secret_redaction_happens_before_serialization(self):
        source = {"message": "token=abc123", "nested": ["Bearer xyz789"]}
        safe = redact(source, ["abc123", "xyz789"])
        persisted = json.dumps(safe)
        self.assertNotIn("abc123", persisted)
        self.assertNotIn("xyz789", persisted)
        self.assertIn("[REDACTED]", persisted)

    def test_evidence_correction_is_append_only(self):
        ledger = [{"id": "ev-1", "claim": "x", "status": "original"}]
        correction = {"id": "ev-2", "supersedes": "ev-1", "status": "corrected"}
        ledger.append(correction)
        self.assertEqual(len(ledger), 2)
        self.assertEqual(ledger[0]["status"], "original")
        self.assertEqual(ledger[1]["supersedes"], "ev-1")

    def test_external_ids_are_namespaced(self):
        a = ("crm-a", "123")
        b = ("crm-b", "123")
        self.assertNotEqual(a, b)

    def test_breaking_schema_change_requires_major_version(self):
        def is_major_bump(old, new):
            return int(new.split(".")[0]) > int(old.split(".")[0])
        self.assertTrue(is_major_bump("0.2.0", "1.0.0"))
        self.assertFalse(is_major_bump("0.2.0", "0.3.0"))

    def test_hash_chain_detects_modified_previous_entry(self):
        first = {"id": "ev-1", "payload": "alpha", "prev_hash": None}
        first["hash"] = hashlib.sha256(json.dumps(
            {k: v for k, v in first.items() if k != "hash"},
            sort_keys=True).encode()).hexdigest()
        altered = dict(first, payload="tampered")
        altered_hash = hashlib.sha256(json.dumps(
            {k: v for k, v in altered.items() if k != "hash"},
            sort_keys=True).encode()).hexdigest()
        self.assertNotEqual(first["hash"], altered_hash)


if __name__ == "__main__":
    unittest.main(verbosity=2)
