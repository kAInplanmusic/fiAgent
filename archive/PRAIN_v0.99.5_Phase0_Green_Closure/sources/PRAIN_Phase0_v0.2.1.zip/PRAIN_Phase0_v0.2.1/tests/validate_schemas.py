"""Validate all PRAIN JSON Schemas and their declared test vectors.

Requires: Python 3.10+, jsonschema
"""
import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
vectors = json.loads((HERE / "test-vectors.json").read_text(encoding="utf-8"))
results = []

# Check every schema file, not only schemas referenced by a test vector.
schemas = {}
for path in sorted((ROOT / "schemas").glob("*.schema.json")):
    schema = json.loads(path.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    schemas[path.name] = schema

for case in vectors["cases"]:
    schema = schemas[case["schema"]]
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(case["instance"]), key=lambda e: list(map(str, e.path)))
    actual_valid = not errors
    passed = actual_valid == case["valid"]
    results.append({
        "id": case["id"],
        "expected_valid": case["valid"],
        "actual_valid": actual_valid,
        "passed": passed,
        "errors": [e.message for e in errors]
    })

out = {
    "schema_version": vectors["version"],
    "schemas_checked": len(schemas),
    "vectors_checked": len(results),
    "passed": sum(r["passed"] for r in results),
    "failed": sum(not r["passed"] for r in results),
    "results": results
}
print(json.dumps(out, ensure_ascii=False, indent=2))
raise SystemExit(1 if out["failed"] else 0)
