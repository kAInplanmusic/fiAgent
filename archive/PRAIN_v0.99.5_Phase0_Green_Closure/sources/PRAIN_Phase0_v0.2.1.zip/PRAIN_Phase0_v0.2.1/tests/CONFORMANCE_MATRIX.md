# PRAIN Conformance Matrix v0.2.1

| ID | Requirement | Test class | Phase 0 reference result |
|---|---|---|---|
| C-001 | All schemas load as Draft 2020-12 | static validator | automated |
| C-002 | Goal requires acceptance criteria | negative schema vector | automated |
| C-003 | ActionRequest requires PolicyDecision ref | negative schema vector | automated |
| C-004 | Unknown policy enum rejected in strict mode | negative schema vector | automated |
| C-005 | Completed execution is not verified success | semantic reference test | automated |
| C-006 | Duplicate idempotency key does not repeat side effect | reference model | automated |
| C-007 | Stale state version rejected | reference model | automated |
| C-008 | No capability / no policy => no allow | policy reference model | automated |
| C-009 | Secret redaction before trace persistence | redaction reference test | automated |
| C-010 | Evidence corrections are append-only | ledger reference test | automated |
| C-011 | External IDs retain namespace | reference test | automated |
| C-012 | Breaking schema changes require major version | compatibility rule test | automated |

A conformance run emits machine-readable JSON from `validate_schemas.py`.
Reference tests are deterministic architectural checks, not production runtime integration tests.
