# Implementation Plan — v0.5.0

## Phase 1 — Contracts first
- Freeze envelope, command lifecycle, aggregate versioning, error taxonomy, and consistency classes.
- Generate types and validation from JSON Schemas.
- Add contract compatibility tests to CI.
**Exit:** malformed/unsupported messages are rejected; every command has correlation and idempotency metadata.

## Phase 2 — Transactional core
- PostgreSQL schema for aggregates, inbox, outbox, idempotency records, leases, policy decisions, receipts, and verification records.
- CAS mutations and transactionally committed outbox.
- Rebuildable projections with explicit source watermark.
**Exit:** race, crash, replay, and duplicate tests pass.

## Phase 3 — Durable transport and worker runtime
- Add a durable message transport adapter (NATS JetStream is a candidate, not a hard dependency).
- Consumer inbox/deduplication; bounded retries and dead-letter handling.
- Worker capability registration and heartbeat.
**Exit:** broker outage and consumer restart tests pass.

## Phase 4 — Safe execution and recovery
- Action digest, idempotency key, policy recheck at dispatch, lease epoch/fencing token.
- Reconciliation API and explicit `unknown` state.
- Per-action retry class and deadline.
**Exit:** ambiguous timeout tests demonstrate no blind duplicate side effect.

## Phase 5 — Goal orchestration and evidence
- Goal/plan state machine; dependency graph; verification records tied to evidence.
- Completion transition guarded by acceptance criteria and expected version.
**Exit:** no incomplete or inconclusive goal can become completed.

## Phase 6 — Multi-host and resilience
- Deploy independent worker pools on multiple hosts.
- Add network partition, host loss, clock skew, and broker/database failover drills.
- Establish measured SLO, RPO, RTO, capacity limits.
**Exit:** runbooks and measured recovery behavior match declared targets.

## Phase 7 — Scale only from evidence
- Benchmark throughput and tail latency.
- Add replicas, partitioning, cache, autoscaling, or multi-zone topology only when metrics justify them.
- Keep semantic projections eventually consistent and version-aware.
**Exit:** documented bottleneck and demonstrated improvement.

## Explicit non-goal
No phase claims globally linearizable behavior for every subsystem under arbitrary partition while preserving availability. Strong guarantees apply only to scoped authoritative operations backed by suitable transactional/consensus mechanisms.
