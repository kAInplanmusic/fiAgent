# Distributed Protocol Conformance Tests

A release is not conformant merely because unit tests pass. Test the invariants under failure.

## Required test groups
1. Duplicate delivery: deliver the same event 2–100 times; state changes once.
2. Out-of-order delivery: deliver aggregate version N+1 before N; stale state is not silently accepted.
3. Publisher crash: crash after database commit but before publish; outbox eventually publishes.
4. Consumer crash: crash before commit and after commit/before ack; replay is safe.
5. CAS race: two writers use the same expected version; at most one wins.
6. Broker outage: writes either commit with outbox and publish later or fail explicitly; no silent event loss.
7. Database outage: side-effecting operations fail closed when authority is unavailable.
8. Lease expiry: old worker resumes after reassignment; stale fencing token cannot mutate protected resource.
9. Ambiguous remote timeout: state becomes `unknown`; no blind duplicate side effect.
10. Policy revocation: queued command is re-authorized at dispatch; stale approval cannot authorize changed input.
11. Projection lag: stale graph/vector index cannot override authoritative state.
12. Schema incompatibility: unsupported major version is rejected/quarantined.
13. Clock skew: correctness does not depend on wall-clock ordering.
14. Goal verification: missing, inconclusive, or contradictory evidence prevents `completed`.
15. Recovery: restore from backup and replay events without duplicate side effects.
16. Tenant isolation: messages, reads, leases, and projections cannot cross tenant boundaries.
17. Poison message: bounded retries then dead-letter/quarantine with actionable diagnostics.
18. Backpressure: overloaded consumers apply bounded queues and admission control instead of unbounded memory growth.

## Release gates
- All safety invariants pass in automated tests.
- Fault injection covers the failure cases relevant to deployment.
- Recovery time and data-loss objectives are measured, not guessed.
- Dashboards expose queue age, retry count, unknown outcomes, consumer lag, CAS conflicts, policy denials, and verification failures.
- A runbook exists for every state requiring operator intervention.
