# Execution, Leases, Retries, and Recovery

## 1. Lease semantics
A lease gives a worker temporary permission to attempt an assignment. It is not proof that the worker is the only process still executing after a pause or network partition. Leases include owner, epoch/fencing token, issued time, expiry, and heartbeat.

## 2. Fencing
For mutable resources, each new lease increments a monotonically increasing fencing token. The resource or adapter rejects writes with older tokens. If the target cannot enforce fencing, the adapter must use a target-specific idempotency/reconciliation strategy or mark the action as unsafe to retry.

## 3. Retry classification
- `safe_retry`: proven idempotent or read-only operation
- `retry_after_reconcile`: side effect may have happened; inspect target first
- `never_auto_retry`: irreversible/non-idempotent operation without reliable reconciliation
- `policy_recheck`: authorization or policy version changed
- `manual_or_operator_review`: insufficient evidence to safely continue

Retries use bounded exponential backoff with jitter, attempt budgets, deadline, and error taxonomy. Never retry indefinitely.

## 4. Ambiguous outcome
When a timeout occurs after dispatch:
1. persist `unknown` and the attempt ID;
2. do not assume the action failed;
3. query the target using operation ID/idempotency key if supported;
4. reconcile external state and attach evidence;
5. either record succeeded/failed or leave unresolved and escalate;
6. only retry if the action-specific policy says it is safe.

## 5. Cancellation
Cancellation prevents new work and requests cooperative cancellation of running work. It does not imply an already dispatched external side effect was reversed. Report cancellation request, executor acknowledgement, and any compensation as separate facts.

## 6. Compensation
A compensating action is a new action, not time travel. It requires its own policy decision, idempotency key, evidence, and verification. Compensation may fail and must be observable.

## 7. Goal completion
A goal is completed only when:
- every mandatory acceptance criterion has a verification record;
- each verification points to evidence and verifier/version;
- no required criterion is `unknown` or inconclusive;
- final state transition wins its expected-version CAS.
