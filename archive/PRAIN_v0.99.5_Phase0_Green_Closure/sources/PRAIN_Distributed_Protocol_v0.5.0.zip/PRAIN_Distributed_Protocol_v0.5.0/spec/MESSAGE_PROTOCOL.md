# PRAIN Message Protocol

## 1. Message classes
- `command`: request an authorized action
- `event`: immutable fact that a state transition or observation occurred
- `query`: ask for information without causing a side effect
- `response`: answer a query or command acceptance request
- `receipt`: report execution status and evidence references
- `control`: heartbeat, lease renewal, drain, cancellation, or health state

## 2. Envelope contract
Every message includes:
- `message_id`: globally unique opaque identifier
- `message_type`: one of the classes above
- `schema_version`: semantic version of the payload contract
- `created_at`: UTC RFC 3339 timestamp
- `producer`: node/service identity
- `correlation_id`: end-to-end workflow/request ID
- `causation_id`: preceding message ID, when applicable
- `tenant_id`: explicit tenant/security boundary
- `aggregate`: aggregate type, ID, and version where applicable
- `payload`: typed message data
- `provenance`: source and trust metadata
- `trace`: trace/span context
- `classification`: data sensitivity category
- `expires_at`: optional expiry for time-bounded requests

No credentials, API keys, or raw secrets belong in the envelope or evidence payload.

## 3. Delivery semantics
Baseline: durable at-least-once delivery. Duplicates are expected.
- Producers use a transactional outbox: authoritative state transition and outbox record commit in one database transaction.
- Consumers use an inbox/deduplication table keyed by `(consumer_id, message_id)` and commit it with their local state change.
- Event transport acknowledgement occurs only after durable consumer handling, or after durable enqueue to the consumer's own processing store.
- Retrying delivery does not imply retrying the underlying external action.
- Ordering is guaranteed only within explicitly defined aggregate partitions, not globally.

## 4. Command lifecycle
`created -> authorized -> accepted -> dispatched -> running -> succeeded | failed | unknown | cancelled`

Additional `reconciling` status is used after an ambiguous outcome. `accepted` means the system durably accepted responsibility, not that execution started. `succeeded` means the executor reported success; only a verifier can establish goal-level completion.

## 5. Idempotency
Every command that can cause a side effect carries:
- `idempotency_key`
- canonical `action_digest`
- target/resource identity
- policy decision reference/version
- expiry/deadline where relevant

The same key with a different action digest must be rejected as a conflict. If a remote target lacks idempotency support, PRAIN must query/reconcile its state before any retry that could duplicate a side effect.

## 6. Schema evolution
Use SemVer:
- patch: compatible clarification or optional metadata
- minor: backward-compatible optional fields/variants
- major: incompatible shape/meaning change

Consumers must reject unsupported major versions and quarantine malformed messages. Never silently reinterpret a payload with a different meaning.

## 7. Security
Authenticate service identities; authorize every command; use tenant-scoped routing and storage; validate payloads at boundaries; cap payload size; redact secrets before persistence; and record policy decision references for side effects.
