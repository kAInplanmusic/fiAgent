# State, Transactions, and Conflict Handling

## 1. Source of truth
Each record type has one declared authoritative store and writer protocol. Search/vector/graph projections are derived and rebuildable. Do not create two independent authorities for the same invariant.

## 2. Transactional outbox
When a transaction changes an authoritative aggregate, write:
1. the aggregate mutation,
2. the next aggregate version,
3. an outbox event,
4. any idempotency/result record
in one transaction. A publisher repeatedly delivers unsent outbox rows. Delivery may duplicate; consumers deduplicate.

## 3. Optimistic concurrency
A mutation states `expected_version`. The write succeeds only if current version equals expected version. Otherwise return a typed conflict containing current version and a safe current snapshot/reference. Never auto-overwrite.

## 4. Conflict resolution
Classify conflicts:
- `stale_write`: caller used an old version; reload and re-evaluate
- `concurrent_goal_change`: re-plan dependent workflow
- `policy_changed`: re-authorize against current policy
- `duplicate_idempotency_key`: return existing outcome if digest matches; reject if digest differs
- `projection_lag`: wait/rebuild projection; do not modify authority
- `split_brain_suspected`: stop unsafe writes and reconcile with authoritative quorum/store
- `semantic_contradiction`: preserve both claims with provenance and mark unresolved until adjudicated

Automatic merge is allowed only for explicitly commutative fields with a documented merge function. Never merge authorization, identity, goal status, or external side-effect records by generic last-write-wins.

## 5. Read modes
Every API declares one of:
- `authoritative`: current authoritative transaction view
- `bounded_stale`: projection may lag; response includes version/freshness
- `snapshot`: consistent point-in-time view with a declared watermark
- `eventual`: no freshness guarantee beyond explicit metadata

Policy checks and irreversible action preconditions use authoritative reads.

## 6. Global invariants
If a rule spans multiple aggregates (for example "only one active owner for a resource"), enforce it with a database constraint/transaction or a consensus-backed coordination mechanism. Do not simulate a global invariant by checking several caches and hoping the answer stays true.

## 7. Deletion and retention
Deletion must propagate to source records, derived projections, caches, embeddings, backups according to documented retention policy, and exports where applicable. Keep only the minimum legally/operationally required tombstone/audit metadata.
