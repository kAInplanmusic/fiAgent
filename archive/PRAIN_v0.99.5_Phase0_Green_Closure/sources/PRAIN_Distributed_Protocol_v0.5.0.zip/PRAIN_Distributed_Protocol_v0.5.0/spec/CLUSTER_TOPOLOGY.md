# Cluster Topology and PRAIN Cores

## 1. Logical cores
P — Perception: normalize observations and preserve provenance/uncertainty.
R — Reason: interpret, infer, compare, and plan.
A — Anima: maintain inspectable, versioned self-model and continuity data.
I — Intention: own goal contracts, priorities, dependencies, and acceptance criteria.
N — Nerve: execute authorized work through capability adapters.

These are logical responsibilities, not mandatory one-process-per-letter services. Every core may have multiple replicas; worker pools can scale independently.

## 2. Shared fabric
- identity and capability registry
- durable message transport
- authoritative transactional state
- policy gateway
- evidence ledger
- trace/metrics/logging
- schema registry or versioned contract repository

## 3. Control versus data plane
Control plane owns goal state, scheduling, policy decisions, leases, and workflow transitions. Data plane performs ingestion, reasoning workloads, tool execution, indexing, and verification. Data-plane workers cannot self-authorize actions.

## 4. Scheduling
A task declares required capabilities, resource envelope, data classification, deadline, locality constraints, retry class, and policy requirements. Scheduler selects only healthy eligible workers. Load is a signal, not an authorization grant. Prefer locality when it reduces data movement without violating policy.

## 5. Failure domains
Do not colocate every replica in one failure domain and call it highly available. Define node, zone, provider, database, and message-broker failure assumptions explicitly. Use quorum-backed coordination only where needed; understand that quorum systems may refuse writes without quorum.

## 6. Progressive deployment
Stage A: modular single deployment with strict contracts.
Stage B: separate worker processes and durable bus.
Stage C: multiple hosts and fault-injection tests.
Stage D: redundant control plane and storage with documented quorum/failover.
Stage E: autoscaling and multi-zone/multi-provider only when measured requirements justify it.

## 7. Avoid premature complexity
Do not introduce Kubernetes, multi-region consensus, or a service mesh solely because the architecture is distributed. First prove protocol invariants and operational recovery. Keep adapters replaceable.
