# PRAIN Consistency Model

## 1. Why "perfect global consistency" is not a valid engineering target
A distributed system can experience network partitions, process crashes, delayed messages, duplicate delivery, clock skew, and ambiguous remote outcomes. During a partition, a system cannot both guarantee uninterrupted writes everywhere and guarantee a single globally agreed state. PRAIN therefore defines explicit consistency domains and behavior under uncertainty.

## 2. Consistency classes

### C0 — Strongly consistent authoritative state
Use transactional writes and compare-and-swap (CAS) for:
- goal lifecycle and goal version
- policy/approval records
- execution intent and idempotency records
- capability ownership/leases where a single owner is required
- schema and protocol activation state

A successful write means the authoritative store committed it. It does not mean downstream consumers have already processed the corresponding event.

### C1 — Ordered per-aggregate state
Events for one aggregate (for example one goal or action) carry a monotonically increasing aggregate version. Consumers reject stale versions, buffer gaps when practical, and request replay/snapshot if a gap cannot be repaired.

Do not claim a global total order across unrelated aggregates unless a specific consensus-backed log is introduced and its cost accepted.

### C2 — Eventual derived state
May be eventually consistent:
- semantic/graph projections
- embedding/vector indexes
- search indexes
- analytics and dashboards
- cached capability summaries
- read replicas

Each derived result must expose source version or `as_of` metadata. A consumer must not treat a stale projection as an authoritative policy decision or final verification.

### C3 — Best-effort observations
External signals, telemetry, and untrusted source observations may be duplicated, delayed, missing, or contradictory. Preserve source, event time, ingest time, confidence/uncertainty, and provenance.

## 3. Required invariants
1. A goal has one authoritative current version.
2. A policy denial cannot be bypassed by a stale cache.
3. A command is not considered completed because it was published to a bus.
4. A receipt records what the executor knows, not what the planner hopes happened.
5. `unknown` is a valid and persistent outcome.
6. A goal cannot become `completed` without evidence-backed verification of every required acceptance criterion.
7. Derived projections never overwrite authoritative records.
8. A retry cannot create a second side effect if the target supports idempotency; otherwise the action must reconcile before retry.
9. Timeouts and lease expiry do not prove non-execution.
10. Conflicting writes are surfaced as conflicts, not silently merged unless a domain-specific merge rule is explicit.

## 4. Partition policy
Each operation declares a partition mode:
- `fail_closed`: reject/defer if authoritative policy/state cannot be reached
- `read_only_stale_ok`: allow a clearly marked stale read
- `queue_until_reconnected`: durably queue a non-side-effecting or safely idempotent request
- `local_independent`: permit only when no global uniqueness or shared invariant is involved

Side effects, approvals, identity/security mutations, and goal completion default to `fail_closed`.

## 5. Clocks
Use UTC RFC 3339 timestamps for diagnostics, not as the sole concurrency mechanism. Use aggregate versions, database transactions, and explicit causal references for correctness. Wall-clock ordering does not establish causality.
