# Consistency, Authority, and Conflict

## 1. Consistency is declared per record type

| Record class | Required model | Rule |
|---|---|---|
| Authorization / policy decision | Authoritative check at action boundary | No action based only on a stale local copy |
| Tenant / principal identity | Strong uniqueness and scope enforcement | No cross-tenant inference or write |
| Goal definition and acceptance criteria | Versioned authoritative aggregate | Plan must bind to goal version |
| External action status | Durable receipt plus reconciliation | Unknown is a first-class status |
| Evidence ledger | Append-only authoritative records | Corrections append; they do not silently erase |
| Semantic projection / cache | Eventual consistency | Must expose source version and freshness |
| Hypotheses / interpretations | Multi-hypothesis | Conflicting candidates can coexist |
| Resource allocation | Local optimization within global ceilings | Enforce ceiling at reservation/action boundary |
| Search index / summary | Rebuildable derived state | Never overwrite canonical records |
| Telemetry | Best-effort with freshness bounds | Missing data is not equivalent to healthy |

## 2. Authority registry

Every authoritative record type declares:
- canonical owner/service or aggregate;
- validation rule;
- concurrency mechanism;
- allowed writers;
- version strategy;
- evidence requirements;
- conflict resolver/escalation path;
- retention and redaction requirements.

If authority is not declared, a write that would affect global truth must be denied or deferred.

## 3. Conflict categories

- `projection_lag` — local copy is behind.
- `hypothesis_disagreement` — interpretations differ; preserve candidates.
- `source_disagreement` — independent sources conflict.
- `concurrent_write` — compare-and-swap/version race.
- `policy_conflict` — requested transition violates current policy.
- `execution_ambiguous` — external effect may or may not have occurred.
- `lineage_gap` — claim lacks enough provenance to validate.
- `dependency_drift` — a premise changed after plan generation.

## 4. Resolution policy

- Never use generic last-write-wins for semantic claims.
- Prefer source-specific authority and evidence, not model popularity or recency alone.
- If evidence is insufficient, preserve `unknown` and request more evidence.
- Recompute derived claims and plans when their dependency versions change.
- A conflict resolution must record resolver, rationale, input versions, and evidence.
- Policy revocation invalidates pending actions immediately at the authorization boundary.
- Conflicting non-authoritative hypotheses do not block unrelated work unless they affect a required dependency or safety invariant.

## 5. Versioned plans

A plan binds to:
- goal ID and goal version;
- dependency claim IDs and versions;
- policy version or policy reference;
- capability versions;
- expiry/deadline;
- acceptance criteria.

Before a consequential action, revalidate any dependency that could change authorization, external reality, or irreversible outcome. Do not require a full global refresh for unrelated claims.
