# Semantic Coordination Protocol

## 1. Message semantics

Every cross-unit message should say not only *what content* is being sent, but also:
- who produced it and under which capability/model version;
- what scope it applies to;
- whether it is an observation, hypothesis, confirmed claim, refutation, command, receipt, or reconciliation request;
- which evidence supports it;
- which versions and dependencies it assumes;
- when it was observed, issued, and considered stale;
- what response or decision is expected.

Transport delivery is not semantic acceptance. A delivered message may be rejected, deferred, or kept only as a hypothesis.

## 2. Message categories

- `observation` — sourced input about an observed state.
- `hypothesis` — provisional interpretation or prediction.
- `claim` — assertion with epistemic status and evidence links.
- `invalidation` — marks dependent projections/plans as stale.
- `command` — requests an action; it is not itself authorization.
- `receipt` — records an execution transition or outcome.
- `reconciliation_request` — requests resolution of a conflict or ambiguous action.
- `health_signal` — describes observed health, drift, load, or quality.
- `repair_proposal` — proposes a bounded repair/adaptation.
- `verification_result` — reports criterion-level verification.

## 3. Ordering and deduplication

- At-least-once delivery is acceptable; consumers must be idempotent.
- Use `message_id` for message identity and `idempotency_key` for side-effecting commands.
- `aggregate_id` and `aggregate_version` provide per-aggregate ordering/version gates.
- A causation/correlation chain links messages to goals, plans, actions, and evidence.
- Out-of-order messages are not automatically discarded: validate their version and apply, retain, or reconcile explicitly.
- Use transactional outbox/inbox where state changes and message publication must not diverge.
- Schema evolution must be explicit and backward-compatibility tested.

## 4. Scope and routing

A message has a scope (`unit`, `group`, `global`, or named resource scope), audience/recipient, and dependency tags. Route to subscribers whose declared dependencies intersect the message's affected dependencies. Do not broadcast raw internal reasoning by default; publish structured conclusions and evidence references needed by collaborators.

## 5. Conflict protocol

1. Detect same-entity/same-time claims that are incompatible, or version races.
2. Classify: stale projection, independent hypotheses, source disagreement, concurrent authoritative write, policy conflict, or execution ambiguity.
3. Preserve both claims and their provenance; do not silently overwrite.
4. Determine authority and required evidence for the record type.
5. Recompute if derived dependencies changed.
6. Request evidence or adjudication if still unresolved.
7. Apply a versioned resolution and retain the conflict record and rationale.

## 6. Trust and epistemic status

Suggested epistemic values:
- `observed`
- `hypothesis`
- `supported`
- `confirmed`
- `refuted`
- `unknown`

Status is not a generic confidence score. A high-confidence model output is not automatically confirmed. Promotion requires the evidence policy for the relevant claim type.

## 7. Operational defaults

- bounded retries with backoff and jitter;
- deadline and expiry for commands;
- dead-letter queue for poison messages;
- replay with deterministic/idempotent handlers;
- clock timestamps for audit, logical versions for ordering;
- clock skew must not determine authoritative ordering by itself;
- messages that lack schema, scope, provenance, or authorization context are rejected or quarantined.
