# Homeostasis & Adaptation Layer (HAL)

## 1. Purpose

HAL is the system-wide feedback and bounded adaptation capability. It monitors whether PRAIN remains within declared operating envelopes and whether decisions produce expected effects.

HAL is **not** a sixth P/R/A/I/N core, not a self-authorizing agent, and not a mechanism for uncontrolled self-modification.

## 2. Responsibilities

### Homeostasis
Monitor:
- resource consumption and quotas;
- queue depth, delivery lag, retries, dead letters;
- worker availability and lease churn;
- projection freshness and invalidation backlog;
- unresolved conflict count/age;
- evidence coverage and verification latency;
- goal progress, stalled goals, and repeated failed plans;
- model/tool quality signals and drift.

### Feedback
Compare expected and observed effects. Record the hypothesis behind a change, the measurement window, baseline, success metric, and rollback condition.

### Adaptation
Within a versioned policy envelope, HAL may propose or perform bounded actions such as:
- shifting eligible work among workers;
- scaling concurrency within quotas;
- refreshing or rebuilding derived projections;
- changing cache TTL within allowed bounds;
- requesting a second evaluator or additional evidence;
- pausing a repeatedly failing workflow;
- selecting a previously approved provider/model fallback.

### Repair
Detect and initiate:
- replay of safely idempotent messages;
- reconstruction of derived projections from canonical records;
- resumption of workflows from durable checkpoints;
- reconciliation of ambiguous external actions;
- quarantine of poison messages;
- restoration of missing dependency links where source evidence exists.

### Evolution
Model, prompt, policy, schema, or planner changes are treated as versioned releases:
- propose → offline evaluation → conformance tests → staged rollout → monitor → retain/rollback.
No silent mutation of live policy or canonical identity state.

## 3. Hard limits

HAL MUST NOT:
- grant or expand its own permissions;
- bypass the policy gateway;
- increase hard resource ceilings;
- mark a goal complete without criterion-level evidence;
- rewrite or delete authoritative evidence to make metrics look healthy;
- promote a hypothesis to confirmed solely because it improves a metric;
- repeat a side-effecting action when outcome is unknown without reconciliation;
- change policy, schemas, model versions, or action capabilities without the declared approval path.

## 4. Control policy

Every adaptation is a `repair_proposal` with:
- target and scope;
- observed signal and evidence;
- proposed change and expected effect;
- blast-radius estimate;
- applicable policy and resource bounds;
- rollout mode;
- success metrics and stop/rollback conditions;
- expiry and maximum attempt count.

Possible disposition: `accept`, `reject`, `defer`, `require_approval`, `rollback`.

## 5. Stability requirements

Avoid feedback oscillation with:
- hysteresis thresholds;
- cooldown periods;
- rate limits and maximum concurrent adaptations;
- canary/staged rollout for risky changes;
- explicit rollback criteria;
- bounded retry and repair budgets;
- separation of measurement from the mechanism being optimized where practical.

HAL must report when it lacks enough signal to act. Unknown health is not healthy health.

## 6. HAL operating modes

- `observe_only` — collect and diagnose; no mutations.
- `bounded_auto_repair` — only preapproved, reversible, low-blast-radius repairs.
- `approval_required` — propose but wait for an authorized decision.
- `degraded_safe_mode` — reduce concurrency and suspend nonessential risky actions.
- `recovery` — reconcile state and rebuild derived projections under strict limits.

Mode changes are logged and policy-checked. A degraded mode must not accidentally become a route to broader permissions.
