# Identity, Continuity, and Lineage

## 1. Identity is distributed across P/R/A/I/N

No single dimension is the sole source of identity. A/Anima maintains an explicit, inspectable, versioned self-model and continuity record, while identity also depends on perception history, reasoning commitments, intentions, and authorized capabilities.

This is a software identity model, not a claim of consciousness.

## 2. Separate durable information from active interpretation

Keep distinct:
- **source records:** raw observations, user instructions, external receipts, and signed/otherwise verifiable evidence;
- **semantic claims:** normalized assertions derived from sources;
- **hypotheses:** interpretations and predictions;
- **self-model:** current declared capabilities, boundaries, preferences, version, and continuity links;
- **plans:** intent bound to goal and dependency versions;
- **projections:** rebuildable indexes, summaries, and caches.

Never conflate a summary with its source or a model-generated explanation with verified evidence.

## 3. Lineage contract

A semantic claim should be traceable to:
- source/evidence IDs;
- producer and producer version;
- transformation or inference method/version;
- relevant timestamps and validity interval;
- parent claims and dependency versions;
- epistemic status and confidence representation;
- supersession/refutation links where applicable.

A missing lineage edge is a quality defect and may block promotion to an authoritative claim.

## 4. Controlled change

Self-model changes are proposed as versioned deltas:
1. state the old and proposed values;
2. attach evidence or explicit owner instruction;
3. validate against invariant and policy rules;
4. apply using compare-and-swap;
5. record the new version and the reason;
6. invalidate only dependent projections and plans.

No component may silently rewrite prior identity versions. Corrections preserve lineage.

## 5. Repair and retention

Canonical records are append-only where auditability requires it. Derived indexes and caches may be rebuilt. Privacy and retention rules still apply: immutable auditability must not become a pretext for retaining data beyond a lawful or declared retention period. Redaction, deletion, and tombstone semantics must be defined per data class, including derived projections and replicas.
