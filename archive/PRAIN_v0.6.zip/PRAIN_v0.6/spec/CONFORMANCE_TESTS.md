# v0.6 Conformance and Fault-Injection Tests

A runtime claiming v0.6 conformance must run these tests against its actual state store, transport, scheduler, policy gateway, and adapters. Passing schema validation alone is insufficient.

## Semantic coordination
1. Missing provenance is rejected or quarantined.
2. Out-of-scope message does not mutate local authoritative state.
3. Hypothesis disagreement preserves both candidates.
4. A confirmed claim cannot be promoted from model confidence alone.
5. Dependency invalidation marks only affected projections/plans stale.
6. Stale aggregate version causes explicit conflict, not silent overwrite.
7. Message duplicate is idempotent.
8. Reordered messages converge or produce a visible conflict without data loss.

## Consistency and policy
9. Revoked permission blocks action at the execution boundary even if a worker cache is stale.
10. A plan generated against an obsolete goal version must revalidate before a consequential action.
11. Tenant-scoped message cannot leak into another tenant's projection.
12. Unknown authority for a global write results in deny/defer.
13. Resource ceiling is enforced at reservation/action boundary.

## HAL stability
14. Repeated identical health signals do not cause unbounded scaling or repair loops.
15. Cooldown/hysteresis prevents threshold oscillation.
16. HAL cannot expand permissions or resource ceilings.
17. A failed canary triggers the declared rollback path.
18. HAL reports unknown health when telemetry is missing or stale.
19. Repair budget exhaustion stops retries and escalates.

## Recovery and evidence
20. Crash after external side effect but before receipt yields `unknown_outcome`, then reconciliation.
21. Lease expiry does not cause blind duplicate side effect.
22. Projection rebuild reproduces canonical state at a specified cursor.
23. Poison message is quarantined and does not stall unrelated partitions.
24. Goal cannot complete while any required acceptance criterion lacks evidence.
25. Successful tool response with failed acceptance criterion does not complete the goal.
26. Schema incompatibility is rejected or routed through a declared migration.
27. Clock skew does not override aggregate version ordering.
28. Restore/replay preserves evidence lineage and idempotency.
29. Conflicting authoritative writes are visible and auditable.
30. Deletion/redaction policy is applied to derived projections and replicas as defined.

## Required test report

For every test: runtime build, configuration, seed/fixture, injected fault, expected invariant, observed result, logs/evidence references, and pass/fail. A test suite definition is not itself proof that a runtime passed it.
