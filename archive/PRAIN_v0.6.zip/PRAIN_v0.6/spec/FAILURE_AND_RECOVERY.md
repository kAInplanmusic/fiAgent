# Failure, Recovery, and Unknown Outcomes

## 1. Failure is part of the state model

Represent at least:
- `not_started`
- `queued`
- `running`
- `succeeded`
- `failed`
- `cancelled`
- `unknown_outcome`
- `reconciling`
- `blocked`

A transport timeout does not prove a command failed. A worker crash does not prove an external effect did not occur. A lease expiry is not proof of non-execution.

## 2. Safe execution sequence

1. Persist command intent and idempotency key.
2. Check current policy and relevant authoritative versions.
3. Record execution attempt and lease/fencing token.
4. Invoke capability adapter.
5. Persist receipt or mark outcome unknown.
6. If unknown, query/reconcile with the external system or evidence source.
7. Retry only if reconciliation establishes retry is safe under the command's retry class.
8. Verify acceptance criteria independently of tool transport success.

## 3. Recovery domains

- **Message recovery:** inbox dedupe, outbox replay, poison-message quarantine, bounded retries.
- **Projection recovery:** rebuild from canonical records and replay cursor; compare counts/checksums where applicable.
- **Workflow recovery:** resume from durable checkpoint; validate goal/dependency versions before continuing.
- **Action recovery:** reconcile external side effects before retry.
- **Semantic recovery:** reconstruct lineage and dependency graph; unresolved lineage becomes an explicit gap.
- **HAL recovery:** enter recovery mode, restrict risky adaptations, and produce a recovery report.

## 4. Fencing and leases

Leases are for coordination, not proof that a previous actor had no side effects. Use monotonically increasing fencing epochs where supported. External systems that do not support idempotency or fencing require explicit reconciliation and may require human approval for retries.

## 5. Degraded operation

When a global authority or policy gateway is unavailable:
- continue only local work that does not require that authority;
- do not execute actions requiring a fresh policy decision;
- mark dependent tasks blocked/deferred;
- preserve queued intent and evidence;
- recover with reconciliation, not blind replay.

## 6. Recovery acceptance

A recovery is complete only when:
- canonical records remain valid;
- message offsets/checkpoints are reconciled;
- projections are rebuilt or explicitly marked stale;
- ambiguous actions are reconciled or remain unknown;
- goal states are reverified;
- repair actions and their effects are recorded.
