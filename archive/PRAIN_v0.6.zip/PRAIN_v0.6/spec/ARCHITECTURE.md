# Architecture — Multiscale Semantic Coordination

## 1. System model

PRAIN is a **semantic control plane**. It preserves the relationship between what was observed, what is believed, what is intended, what is permitted, what was attempted, and what was verified.

### Four architectural planes

1. **Semantic plane** — typed entities, claims, relationships, provenance, uncertainty, temporal validity, and lineage.
2. **Coordination plane** — semantic messages, scopes, subscriptions, dependency invalidation, conflict detection, and reconciliation.
3. **Execution plane** — plans, capability adapters, bounded leases, idempotency, retries, and external action status.
4. **Invariant & evidence plane** — policy decisions, authoritative records, audit trail, receipts, acceptance criteria, and independent verification.

P/R/A/I/N operate across these planes. They are not mapped one-to-one to infrastructure services.

## 2. Organizational scales

### Scale L0 — Local unit
A model, worker, tool adapter, memory shard, or specialist process. It owns a bounded local state and can make progress without global agreement for every operation.

Local unit contract:
- declare capabilities and limits;
- label outputs with provenance, epistemic status, scope, and version;
- never promote its own hypothesis to global authoritative truth;
- obey global policy and resource envelopes;
- expose health and progress signals.

### Scale L1 — Cooperation group
A small set of units collaborating on a subgoal or bounded problem. It exchanges intermediate results and maintains a local semantic projection. It can resolve local disagreements when the relevant authority and evidence are within its scope.

Group contract:
- own a defined subgoal and dependency set;
- publish summarized results plus links to supporting evidence;
- detect disagreement and escalate unresolved authority conflicts;
- avoid broadcasting every low-value internal event globally.

### Scale L2 — Global semantic system
The shared semantic model and goal graph across groups. It tracks cross-group dependencies, source-of-truth declarations, global identity/version relationships, and conflicts that cross scopes.

Global does not mean every replica holds identical data at every moment. It means shared meaning is represented through stable contracts and explicit authority.

### Scale L3 — Invariant & control boundary
The narrow set of globally binding decisions: authorization, identity/tenant boundaries, resource ceilings, authoritative goal versions, and evidence-backed completion. This boundary must remain enforceable even when local projections are stale.

## 3. Semantic Coordination Fabric (SCF)

SCF is the coordination mechanism connecting the scales. It comprises:
- semantic message envelope;
- scope-aware routing/subscriptions;
- provenance and lineage;
- dependency-aware invalidation;
- conflict classification;
- selective synchronization;
- reconciliation requests and results;
- bounded replay and dead-letter handling.

SCF is a logical capability, not necessarily a standalone broker/service.

### Recipient decision
For every received message, a recipient chooses one of:
- `adopt` — update a local projection after validation;
- `retain_as_hypothesis` — preserve as a candidate belief, not authoritative fact;
- `recompute` — recompute dependent claims or plans;
- `request_evidence` — ask for supporting evidence;
- `raise_conflict` — register incompatible claims or versions;
- `ignore_out_of_scope` — message does not apply to this scope;
- `defer` — insufficient capability, freshness, or policy context.

Every decision records the reason and relevant version.

## 4. Selective synchronization

Use the least expensive synchronization model that preserves the required invariant.

- **Strong/authoritative check:** permissions, action approval, unique identity constraints, authoritative goal version, resource ceiling, and action status before retry.
- **Compare-and-swap / version gate:** updates to shared authoritative aggregates.
- **Eventual consistency:** derived semantic projections, search indexes, caches, summaries, and non-authoritative analytics.
- **Best-effort / freshness-bounded:** observations where delay is acceptable and uncertainty is explicit.
- **Multi-hypothesis:** interpretations and predictions when evidence is incomplete or ambiguous.

No global lock or consensus round is required for ordinary local reasoning. A global invariant is checked only where the action or state transition depends on it.

## 5. Feedback and control loop

1. Observe state and telemetry.
2. Normalize and attach provenance.
3. Compare actual state with declared bounds and expected effects.
4. Identify drift, failure, conflict, or inefficiency.
5. Generate a bounded proposal.
6. Validate proposal against policy and invariants.
7. Apply only permitted changes.
8. Verify effects and store evidence.
9. Update local projections and invalidate dependent results selectively.

The loop must include hysteresis, cooldowns, and rate limits where repeated adjustment could oscillate.

## 6. Reference topology

Recommended first deployment:
- one durable state store (e.g. PostgreSQL);
- transactional outbox/inbox and idempotent consumers;
- one event transport adapter (NATS JetStream is a candidate, not a mandatory dependency);
- one scheduler/lease manager;
- one policy gateway;
- one evidence ledger;
- local workers and group coordinators as modules/processes;
- HAL as a supervisory module with explicit write scopes.

Start as a modular monolith or a small number of processes. Split modules only after benchmarks show a need. Every transport and model provider should be replaceable behind interfaces.

## 7. Boundaries

- A projection is never the source of truth for the record it projects.
- HAL is not an authorization authority.
- A model output is not automatically evidence.
- A successful tool response is not necessarily task success.
- An expired lease is not proof that an external side effect did not happen.
- No single unit can silently rewrite another unit's lineage or erase audit history.
