# Implementation Plan — v0.6

## Stage 0 — Freeze contracts
- Adopt v0.5 message/action/receipt invariants where still applicable.
- Validate v0.6 schemas and publish compatibility notes.
- Declare source of truth, writer authority, versioning, and retention for every record type.
**Exit:** contract review complete; schema compatibility tests green.

## Stage 1 — Durable semantic state
- PostgreSQL or equivalent transactional store.
- Versioned canonical aggregates and compare-and-swap.
- Evidence ledger and lineage edges.
- Transactional outbox/inbox and idempotent consumers.
**Exit:** crash/replay/duplicate tests pass; no projection can overwrite canonical state.

## Stage 2 — Semantic Coordination Fabric
- Message envelope, scope-aware routing, dependency tags.
- Local semantic projections with freshness metadata.
- Conflict registry and reconciliation workflow.
- Dead-letter and replay controls.
**Exit:** ordering, duplicate, scope, conflict, and invalidation tests pass.

## Stage 3 — Execution and invariant boundary
- Policy gateway as sole authorization decision point.
- Capability registry and adapters.
- Idempotency keys, leases/fencing, explicit unknown outcome.
- Goal criteria and independent verification.
**Exit:** revoked-policy, ambiguous-outcome, and evidence-gate tests pass.

## Stage 4 — HAL observe-only
- Health signals, resource envelopes, freshness checks, stalled-goal detection.
- Dashboards/structured reports and bounded diagnostics.
- No autonomous mutations initially.
**Exit:** useful detection precision measured; missing telemetry never reported as healthy.

## Stage 5 — Bounded repair
- Rebuild projections, replay idempotent messages, resume checkpoints.
- Reconcile ambiguous actions.
- Repair budgets, cooldowns, audit records, escalation paths.
**Exit:** fault injection passes; no blind retry or unbounded loop.

## Stage 6 — Controlled adaptation
- Versioned proposals, approval path, canary, metrics, rollback.
- Start with reversible workload routing and cache refresh.
- Keep model/policy/schema evolution outside auto-repair unless separately approved.
**Exit:** canary rollback and oscillation tests pass under load.

## Stage 7 — Multi-group scaling
- Add group coordinators only when measured workload needs them.
- Define partition ownership and cross-group dependency policy.
- Test partial network partition, delayed delivery, and group recovery.
**Exit:** documented service objectives and conformance report.

## Recommended first deployment
A modular monolith/small-process deployment is the default. Keep interfaces replaceable. NATS JetStream and PostgreSQL are candidate technologies, not architectural requirements. Do not start by deploying a large microservice cluster.
