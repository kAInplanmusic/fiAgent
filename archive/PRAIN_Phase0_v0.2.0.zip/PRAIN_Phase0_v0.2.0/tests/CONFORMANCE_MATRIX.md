# PRAIN Conformance Matrix v0.2.0

| ID | Requirement | Test class | Expected |
|---|---|---|---|
| C-001 | Schemas parse as JSON Schema Draft 2020-12 | static | all schema files load |
| C-002 | Goal requires acceptance criteria | negative schema | empty criteria rejected |
| C-003 | ActionRequest requires PolicyDecision ref | negative schema | missing ref rejected |
| C-004 | Unknown policy enum rejected in strict mode | negative schema | invalid enum rejected |
| C-005 | Completed execution is not verified success | semantic | verifier remains independent |
| C-006 | Duplicate idempotency key does not repeat side effect | integration | second delivery returns prior result |
| C-007 | Stale state version rejected | integration | `VERSION_CONFLICT` |
| C-008 | No capability / no policy => no allow | policy unit | deny or defer |
| C-009 | Secret redaction before trace persistence | privacy unit | secret absent from persisted payload |
| C-010 | Evidence corrections are append-only | ledger integration | correction creates new entry |
| C-011 | External IDs retain namespace | schema/logic | no collision across namespaces |
| C-012 | Breaking schema changes require major version | compatibility | build fails without major bump |

A conformance run must emit JSON with `passed`, `failed`, `skipped`, `schema_version`, and per-test evidence references.
