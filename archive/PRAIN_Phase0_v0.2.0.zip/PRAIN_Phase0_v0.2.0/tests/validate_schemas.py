"""Optional validator for PRAIN schema test vectors. Requires jsonschema package."""
import json
from pathlib import Path
from jsonschema import Draft202012Validator

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
vectors = json.loads((HERE / "test-vectors.json").read_text(encoding="utf-8"))
results = []
for case in vectors["cases"]:
    schema = json.loads((ROOT / "schemas" / case["schema"]).read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    errors = list(validator.iter_errors(case["instance"]))
    actual_valid = not errors
    passed = actual_valid == case["valid"]
    results.append({"id": case["id"], "expected_valid": case["valid"], "actual_valid": actual_valid,
                    "passed": passed, "errors": [e.message for e in errors]})
out = {"schema_version": vectors["version"], "passed": sum(r["passed"] for r in results),
       "failed": sum(not r["passed"] for r in results), "results": results}
print(json.dumps(out, ensure_ascii=False, indent=2))
raise SystemExit(1 if out["failed"] else 0)
