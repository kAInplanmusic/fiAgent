# PRAIN Phase 0 v0.2.0

Framework-neutrales Architektur- und Konformitätspaket für PRAIN.

## Quick start
1. Installiere Python 3.10+ und `jsonschema`.
2. Führe `python tests/validate_schemas.py` aus.
3. Prüfe `docs/DECISION_REGISTER.md` und `docs/PHASE0_EXIT_CRITERIA.md`.
4. Phase 0 erst freigeben, wenn alle Verhaltens- und Integrationstests ebenfalls umgesetzt und bestanden sind.

```bash
python -m pip install jsonschema
python tests/validate_schemas.py
```

Dieses Paket definiert Verträge und Testvektoren; es enthält noch keine produktive Event-Bus-, State-Store- oder Policy-Gateway-Runtime.
