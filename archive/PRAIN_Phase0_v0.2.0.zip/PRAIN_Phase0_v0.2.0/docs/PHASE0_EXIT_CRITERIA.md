# Phase 0 — Exit-Kriterien v0.2.0

Phase 0 gilt erst dann als abgeschlossen, wenn alle folgenden Kriterien durch automatisierte Tests belegt sind:

1. Alle JSON-Schemas lassen sich mit einem Draft-2020-12-Validator laden.
2. Jedes Kernobjekt hat stabile ID, Schema-Version und klar definierte Semantik.
3. Ein `Claim` mit `verification_status=verified` muss mindestens eine Evidenzreferenz enthalten oder eine dokumentierte Ausnahme referenzieren.
4. Jedes aktive `Goal` hat mindestens ein maschinenprüfbares Akzeptanzkriterium.
5. Jede `ActionRequest` referenziert eine Policy-Entscheidung, Capability, Idempotenzschlüssel und Korrelations-ID.
6. `execution_status=completed` darf nicht automatisch `verification_status=verified` implizieren.
7. Wiederholte Events mit derselben Consumer-/Idempotenz-Kombination erzeugen keine doppelte Nebenwirkung.
8. Veraltete Versionsupdates werden als Konflikt abgewiesen.
9. Unbekannte Capability, fehlende Policy oder unbekannter Risikograd führen nicht zu Allow.
10. Secrets werden vor Log-/Trace-Persistenz redigiert.
11. Additive Schemaänderungen bestehen Kompatibilitätstests; Breaking Changes erfordern eine Major-Version.
12. Jeder Architekturtest ist reproduzierbar und liefert Maschinenlesbares Ergebnis.

**Status:** Entscheidungsregeln definiert; Tests und Schema-Validierung sind in diesem Paket als Testharness angelegt. Das ist noch keine vollständige produktive Runtime.
