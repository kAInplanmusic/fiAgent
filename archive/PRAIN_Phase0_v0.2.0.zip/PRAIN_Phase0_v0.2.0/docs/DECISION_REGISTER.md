# PRAIN Phase 0.2 — Verbindliches Entscheidungsregister

**Version:** 0.2.0 · **Status:** beschlossen für den Referenzentwurf · **Geltungsbereich:** framework-neutrales PRAIN-Core-Modell

## DEC-001 — Identifikatoren
**Entscheidung:** UUIDv7 als bevorzugte interne ID; externe IDs werden als `external_ref` mit Namespace gespeichert.  
**Regel:** IDs sind opak. Verbraucher dürfen keine Semantik aus ID-Text ableiten. Importierte Legacy-IDs dürfen erhalten bleiben, müssen aber mit Namespace und Quelle versehen werden.

## DEC-002 — Zeit
**Entscheidung:** Zeitstempel sind RFC 3339 mit UTC-Offset; alle intern erzeugten Zeitpunkte werden in UTC mit `Z` serialisiert.  
**Regel:** Ereigniszeit (`occurred_at`) und Empfangszeit (`received_at`) sind getrennt. Verspätete Ereignisse werden anhand von Ereigniszeit plus Empfangszeit verarbeitet; historische Ereignisse dürfen den aktuellen Zustand nicht ungeprüft rückdatieren.

## DEC-003 — Ereigniszustellung
**Entscheidung:** At-least-once Zustellung mit Idempotenz auf Konsumentenseite.  
**Regel:** Kein Anspruch auf globale Exactly-once-Ausführung. Nebenwirkungen werden durch stabile `idempotency_key`, persistierte Verarbeitungsmarker und adapterseitige Deduplizierung begrenzt.

## DEC-004 — Zustand und Konflikte
**Entscheidung:** Jede veränderliche Entität trägt `version` und `updated_at`.  
**Regel:** Schreiboperationen verwenden Compare-and-swap/optimistische Versionsprüfung. Konflikte werden nicht still überschrieben. Standardverhalten: Konflikt markieren und zur erneuten Berechnung zurückgeben; fachliche Merge-Regeln müssen explizit pro Entität definiert werden.

## DEC-005 — Evidenz-Ledger
**Entscheidung:** Append-only Ereignis-/Evidenzprotokoll mit Hash-Verkettung als Referenzdesign; Backend darf variieren.  
**Regel:** Korrekturen erfolgen durch neue Einträge, nicht durch stilles Umschreiben. Hash-Verkettung allein ist kein vollständiger Manipulationsschutz; für stärkere Beweiskraft sind Schlüsselverwaltung und externe Checkpoints/Signaturen erforderlich.

## DEC-006 — Berechtigungen und Freigaben
**Entscheidung:** Deny-by-default für ausführende Aktionen. Least privilege, kurzlebige Freigaben und Capability-Scopes.  
**Regel:** Externe Kommunikation, finanzielle Aktionen, destruktive Änderungen, Geheimniszugriff und nicht rückgängig zu machende Aktionen benötigen eine explizite Policy und je nach Deployment eine menschliche Freigabe. Freigaben sind an Aktion, Ziel, Eingabe-Hash, Ablaufzeit und Capability gebunden; Änderungen an diesen Feldern machen die Freigabe ungültig.

## DEC-007 — Datenschutz und Geheimnisse
**Entscheidung:** Datenklassifizierung und Retention sind Pflichtmetadaten der Implementierung.  
**Regel:** Secrets werden nie in normalen Logs, Claims oder Traces im Klartext gespeichert. Redaction vor Persistenz/Export. Löschanforderungen müssen in Suchindizes, Caches, Vektorspeichern und abgeleiteten Daten behandelt werden; append-only Audit-Einträge enthalten nach Möglichkeit Referenzen/Hashes statt Inhalte.

## DEC-008 — Schema-Kompatibilität
**Entscheidung:** SemVer für Verträge.  
- PATCH: Dokumentation oder rückwärtskompatible Korrekturen ohne Schema-Verhaltensänderung.
- MINOR: optionale Felder/Enums nur dann, wenn Konsumenten unbekannte Werte tolerieren; sonst neue Version oder Feature Negotiation.
- MAJOR: Entfernung/Umbenennung/Änderung von Pflichtfeldern, Typen oder Semantik.
**Regel:** Produzenten und Konsumenten deklarieren unterstützte Schema-Versionen. Unbekannte Enum-Werte werden im strikten Validierungsmodus abgewiesen.

## DEC-009 — Quantum-ready
**Entscheidung:** Provider-/Compute-Abstraktion, portable Datenverträge und austauschbare Adapter; kein vorausgesetztes Quantencomputing und keine unbelegte Leistungsbehauptung.

## DEC-010 — Identität
**Entscheidung:** Identität entsteht verteilt aus P/R/A/I/N. A hält das versionierte explizite Selbstmodell, ist aber nicht alleiniger Identitätsursprung. Identitätsänderungen sind versioniert und nachvollziehbar.

## DEC-011 — Konfigurations- und Policy-Provenienz
**Entscheidung:** Jede Policy-Entscheidung protokolliert Policy-Version, angewendete Regelreferenzen, Zeitpunkt, Ergebnis und begründende Attribute. Fehlende Policy-/Capability-Daten führen zu `deny` oder `defer`, nie zu implizitem `allow`.

## DEC-012 — Korrelationsfelder
**Entscheidung:** Jeder Event-Envelope enthält `event_id`, `event_type`, `occurred_at`, `producer`, `correlation_id`, `schema_version` und `payload`. `causation_id` und `idempotency_key` sind bei kausalen Aktionen verpflichtend.
