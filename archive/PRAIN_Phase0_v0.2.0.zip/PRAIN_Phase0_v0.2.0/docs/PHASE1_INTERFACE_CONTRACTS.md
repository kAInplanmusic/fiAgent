# Übergang zu Phase 1 — Schnittstellenverträge

Phase 1 wird vorbereitet, aber nicht als produktive Runtime vorgetäuscht. Die erste lauffähige Referenzimplementierung sollte aus vier kleinen Services/Modulen bestehen:

1. **Event Registry / Bus Adapter** — Annahme, Validierung, Deduplizierung und Zustellung von Event Envelopes.
2. **Goal Registry** — versionierte Ziele, Akzeptanzkriterien und Statusübergänge.
3. **State Store Interface** — `get(id)`, `create(entity)`, `compareAndSwap(id, expectedVersion, nextEntity)`.
4. **Policy Gateway** — `evaluate(ActionRequest) -> PolicyDecision`, deny-by-default.

## Minimaler Event-Envelope
- `event_id`: UUIDv7
- `event_type`: namespaced string, z. B. `prain.observation.received`
- `occurred_at`: RFC 3339 UTC
- `producer`: stabiler Adapter-/Modul-Identifier
- `correlation_id`: End-to-End-Workflow-ID
- `schema_version`: SemVer
- `payload`: typisiertes Objekt gemäß Event-Typ
- `idempotency_key`: für Events/Aktionen mit Nebenwirkungen

## State Store Semantik
`compareAndSwap` schreibt nur, wenn `expectedVersion` der aktuellen Version entspricht. Bei Konflikt wird ein typisiertes `VERSION_CONFLICT` zurückgegeben; es findet kein stilles Überschreiben statt.

## Policy Gateway Semantik
Policy-Ausgabe ist `allow`, `deny`, `require_approval` oder `defer`. Kein Adapter darf Aktionen an der Gateway-Entscheidung vorbei ausführen.

## Ausserhalb des Umfangs von Phase 1
- kein autonomes Self-modifying Policy System
- kein echter Quantensolver
- keine produktive Identitätsbehauptung aus einem einzelnen Modell
- kein automatischer Zugriff auf Hallerbans oder andere private Agenteninstallationen
