# PRAIN v0.1.0 — Phase-1 Specification Gate (not implementation)

**Status: BLOCKED pending explicit Phase-0 closure.** This is a forward-looking specification gate only. It contains no runtime, framework, OS integration, deployment, or production code.

Versioning note: `0.1.0` is a new phase baseline and is not numerically “after” `0.99.0` under SemVer. It is used here as a Phase-1 namespace only after Phase 0 is accepted. Do not treat its existence as approval to begin Phase 1.

## Entry conditions
1. PRAIN v0.99 Phase-0 gates are all evidenced and reviewed.
2. Project owner explicitly approves Phase-0 closure.
3. Open decisions are accepted, rejected with rationale, or formally deferred with an owner and trigger.
4. The project owner explicitly authorizes Phase-1 specification work.

## Phase-1 scope if authorized
- Translate approved contracts into a runtime-neutral reference implementation plan.
- Define test harness boundaries and conformance fixtures before selecting runtime/framework/OS.
- Compare candidate persistence, message transport and provider adapters against the approved workload/SLOs.
- Preserve P/R/A/I/N as logical responsibilities; do not require five separate processes.
- Keep policy authorization independent from HAL adaptation and semantic inference.

## Explicit non-goals in this package
- No runtime implementation.
- No framework, language, broker, database, or OS selection.
- No deployment or server changes.
- No claim that Phase 0 is closed.
