# PRAIN v0.99 — Phase-0 Release Candidate Gate

**Status: NOT APPROVED / NOT CLOSED.** This is a final-candidate checklist, not a claim of completion. The package must not be labelled Phase-0 complete until every mandatory row has verifiable evidence and the project owner approves the closure record.

| Gate | Required evidence | Current status |
|---|---|---|
| Canonical definition and scope | Approved P/R/A/I/N definition; Hallerbans-independent scope; quantum-ready meaning bounded | Documented; owner confirmation pending |
| Traceability through v0.6 | Every normative requirement linked to source, decision, contract and conformance test | Partial; item-level knowledge base audit open |
| Schema constraints | Nested types, enums, refs, patterns, formats, numeric bounds and required fields diffed; migrations tested | Open |
| Knowledge-base reconciliation | JSON and HTML embedded DB compared item-by-item; every item mapped, superseded or explicitly retired | Open |
| Claim ontology | Epistemic statuses and promotion/demotion rules approved | Open |
| Identity/tenant/delegation | Principal, tenant, scope, expiry, revocation and lineage contract approved | Open |
| Authority/consistency | Record-class matrix and canonical execution lifecycle approved | Partial |
| Policy/approval | Action-bound approval, policy re-check and revocation semantics approved | Partial |
| Evidence/privacy | Signing/key lifecycle, classification, retention, deletion and derived-copy behavior approved | Open |
| HAL safety boundary | Adaptation catalogue, hard bounds, independent verification and rollback defined | Partial |
| SLOs and operational thresholds | Workload-specific targets approved | Open |
| Conformance suite | Positive/negative fixtures, failure/recovery, tenant isolation and migrations mapped to acceptance results | Partial |
| Package integrity | Archive integrity, manifest and SHA-256 independently checked | To be checked on final candidate build |
| User approval | Explicit written Phase-0 closure decision | Not received |

## Release rule
A gate cannot pass on prose alone when the criterion requires machine-checkable fixtures, comparison results or explicit owner approval. No runtime/framework/OS work is authorized by this candidate.
