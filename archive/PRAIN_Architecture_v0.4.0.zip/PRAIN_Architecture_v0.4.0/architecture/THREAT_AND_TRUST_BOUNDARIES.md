# Trust boundaries and policy enforcement

## 1. Trust zones

1. **Untrusted inputs:** user content, web pages, retrieved documents, external tool output, other agents.
2. **Interpretation zone:** parsing, extraction, reasoning and planning; outputs remain proposals.
3. **Control zone:** goal state, policy evaluation, approval checks and state transitions.
4. **Execution zone:** capability adapters and external side effects.
5. **Evidence zone:** audit and verification artifacts, protected against unauthorized mutation.

Content from an untrusted zone must not become executable instructions merely because it was retrieved or summarized.

## 2. Policy decision inputs

At minimum:
- actor and delegated principal;
- action and target;
- capability reference and scope;
- normalized input digest;
- goal/plan linkage;
- risk class and side-effect classification;
- policy ID/version;
- approval reference and expiry if required;
- environment/tenant;
- idempotency key.

A policy decision is tied to this exact request. Changing target, inputs, capability, or relevant context requires re-evaluation.

## 3. Capability model

Capabilities should be scoped by action, resource, operation, environment, and expiry. Prefer short-lived delegated capabilities over ambient credentials. Never give a planner raw secrets. Adapters receive only the minimum credential required for their operation.

## 4. Approval binding

An approval must bind to the exact action, target, canonical input digest, idempotency key, policy version and expiry. It must identify the approver and be authenticated in production. Reusing an approval for a modified action is invalid.

## 5. Audit and privacy

Record policy decisions and significant state transitions, but avoid copying raw secrets and unnecessary personal data into the ledger. Keep a source reference plus redacted representation where possible. Retention/deletion must cover object storage, relational records, vector/graph indexes, caches, derived summaries, backups according to policy, and exported artifacts.

## 6. Non-negotiable enforcement

- The policy gateway is a reference monitor: every side effect passes through it.
- No direct tool adapter bypass from reasoning code.
- Fail closed if policy service is unavailable for an action that requires a decision.
- Distinguish denied, unavailable, and not evaluated.
- Do not treat a valid schema as evidence that a request is authorized.
- Do not treat an allowed action as evidence that the goal succeeded.
