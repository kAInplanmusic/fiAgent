# Semantic model and typed relationships

## 1. Why semantics is a first-class layer

A database stores records; a semantic layer defines what records mean, how they relate, when they are valid, who asserted them, and what evidence supports them. PRAIN should not let an embedding similarity score silently become a fact or an authorization.

## 2. Core object types

- **Entity:** stable referent with canonical ID and aliases.
- **Observation:** source-bound occurrence or input, retaining raw reference and timestamps.
- **Claim:** proposition about an entity or relation, with claimant/source, validity interval, confidence, status, and evidence.
- **Belief:** current system stance toward a claim (`accepted`, `tentative`, `disputed`, `rejected`, `superseded`).
- **Goal:** desired outcome contract.
- **Plan:** versioned proposed path from current state to goal state.
- **ActionRequest:** specific operation proposed for execution.
- **PolicyDecision:** explicit allow/deny with policy version and request digest.
- **ExecutionReceipt:** what the executor reports doing; not equivalent to verification.
- **VerificationRecord:** evaluation of acceptance criteria against evidence.
- **SelfModelRevision:** versioned statement of system capabilities, limits, commitments, and continuity.
- **EvidenceRef:** pointer to immutable or versioned source artifact.
- **Conflict:** typed incompatibility between claims, state versions, policies, or goal commitments.

## 3. Claim and belief discipline

A claim should not be represented as just `{text, embedding}`. At minimum:
- `claim_id`
- subject / predicate / object or typed proposition
- source and extraction method
- `observed_at`, `recorded_at`
- valid-from / valid-until where meaningful
- confidence and confidence basis
- evidence refs
- status
- schema/ontology version
- sensitivity/retention label

Confidence is not truth. Source reliability, extraction certainty, recency, and corroboration should remain distinguishable rather than collapsed into a single score where practical.

## 4. Contradiction handling

When claims conflict:
1. preserve both claims and their provenance;
2. determine whether they differ in time, scope, definition, or source;
3. check source authority and independent corroboration;
4. mark unresolved conflict explicitly;
5. avoid irreversible actions dependent on the disputed claim;
6. request new observation or defer if material.

Never overwrite an old claim just because a newer text was received. Newness may matter, but does not automatically establish correctness.

## 5. Semantic links

Useful typed edges:
- `observed_from`
- `supports`
- `contradicts`
- `derived_from`
- `about_entity`
- `fulfills_goal`
- `depends_on`
- `authorized_by`
- `executed_as`
- `verified_by`
- `supersedes`
- `caused_by`
- `updates_self_model`
- `requires_capability`

Edges should have IDs and provenance if their correctness affects decisions.

## 6. Storage strategy

Use polyglot persistence behind interfaces:
- relational store for authoritative transactional state, goals, policies and workflow transitions;
- object/document storage for source artifacts and large payloads;
- graph representation for explicit relationships and lineage when traversals justify it;
- vector index for retrieval candidates only, never the authority for permissions or final truth;
- append-only audit/evidence stream for state transitions and verification records.

A small prototype may use SQLite and JSON first. The semantic API should remain provider-neutral.
