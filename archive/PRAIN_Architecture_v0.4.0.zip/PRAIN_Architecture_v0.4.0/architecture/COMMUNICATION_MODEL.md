# Communication model and internal pathways

## 1. Message classes

Use three distinct interaction types.

### Command
Requests an actor to do something. It has an explicit recipient, deadline/timeout, idempotency key, and expected result contract. Example: `ExecuteAction`.

### Event
States that something happened. It is immutable after publication and carries `event_id`, `occurred_at`, `received_at`, `correlation_id`, and optional `causation_id`. Example: `ActionExecutionFinished`.

### Query
Requests information without intended side effects. It should be read-only and can carry consistency requirements. Example: `GetGoalState`.

Never disguise a command as an event. An event named `delete_file` is an unsafe ambiguity; use a command with an explicit policy check.

## 2. Standard envelope

Required fields:
- `message_id`: unique opaque identifier.
- `message_type`: `command | event | query | response`.
- `name`: namespaced message name.
- `schema_version`: explicit semantic version.
- `created_at`: UTC timestamp.
- `producer`: module/service identity.
- `correlation_id`: end-to-end workflow trace.
- `causation_id`: immediate triggering message when known.
- `tenant_id` or security domain where multi-tenancy exists.
- `payload`: typed payload, not a free-form catch-all.
- `provenance`: source and transformation lineage when content contains claims.
- `trace_context`: distributed trace propagation if supported.

Security-sensitive messages also include `actor`, `capability_ref`, `policy_decision_ref`, `idempotency_key`, and `input_digest`.

## 3. Recommended pathways

### Observation pathway
`external source → P adapter → raw observation reference → normalizer → semantic claim store → evidence index → R context`

### Goal pathway
`user/system intent → I Goal Registry → priority/dependency resolver → R planner → plan review → policy preflight`

### Execution pathway
`R PlanProposal → I/Orchestrator validation → ActionRequest → Policy Gateway → N adapter → ExecutionReceipt → event bus`

### Verification pathway
`ExecutionReceipt + expected postconditions → verifier → evidence ledger → goal state transition → feedback to R/P`

### Self-model pathway
`verified events + durable commitments + capability registry → A update proposal → contradiction/eligibility checks → versioned SelfModelRevision`

### Failure pathway
`timeout/error/conflict → normalized FailureEvent → recovery coordinator → retry/compensate/replan/escalate → new action with linked causation`

## 4. Routing rules

- Route by namespaced message type and explicit owner, not by fuzzy natural-language interpretation.
- Events may have multiple subscribers; commands have one accountable handler unless an explicit fan-out protocol is defined.
- Query handlers declare whether their result is strongly consistent, snapshot-consistent, or eventually consistent.
- Each consumer keeps a durable inbox/deduplication record before side effects in a production implementation.
- Event publication and state mutation must use an outbox/transactional strategy where atomicity matters.
- Unknown schema version: reject or quarantine; never silently reinterpret.
- Unknown command: return a typed `unsupported_command` response.
- Expired command: do not execute; return `deadline_exceeded`.
- Missing correlation ID: generate at ingress and preserve downstream.
- Sensitive payloads should be referenced or redacted, not copied into every event.

## 5. Synchronous vs asynchronous

Use synchronous calls for:
- policy decisions required before a side effect;
- short local queries;
- validation that gates a state transition.

Use asynchronous events for:
- long-running work;
- fan-out observation processing;
- notifications and audit indexing;
- retries, delayed work, and cross-process coordination.

Do not hold a synchronous request open for an entire long-running agent workflow. Return a `workflow_id` and publish state changes.

## 6. Ordering, duplicates and delivery

Assume at-least-once delivery. Exactly-once distributed side effects are not a realistic generic promise. Use:
- idempotency key scoped to actor + action class + target;
- consumer inbox to reject duplicates;
- transactional outbox to couple state and publication;
- per-aggregate sequence/version for ordering-sensitive events;
- explicit stale-event handling;
- bounded retries with exponential backoff and jitter;
- dead-letter queue plus operator/recovery policy.

A duplicate event must not imply a duplicate side effect. A consumer may record `duplicate_ignored` while still returning the original outcome reference.

## 7. Communication failure contract

Every command ends in one of:
`accepted`, `succeeded`, `rejected`, `failed`, `timed_out`, `cancelled`, `unknown_outcome`.

`unknown_outcome` is essential: if a remote tool times out after the action may have occurred, do not blindly repeat it. Query status or use an idempotency key first.

## 8. Interaction diagram

```mermaid
sequenceDiagram
    participant P as Perception
    participant S as Semantic State
    participant I as Intention
    participant R as Reason
    participant G as Policy Gateway
    participant N as Nerve
    participant V as Verifier
    participant E as Evidence Ledger

    P->>S: Observation + provenance
    S-->>R: Context snapshot + version
    R->>I: Goal/plan proposal
    I-->>R: Goal ID + acceptance criteria
    R->>G: ActionRequest + input digest
    G-->>R: PolicyDecision (allow/deny)
    R->>N: Authorized command
    N-->>P: ExecutionReceipt / result
    P->>V: Result + expected postconditions
    V->>E: Verification evidence
    E-->>I: Verified outcome reference
    I->>I: Goal transition (CAS)
    I-->>R: Completed / retry / replan / blocked
```
