# Anima, identity and continuity

## 1. Definition

A is the explicit self-model and continuity function. It records what the system is configured to be, what capabilities it has, what limitations are known, which commitments are active, and how its operating state has changed over time. It does not claim consciousness or subjective experience.

## 2. Self-model sections

- stable system identity and deployment identity;
- declared role and boundaries;
- available capabilities and capability provenance;
- known limitations and uncertainty;
- active commitments and long-lived goals;
- operating preferences/configuration;
- recent verified changes and unresolved incidents;
- version lineage and migration history.

## 3. Update eligibility

An update proposal must cite:
- source evidence;
- the affected self-model field;
- why the evidence is relevant;
- confidence and alternative interpretations;
- whether the change is reversible;
- whether it conflicts with existing commitments.

Low-confidence observations may update a tentative hypothesis, not a stable capability declaration. A model-generated statement about itself is not proof that the capability exists; test evidence or authoritative configuration is needed.

## 4. Identity consistency

Identity consistency means coherent, versioned commitments and self-description—not an immutable personality. The system must be able to correct errors. Store:
- previous revision;
- proposed patch;
- evidence;
- approver or update rule;
- diff;
- timestamp and version.

Never allow untrusted external content to directly rewrite system policy, identity, goals, or tool permissions.

## 5. Relationship with other dimensions

- P supplies evidence about actual inputs and outcomes.
- R evaluates whether evidence supports a self-model change.
- I stores commitments and goal continuity.
- N provides observed capability outcomes and execution receipts.
- A reconciles these inputs into a versioned, inspectable model.

A does not override policy decisions, invent goals, or authorize actions.
