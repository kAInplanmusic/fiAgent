# Reference architecture

## 1. System definition

PRAIN is a semantic control plane for goal-directed autonomous systems. It maintains a typed model of the world, the system, its goals, permissions, actions, and evidence. It orchestrates a loop:

**observe → interpret → orient → choose → authorize → execute → verify → learn/update**

This is a control loop, not a one-way pipeline. Verification can reopen a goal, invalidate an assumption, request new observations, or trigger compensation.

## 2. Logical planes

### A. Semantic plane — what does the system believe and mean?
- Ontology and schema registry
- Entity/relationship registry
- Claim and belief store with provenance, confidence, validity interval, and status
- Context resolver
- Memory index adapters (relational, graph, vector, document)
- Semantic diff and contradiction detection

### B. Control plane — what should happen next?
- Goal Registry
- Priority and dependency resolver
- Planner / Reasoning Coordinator
- Workflow state machine
- Policy Gateway
- Verification / Evaluation service
- Recovery and compensation coordinator

### C. Execution plane — how does an authorized action happen?
- Nerve capability registry
- Tool and agent adapters
- Command dispatcher
- Timeout, cancellation, retry, and idempotency handling
- Result normalizer
- Sandboxed execution boundary where appropriate

### D. Evidence and operations plane — what happened, and can we prove it?
- Event log / durable message transport
- State store and optimistic concurrency
- Evidence ledger
- Audit and trace correlation
- Metrics, logs, traces, cost and latency accounting
- Retention, redaction, deletion propagation

These are logical planes. A small deployment may run them in one process; the contracts should not require that. Split services only when isolation, scale, deployment, or reliability needs justify the operational cost.

## 3. P/R/A/I/N responsibilities and cross-links

| Dimension | Primary responsibility | Inputs | Outputs | Must connect to |
|---|---|---|---|---|
| P — Perception | Acquire/normalize observations | user, tools, sensors, files, events | Observation, ExtractedFact, Uncertainty | R, semantic store, evidence |
| R — Reason | Interpret, infer, plan, compare options | observations, beliefs, goals, constraints | Hypothesis, PlanProposal, Risk/Uncertainty assessment | P, I, policy gateway |
| A — Anima | Maintain explicit self-model and continuity | verified history, commitments, capabilities, limits | SelfModelRevision, continuity constraints | all dimensions; especially R and I |
| I — Intention | Define desired states and commitments | user intent, priorities, constraints, self-model | Goal, Plan, acceptance criteria, status transitions | R, N, verifier |
| N — Nerve | Execute authorized actions | approved ActionRequest, capability token/context | ExecutionReceipt, tool result, error | policy, evidence, P, verifier |

### Important boundaries
- A is not a mystical or hidden authority. It is an explicit, inspectable self-model with evidence links, revision history, and uncertainty.
- I owns goal semantics and acceptance criteria; R can propose goals or plans but cannot silently rewrite a user commitment.
- N executes only a concrete, authorized request. It does not decide that an action is allowed merely because a planner suggested it.
- P distinguishes raw observation from extracted interpretation. A model-generated interpretation is not relabeled as a direct observation.
- R records material assumptions and unresolved alternatives when they affect a decision.

## 4. Shared state and bounded contexts

Avoid a single unstructured “everything memory” object. Use typed bounded contexts:
1. `world`: entities, observations, claims, relationships.
2. `self`: capabilities, limits, preferences/configuration, commitments, identity revisions.
3. `goals`: goal lifecycle, priorities, dependencies, acceptance criteria.
4. `plans`: alternatives, chosen plan, action graph, preconditions.
5. `execution`: action requests, dispatch state, receipts, retries, compensation.
6. `policy`: capabilities, rules, decisions, approvals, policy versions.
7. `evidence`: source refs, verification results, audit chain.
8. `operations`: trace IDs, cost, latency, failures, health.

Cross-context links use stable IDs, schema versions, and correlation IDs. Contexts may be stored in separate technologies later; references must not depend on a database-specific primary key.

## 5. Canonical request path

1. P receives an input and creates an Observation with source, timestamps, trust label, and raw-content reference.
2. The semantic resolver normalizes entities and extracts claims without erasing provenance.
3. R evaluates relevance, uncertainty, contradiction, and goal implications.
4. I creates or updates a Goal only through a defined goal transition. Acceptance criteria are explicit.
5. R proposes a plan as a dependency graph with preconditions, expected outcomes, and rollback/compensation notes.
6. Policy Gateway evaluates each action request against actor, capability, target, input digest, policy version, risk class, and approval requirement.
7. N dispatches only an authorized request and emits an ExecutionReceipt.
8. P/Verifier compares the result against acceptance criteria using independent evidence where feasible.
9. Evidence Ledger records the verification result and linked artifacts.
10. I transitions the goal to completed only after verification passes; otherwise it remains active, blocked, or failed with a recovery decision.
11. A may update the self-model only from eligible evidence and explicit update rules; no single unverified output should rewrite identity.

## 6. Orchestration topology

Use a **central control loop with event-driven modules**, not unconstrained peer-to-peer chatter as the default:
- Commands are addressed to a specific owner and expect a result.
- Events announce facts that have already occurred.
- Queries request read-only information.
- Every message includes correlation and causation metadata.
- The orchestrator coordinates goals and transitions, but it does not replace specialized modules.
- Modules may be implemented as libraries initially and extracted as services later.

This keeps the architecture debuggable while allowing parallel reasoning or specialist agents behind explicit contracts.

## 7. Execution model

A goal is not one tool call. Model a workflow as a DAG or state machine:
`Goal → Plan → ActionRequest(s) → PolicyDecision(s) → ExecutionReceipt(s) → Verification → GoalTransition`

Each action has:
- stable `action_id`
- `goal_id` and `plan_id`
- actor and capability
- target and normalized input
- preconditions and expected postconditions
- idempotency key
- timeout and cancellation policy
- policy decision reference
- execution status separate from verification status
- compensation strategy if a side effect is reversible

## 8. Deployment progression

- **Prototype:** one process, in-memory adapters, deterministic contract tests.
- **Local durable core:** SQLite/PostgreSQL state, durable event/outbox, structured logs.
- **Single-host runtime:** service API, worker pool, capability adapters, secrets manager, health/readiness.
- **Distributed runtime:** durable broker, leases, partition strategy, distributed tracing, backpressure.
- **Multi-agent federation:** authenticated identities, delegated capabilities, protocol/version negotiation, tenant isolation.

Do not introduce a broker, graph database, vector database, or microservice mesh before the relevant requirements justify them. Preserve interfaces so the storage/transport provider remains replaceable.
