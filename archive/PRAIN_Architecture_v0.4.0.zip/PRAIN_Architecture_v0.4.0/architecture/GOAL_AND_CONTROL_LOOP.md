# Goal orientation and control loop

## 1. Goal object is a contract

A goal must define:
- desired state/outcome, not merely an activity;
- accountable owner and requesting principal;
- priority and deadline, if any;
- acceptance criteria that can be checked;
- constraints and forbidden outcomes;
- dependencies and blockers;
- evidence requirements;
- resource/cost budget where relevant;
- cancellation and supersession conditions;
- status and revision.

“Research the topic” is an activity. “Produce a report containing X, compare Y against Z, cite primary sources, and pass criteria C1–C5” is a goal contract.

## 2. Goal lifecycle

Recommended states:
`proposed → accepted → active → blocked | verifying → completed`
Other terminal states: `failed`, `cancelled`, `superseded`.

Rules:
- `proposed` may be edited; `accepted` establishes commitment.
- `active` requires owner, acceptance criteria, and available policy context.
- `blocked` requires a typed blocker and a reactivation condition.
- `verifying` means actions may have run but acceptance has not passed.
- `completed` requires a passing VerificationRecord and evidence refs.
- `failed` requires a failure reason and recovery disposition.
- `cancelled` and `superseded` are not successful completion.
- Changing acceptance criteria after execution begins creates a new revision and requires an explicit impact assessment.

## 3. Priority model

Do not reduce priority to one opaque LLM score. Use a transparent lexicographic policy:
1. hard safety/policy constraints;
2. explicit user commitments and deadlines;
3. dependency criticality / unblocking value;
4. expected goal value;
5. confidence that the work is feasible;
6. estimated cost and latency;
7. fairness/starvation protection.

Store each factor and its source. A planner may recommend a score, but a priority resolver applies the declared policy. High uncertainty should lead to information gathering or a bounded experiment, not fabricated confidence.

## 4. Plan representation

A plan is a directed acyclic graph or explicit state machine. Each step has:
- step ID, type, dependencies;
- preconditions;
- action request template;
- expected postconditions;
- estimated time/cost;
- risk class and required capability;
- verification method;
- retry/cancel policy;
- compensation plan;
- fallback/alternative.

Parallelize only steps whose dependencies and side effects permit it. Serialize writes to the same aggregate unless concurrency semantics are explicit.

## 5. Control loop algorithm

1. Load goal and consistent state snapshot.
2. Check goal is current, not cancelled/superseded, and not blocked.
3. Compute unmet acceptance criteria.
4. Resolve missing information and material contradictions.
5. Generate candidate plans; estimate cost, confidence, and reversibility.
6. Select plan under priority and resource budgets.
7. Validate preconditions and policy context.
8. Request policy decision for each action, at dispatch time.
9. Execute with timeout, cancellation and idempotency handling.
10. Normalize result; classify outcome as success/failure/unknown.
11. Verify postconditions independently from execution response.
12. Commit state transition with expected version.
13. Record evidence and metrics.
14. If failed: retry only when safe; otherwise query outcome, compensate, replan, block, or escalate.
15. Re-evaluate goal priority and constraints after significant state change.

## 6. Drift and runaway prevention

- Keep a goal lineage: requester → goal → plan → action → evidence.
- Never silently substitute a different objective.
- Material plan changes require a diff and rationale.
- Set maximum iterations, wall-clock deadline, token/API budget, and side-effect budget.
- Stop when criteria pass, the goal is cancelled, budget expires, policy denies, or progress stalls.
- Detect loops by repeated state fingerprints, repeated tool calls, and no measurable acceptance-criterion progress.
- Use explicit user confirmation when the requested commitment changes materially.

## 7. Verification record

A VerificationRecord should contain:
- `verification_id`, `goal_id`, `goal_revision`;
- criterion-by-criterion pass/fail/unknown;
- evidence references and provenance;
- verifier identity/version;
- method and environment;
- timestamp;
- confidence and known limitations;
- final decision: `pass | fail | inconclusive`.

`inconclusive` must not be coerced to pass. Tool output alone may be evidence, but whether it is sufficient depends on the criterion.
