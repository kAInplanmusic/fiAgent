# Observability, evaluation and learning

## 1. Trace a goal end-to-end

Every workflow should be traceable across:
`goal_id → goal_revision → plan_id → action_id → policy_decision_id → execution_id → verification_id → evidence refs`

Propagate `correlation_id` and `causation_id` across events. Redact secrets from logs and traces.

## 2. Operational signals

Measure at least:
- goal completion rate by goal class;
- acceptance-criterion pass rate;
- verification inconclusive/failure rate;
- policy deny rate and reasons;
- duplicate event suppression;
- state conflict frequency;
- unknown-outcome frequency;
- retries and compensation rate;
- tool success vs verified success gap;
- latency per phase and end-to-end;
- cost per completed goal;
- stalled/looping workflows;
- stale policy/schema events;
- evidence coverage and provenance completeness.

Do not optimize only for task completion: that can reward skipping verification or violating constraints.

## 3. Quality evaluation

Evaluate four separate layers:
1. **Semantic quality:** entity/claim extraction, provenance, contradiction handling.
2. **Planning quality:** criterion coverage, feasibility, cost, dependency correctness.
3. **Execution quality:** correct adapter, policy compliance, idempotency and outcome handling.
4. **Verification quality:** evidence sufficiency, false pass rate, reproducibility.

Maintain a regression suite of real, redacted task cases and adversarial edge cases. Score each criterion separately; a single aggregate score hides failure modes.

## 4. Learning loop

After a completed or failed goal:
- compare expected vs actual outcome;
- classify the failure or surprise;
- decide whether it updates a transient context, reusable procedure, semantic claim, or self-model;
- require evidence and review for high-impact updates;
- add a regression test when a failure reveals a repeatable defect.

Do not automatically promote every successful tool trace into a reusable memory. Generalize only when the behavior is repeatable and context boundaries are understood.
