# Failure semantics and recovery

## 1. Normalize failures

Use typed failure classes:
- `validation_error`
- `schema_incompatible`
- `policy_denied`
- `capability_missing`
- `precondition_failed`
- `state_conflict`
- `rate_limited`
- `transient_transport`
- `timeout_known_not_executed`
- `timeout_outcome_unknown`
- `executor_failed`
- `verification_failed`
- `verification_inconclusive`
- `budget_exhausted`
- `cancelled`
- `dependency_unavailable`

Each failure includes stage, retryability, side-effect certainty, evidence refs, correlation ID, and recommended disposition.

## 2. Retry rules

Retry only when:
- failure is classified transient;
- retry budget remains;
- action is idempotent or deduplicated;
- deadline permits;
- policy remains valid;
- the previous attempt's side-effect status is known or reconciled.

Use exponential backoff with jitter. Do not retry policy denial, schema incompatibility, invalid input, or unknown side-effect outcome blindly.

## 3. Unknown outcome

If a remote action times out after dispatch, the action may have succeeded. Mark `unknown_outcome`, then:
1. query the executor by action/idempotency ID;
2. reconcile external state;
3. if confirmed executed, verify postconditions;
4. if confirmed not executed, retry if policy and budget permit;
5. if irreconcilable, block/escalate instead of duplicating the side effect.

## 4. Compensation

Compensation is not generic rollback. For each side-effecting action, declare:
- whether it is reversible;
- compensation action and required capability;
- compensation preconditions;
- compensation verification;
- what cannot be restored.

Use a saga-like workflow for multi-step operations. Compensation itself requires policy evaluation and evidence.

## 5. State conflicts

On compare-and-swap conflict:
- reread current state;
- compare semantic differences;
- re-evaluate preconditions and policy;
- merge only fields with explicitly mergeable semantics;
- otherwise replan or surface a conflict.

Never silently retry the same write with the new version if its assumptions may now be stale.

## 6. Circuit breakers and backpressure

Per capability adapter, track consecutive failures, latency, rate limits and health. Open a circuit when thresholds are exceeded, probe cautiously, and route to an alternative only if semantically equivalent and authorized. Bound queues and reject/defer work when capacity is exceeded.
