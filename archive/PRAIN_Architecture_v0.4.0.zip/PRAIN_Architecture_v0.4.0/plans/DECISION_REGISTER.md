# Decision register — v0.4.0

| ID | Decision | Rationale | Consequence |
|---|---|---|---|
| ADR-013 | PRAIN is a semantic control plane, not merely a knowledge base | Links meaning to goals, policy, action and evidence | Architecture spans semantic, control, execution and evidence planes |
| ADR-014 | P/R/A/I/N are logical responsibilities, not five mandatory agents | Allows modularity without forced agent proliferation | Deploy as modules first; split only when needed |
| ADR-015 | Central control loop + event-driven modules is the default | Easier auditability and recovery than unrestricted peer-to-peer calls | Orchestrator owns workflow transitions; specialist modules own domain logic |
| ADR-016 | Commands, events, queries and responses are distinct types | Prevents hidden side effects and ambiguous routing | Typed message envelope and routing rules |
| ADR-017 | Goal completion requires criterion-level verification | Execution success is not user outcome success | Separate ExecutionReceipt and VerificationRecord |
| ADR-018 | Unknown outcome is a first-class state | Timeout does not prove non-execution | Reconcile before retry |
| ADR-019 | Semantic claims preserve provenance and contradiction state | Prevents embeddings or recency from becoming authority | Typed claim/belief model |
| ADR-020 | Policy gateway is the only authorizer for side effects | Avoids bypass by planners or adapters | All N side effects pass through policy enforcement |
| ADR-021 | Self-model updates require evidence and version history | Prevents prompt injection or model output rewriting identity | A emits proposals; eligibility checks govern adoption |
| ADR-022 | Provider-neutral interfaces precede technology choices | Avoids premature lock-in | Storage and transport implementations remain replaceable |
| ADR-023 | Durable single-host before distributed deployment | Reduces complexity and enables real restart/recovery tests | SQLite/Postgres + inbox/outbox before broker/mesh |
| ADR-024 | Vector search is retrieval, not authority | Similarity does not prove truth or permission | Authoritative state and policy remain typed and transactional |

## Open questions to resolve before multi-user or distributed deployment

1. What is the identity and authentication model for humans, agents, and delegated principals?
2. What is the authoritative source for policy updates and emergency revocation?
3. Which data classes are allowed in long-term memory, and what are the retention/deletion rules?
4. What consistency is required per bounded context?
5. Which action classes require explicit human approval?
6. How are schema migrations and rolling compatibility handled?
7. What is the target workload and reliability objective?
8. Which components need independent deployment, and what evidence justifies that split?
