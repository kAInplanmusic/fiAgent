# Implementation roadmap

## Stage 1 — contract hardening (now)
- Adopt the v0.4.0 message, goal and action-request contracts.
- Add schema validation to CI and compatibility tests.
- Add architecture-to-test traceability.
- Define explicit goal and execution state machines.

**Exit:** every critical invariant maps to at least one automated positive and negative test.

## Stage 2 — durable single-host core
- Introduce repository interfaces and SQLite/PostgreSQL implementation.
- Persist goals, state versions, policy decisions, inbox/outbox, verification records.
- Implement transactional outbox and consumer inbox.
- Add process restart and duplicate-delivery integration tests.

**Exit:** restart does not lose committed state; duplicate delivery does not repeat side effects; state conflicts are surfaced.

## Stage 3 — executable workflow engine
- Plan DAG and dependency resolver.
- Goal criterion evaluator interface with deterministic checks first.
- Explicit workflow transitions and deadline/budget enforcement.
- Timeout unknown-outcome reconciliation, cancellation and compensation protocol.

**Exit:** a multi-step workflow can pause/resume, verify each step, and recover from injected failures.

## Stage 4 — capability and policy boundary
- Capability registry and adapter manifests.
- Policy versioning, authenticated approval, short-lived delegated capabilities.
- Enforce policy check at dispatch and bind decision to request digest.
- Audit policy denials and adapter invocations without leaking secrets.

**Exit:** all side-effecting adapter paths require a current allow decision; tests prove bypass is impossible through public interfaces.

## Stage 5 — semantic memory and provenance
- Typed entities, observations, claims, beliefs and contradiction objects.
- Source lineage and redaction/retention metadata.
- Relational authoritative store; optional graph/vector adapters behind interfaces.
- Retrieval evaluations and false-fact regression tests.

**Exit:** every decision-relevant claim has provenance and a typed status; vector similarity cannot grant authority.

## Stage 6 — self-model and adaptive quality
- Versioned self-model with update proposals and evidence eligibility.
- Regression case generation from verified incidents.
- Cost, latency, quality and policy-compliance metrics.
- Reproducible evaluation harness.

**Exit:** self-model changes are traceable, reversible where possible, and cannot alter permissions directly.

## Stage 7 — optional distribution
Only after evidence justifies it:
- durable broker, worker pool, leases, backpressure;
- distributed trace propagation;
- multi-tenant authn/authz and protocol negotiation;
- provider adapters and deployment profiles.

Do not start with a microservice mesh. Start with stable contracts and durable semantics.
