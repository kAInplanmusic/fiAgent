# Requirements traceability matrix

| Requirement | Contract / design | Minimum test | Status |
|---|---|---|---|
| Duplicate events do not duplicate side effects | Communication model, inbox/outbox | replay same event after restart | Prototype-only in-memory |
| Stale state writes rejected | State Store contract | CAS with stale version fails | Prototype behavior exists |
| Missing policy denies | Trust boundaries | no rule / unavailable policy denies | Prototype rule check exists; outage test pending |
| Goal completion needs evidence | Goal schema, goal loop | no evidence or inconclusive verification cannot complete | Prototype behavior exists |
| Execution and verification separate | Goal loop, semantic model | tool says success but verifier fails | Design; integration test pending |
| Unknown timeout not blindly retried | Failure model | timeout after remote side effect | Design; implementation pending |
| Claim provenance preserved | Semantic model | claim without source rejected/quarantined | Design; implementation pending |
| Self-model cannot self-authorize | Identity model, policy boundary | self-model update cannot grant capability | Design; implementation pending |
| Approval bound to exact request | Action schema, policy model | mutate target/input/idempotency after approval | Prototype partial; signature/authentication pending |
| Secret redaction before persistence | Trust boundaries | secret canary absent from logs/evidence | Design; implementation pending |
| Goal revision traceable | Goal lifecycle | acceptance criteria change creates revision | Design; implementation pending |
| Durable recovery after restart | Roadmap stage 2 | restart between commit and publish | Not implemented |
| Schema evolution explicit | Message envelope | incompatible schema rejected | Contract drafted; validator pending |
| Correlation across workflow | Communication model | goal trace links every action and verification | Prototype partial; distributed tracing pending |

## Release gate

Do not call a requirement “implemented” solely because it is described here. Use states: `designed`, `implemented`, `tested`, `verified-in-target`, `deferred`. Update this matrix with commit/test evidence as code evolves.
