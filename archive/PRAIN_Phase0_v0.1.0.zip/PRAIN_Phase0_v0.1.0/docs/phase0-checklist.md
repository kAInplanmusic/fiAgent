# Phase 0 — Checkliste und Abnahmekriterien

## Erledigt als Entwurf
- [x] Kanonische P/R/A/I/N-Begriffe und Verantwortlichkeiten definiert
- [x] Verteiltes Identitätsmodell dokumentiert
- [x] Claim-Typen und Verifikationsstatus voneinander getrennt
- [x] Kernobjekte als JSON Schema Draft 2020-12 angelegt
- [x] Event-Korrelation und Idempotenzfelder definiert
- [x] Capability-Gateway und Policy-Entscheidungen als Architekturprinzip festgelegt
- [x] ADRs angelegt, darunter Adapter-Neutralität und Quantum-ready-Abgrenzung

## Vor Phase 1 noch zu entscheiden
- [ ] ID-Format: UUIDv7, ULID oder providerneutraler String
- [ ] Zeitregeln: UTC-Normalisierung und Umgang mit verspäteten Ereignissen
- [ ] Event Delivery: mindestens einmal + Idempotenz oder zusätzliche Exactly-once-Semantik auf Anwendungsebene
- [ ] State Store: Transaktionsgrenzen, Konfliktauflösung und Versionierung
- [ ] Evidence Ledger: append-only-Anforderung, Hash-Kette oder signierte Einträge
- [ ] Policy: Rollen-/Capability-Vererbung, Freigabestufen und Ablauf von Freigaben
- [ ] Datenschutz: Retention, Löschung, Redaction und Umgang mit Secrets
- [ ] Schema-Kompatibilität: Regeln für additive/minor und breaking/major Änderungen

## Abnahmetests für Phase 0
1. Jedes Kernobjekt hat stabile Identität, Schema-Version und dokumentierte Semantik.
2. Ein Claim kann nicht als verifiziert gelten, ohne referenzierte Evidenz oder dokumentierte Ausnahme.
3. Ein Ziel hat mindestens ein überprüfbares Akzeptanzkriterium.
4. Eine ausführbare Aktion referenziert eine Policy-Entscheidung und einen Idempotenzschlüssel.
5. Ausführungsstatus und Verifikationsstatus sind getrennte Felder.
6. Unbekannte Statuswerte werden von validierenden Implementierungen zurückgewiesen.
7. Die Kernschemas enthalten keine Abhängigkeit zu einem bestimmten Agentenframework oder Provider.

## Exit-Kriterium
Phase 0 ist abgeschlossen, wenn die offenen Entscheidungen mit konkreten Werten beschlossen und die Schemas gegen positive und negative Testvektoren validiert wurden. Der aktuelle Stand ist ein implementierbarer Entwurf, aber diese Freigabe ist noch nicht erteilt.
