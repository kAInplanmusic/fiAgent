# PRAIN Phase 0 — Architekturverträge

**Version:** 0.1.0  
**Status:** Arbeitsentwurf zur technischen Prüfung  
**Ziel:** PRAIN framework-neutral spezifizieren, bevor konkrete Runtime-, Memory- oder Modellprodukte festgelegt werden.

## Inhalt
- `ontology.yaml`: kanonische Begriffe, fünf Funktionsbereiche, Claim-Typen und Beziehungstypen
- `architecture-decisions.md`: Architekturentscheidungen (ADRs) mit Status
- `policy-model.yaml`: Capability- und Risikomodell als erste Policy-Grundlage
- `schemas/*.schema.json`: JSON-Schemas für Kernobjekte
- `phase0-checklist.md`: Abnahmekriterien und offene Entscheidungen

## Leitplanken
1. PRAIN ist ein eigenständiges Framework, kein Hallerbans-spezifisches Modul.
2. P/R/A/I/N sind Fähigkeiten und Verantwortungsbereiche; nicht zwingend fünf separate Agenten.
3. Identität entsteht verteilt; `Anima` hält das explizite Selbst- und Kontinuitätsmodell.
4. Ein Tool-Erfolg ist nicht gleichbedeutend mit verifiziertem Aufgabenerfolg.
5. Aussagen behalten Typ, Provenienz, zeitliche Gültigkeit und Prüfstatus.
6. Aktionen müssen über ein Capability-/Policy-Gateway laufen.
7. Diese Dateien sind Spezifikationsentwürfe, noch keine implementierte oder sicherheitszertifizierte Runtime.
