# PRAIN Architecture Decision Records (ADRs)

## ADR-001 — Framework-neutrales Kernmodell
**Status:** angenommen  
PRAIN definiert eigene semantische Verträge und Adaptergrenzen. Frameworks und Provider sind austauschbare Implementierungen, keine Ontologie.

## ADR-002 — Fünf Dimensionen als Fähigkeiten
**Status:** angenommen  
P, R, A, I und N sind logische Verantwortungsbereiche. Eine Implementierung darf sie in einem Prozess, mehreren Services oder Agenten abbilden.

## ADR-003 — Verteilte Identität
**Status:** angenommen  
Die Identität von PRAIN-basierten Agenten entsteht aus dem Zusammenspiel aller fünf Dimensionen. A hält das explizite Selbstmodell und Identitätsversionen, ist aber nicht alleiniger „Besitzer“ der Identität.

## ADR-004 — Evidenztypen statt undifferenzierter Fakten
**Status:** angenommen  
Claims unterscheiden beobachtete Aussagen, Schlussfolgerungen, Hypothesen, Vorschläge und extern behauptete Aussagen. Provenienz und Prüfstatus werden separat erfasst.

## ADR-005 — Ausführung und Verifikation sind getrennt
**Status:** angenommen  
`ActionResult.status=completed` bedeutet nur, dass der Adapter die Aktion als abgeschlossen meldet. Der Aufgabenerfolg wird separat über `verification.status` festgestellt.

## ADR-006 — Capability-Gateway vor Tool-Ausführung
**Status:** angenommen als Architekturprinzip; Policy-Details noch offen  
Jede ausführende Aktion benötigt einen identifizierten Akteur, benannte Capability, Risiko-/Nebenwirkungsdeklaration und Policy-Entscheidung.

## ADR-007 — Event Envelope mit Korrelation und Idempotenz
**Status:** angenommen  
Ereignisse tragen `event_id`, `correlation_id`, `causation_id`, `occurred_at` und `schema_version`. Wiederholte Zustellung darf nicht unbemerkt doppelte Nebenwirkungen erzeugen.

## ADR-008 — Quantum-ready ohne Quantencomputing-Voraussetzung
**Status:** angenommen  
Zukunftsfähigkeit bedeutet stabile Verträge, austauschbare Adapter und explizite Compute-Schnittstellen. Es wird kein Quantenvorteil behauptet.

## ADR-009 — Speichertechnologie bleibt austauschbar
**Status:** angenommen  
Graph-, relationale, Dokument- und Vektorspeicher sind Backends. Das kanonische Datenmodell darf nicht von einem Backend-Schema abhängen.

## ADR-010 — Ungeklärte Entscheidungen werden sichtbar gehalten
**Status:** angenommen  
Offene Punkte erhalten Owner-Rolle, Entscheidungstermin/Trigger und Folgen; sie werden nicht stillschweigend als entschieden markiert.
