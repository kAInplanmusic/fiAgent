# PRAIN v0.9.0 — Decision Freeze Proposal

Status: proposal pack for user review. No decision is treated as approved unless explicitly marked carried forward from prior records or accepted by the project owner. No runtime implementation.

Includes the v0.7 traceability baseline, v0.8 schema audit and seven-track review, plus `docs/DECISION_FREEZE_PROPOSAL.md`. Phase 0 remains open pending deep schema constraint diff, knowledge-base item-level reconciliation, user decision approvals and evidence-backed exit review.
