# Phase 1 interface contracts — prototype mapping

| Interface | Prototype | Behavior | Known limit |
|---|---|---|---|
| Event Registry / Bus Adapter | `prain.event_bus.EventBus` | Event envelope, correlation ID, per-consumer duplicate suppression | In-memory; not durable |
| Goal Registry | `prain.goal_registry.GoalRegistry` | Acceptance criteria required; completion requires evidence-backed verification | Criteria are declared, not executed automatically |
| State Store | `prain.state_store.StateStore` | Create, get, optimistic compare-and-swap | Single-process in-memory |
| Policy Gateway | `prain.policy_gateway.PolicyGateway` | Deny-by-default; action/target/capability matching; optional bound approval | No authenticated policy source |
| Evidence ledger | `prain.evidence_ledger.EvidenceLedger` | Append-only API and hash-chain verification | No persistence, signing or external anchoring |

## Event semantics
The adapter models at-least-once delivery and suppresses duplicate event IDs per consumer within the current process. It does not claim exactly-once side effects. Handler failures are surfaced and not automatically retried because a handler may already have acted before raising.

## Policy semantics
No matching policy means deny. Rules must identify a policy and required capability. If approval is required, the approval binds action, target, canonical input hash, idempotency key and future expiry. This prototype does not authenticate the approval issuer.

## Goal semantics
A goal requires a title and at least one criterion containing `id` and `check`. Criteria define the acceptance contract but are not automatically executed. Completion requires a passing verification record, evidence reference and identified verifier.

## Next increments
1. Durable state and event inbox/outbox with retry/dead-letter behavior.
2. Authenticated policy source, signed short-lived approvals, policy provenance.
3. Criterion evaluator protocol and executable acceptance checks.
4. Signed/externally anchored audit and privacy/retention controls.
5. API and deployment configuration after contracts stabilize.
