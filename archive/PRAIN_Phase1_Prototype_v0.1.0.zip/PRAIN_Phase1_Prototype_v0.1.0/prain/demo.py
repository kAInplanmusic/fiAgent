import json
from dataclasses import asdict
from . import Event, EventBus, StateStore, GoalRegistry, PolicyGateway, ActionRequest, EvidenceLedger

def main():
    ledger, store, bus = EvidenceLedger(), StateStore(), EventBus()
    state = store.create("runtime.status", {"phase": "phase1", "healthy": True})
    ledger.append("state.created", "runtime.status", asdict(state))
    received = []
    bus.subscribe("goal.created", "demo.audit", lambda event: received.append(event.event_id))
    event = Event.create("goal.created", {"goal_id": "demo-goal"}, "demo-correlation")
    delivery = bus.publish(event)

    goals = GoalRegistry()
    goal = goals.create("Demonstrate a verified goal", [
        {"id": "criterion-1", "check": "demo_output_contains_success"}
    ], "demo-goal")
    goals.activate(goal.goal_id)
    verified = goals.record_verification(goal.goal_id, True, ["demo://verification/001"], "demo-verifier")
    ledger.append("goal.verified", goal.goal_id, asdict(verified))

    gateway = PolicyGateway([{
        "policy_id": "demo.read.v1", "action": "read", "target": "runtime.status",
        "required_capability": "state:read"
    }])
    req = ActionRequest.create("read", "runtime.status", "state:read", "demo", {"fields": ["phase", "healthy"]})
    decision = gateway.evaluate(req)
    ledger.append("policy.decision", req.action, asdict(decision))
    print(json.dumps({
        "state": asdict(store.get("runtime.status")),
        "event_delivery": delivery,
        "goal_status": verified.status,
        "policy_allowed": decision.allowed,
        "evidence_chain_valid": ledger.verify(),
        "note": "In-memory reference prototype; not production-ready."
    }, indent=2))

if __name__ == "__main__":
    main()
