# PRAIN v0.99.6 — Phase-0 Green Closure Release

**Phase-0 status:** `GREEN_PHASE0_SPECIFICATION_CLOSED`  
**Release status:** `PHASE0_CLOSED_PHASE1_NOT_AUTHORIZED`  
**Specification baseline:** immutable v0.99.4 archive, SHA-256 `fcfba5a97d1d9919f9a37344079127d0234fcfc3d1a03681c6e1282e9f04b1c2`.

## Closure decision and scope

The user's explicit instruction to re-iterate Phase 0, re-measure all checks, finish missing Phase-0 work, optimize the package, and mark it GREEN only at 100% completion is recorded in `PHASE0_CLOSURE_APPROVAL.md`. This release closes the **Phase-0 specification and release-package gate only**. Phase 1 remains a separate authorization gate and is **not authorized** by this package.

## Revalidation matrix

The final release must pass all six independently invocable validator suites below, with zero failures, and the release-bundle verifier must confirm exact manifest inventory, file sizes, SHA-256 digests, report consistency, ZIP CRC, and outer integrity metadata.

| Suite | Required result |
|---|---:|
| Main Phase-0 validator | 127/127 |
| Semantic consistency | 221/221 |
| Normative state-machine conformance | 504/504 |
| Schema/state-machine crosswalk | 65/65 |
| Deep reference-oracle conformance | 237/237 |
| Release-bundle verifier | All checks pass; exact count recorded by execution |

Counts from nested suites overlap and must not be represented as a count of unique requirements.

## Included scope

- Seven specification workstreams, canonical schemas, historical schema audit, knowledge-base disposition and source/claim audit.
- 30 invariant mappings with explicit verification boundaries, including 26 runtime obligations deferred to Phase 1 and four non-runtime boundary obligations.
- Positive and negative transition matrices, schema/state-machine crosswalk and deterministic reference-oracle checks.
- Release approval, lifecycle status, exact package manifest, internal integrity metadata and external ZIP integrity record.

## Limitations

`GREEN` here means 100% of the declared Phase-0 specification and packaging gates pass. It does **not** certify runtime conformance, distributed behavior, provider integrations, production security, legal compliance, live external-source truth, or production readiness. Those claims are outside Phase 0 and remain unverified until their own gates are run.

## Reproducible commands

From this directory:

```bash
python tools/validate_phase0.py
python tools/validate_semantic_consistency.py
python tools/validate_state_machine_conformance.py
python tools/validate_schema_state_machine_conformance.py
python tools/validate_deep_conformance.py
python tools/verify_release_bundle.py --directory .
```

Any failed check means the Phase-0 gate must be reverted from GREEN until corrected and all validators rerun.
