# PRAIN Phase-0 Closure Attestation

- Release package: `PRAIN v0.99.6 — Phase-0 Green Closure`
- Immutable specification baseline: `PRAIN v0.99.4 Phase-0 Schema/State-Machine Conformance`
- Baseline SHA-256: `fcfba5a97d1d9919f9a37344079127d0234fcfc3d1a03681c6e1282e9f04b1c2`
- Decision date: 2026-10-20 (Europe/Berlin)
- Phase-0 decision: `APPROVE_PHASE0_CLOSURE`
- Phase-1 decision: `NOT_AUTHORIZED`
- Phase-0 status: `GREEN_PHASE0_SPECIFICATION_CLOSED`
- Runtime implementation included in Phase 0: no.

## Phase-0 release criteria

The release is marked GREEN only after the final run of the main validator, semantic consistency, state-machine conformance, schema/state-machine crosswalk, deep conformance, and release-bundle verifier all passes with zero failures. The final ZIP is then checked for CRC/inventory consistency and recorded in the external integrity record with its exact SHA-256 and byte size.

## Phase-1 authorization remains separate

This attestation closes the Phase-0 specification and packaging gate only. It does not authorize Phase-1 runtime implementation, production deployment, OS/browser control, external side effects, paid API calls, or handling of secrets. Those require a separate explicit authorization decision with a bounded scope.

## Attestation boundary

Offline specification tests are not runtime or production certification. Historical requirement-level traceability outside the validated Phase-0 package remains part of the separate master audit.
